(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_46e405dc._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_717cc0fc._.js",
  "static/chunks/src_9169e5dd._.css"
],
    source: "dynamic"
});
