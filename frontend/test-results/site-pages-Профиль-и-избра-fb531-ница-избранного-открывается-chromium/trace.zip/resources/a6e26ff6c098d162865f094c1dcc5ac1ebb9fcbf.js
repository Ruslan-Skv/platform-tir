(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f0a7a077._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_717cc0fc._.js",
  "static/chunks/src_812cc8d4._.css"
],
    source: "dynamic"
});
