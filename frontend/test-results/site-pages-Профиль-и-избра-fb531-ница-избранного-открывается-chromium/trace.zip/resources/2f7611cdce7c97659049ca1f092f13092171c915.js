(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actionButtons": "ProductCard-module__3cykKa__actionButtons",
  "addToCartButton": "ProductCard-module__3cykKa__addToCartButton",
  "badges": "ProductCard-module__3cykKa__badges",
  "cardLink": "ProductCard-module__3cykKa__cardLink",
  "cardVariantChip": "ProductCard-module__3cykKa__cardVariantChip",
  "cardVariantChipActive": "ProductCard-module__3cykKa__cardVariantChipActive",
  "cardVariantChipImg": "ProductCard-module__3cykKa__cardVariantChipImg",
  "cardVariantsSelector": "ProductCard-module__3cykKa__cardVariantsSelector",
  "cartControls": "ProductCard-module__3cykKa__cartControls",
  "cartControlsYellow": "ProductCard-module__3cykKa__cartControlsYellow",
  "cartInfo": "ProductCard-module__3cykKa__cartInfo",
  "category": "ProductCard-module__3cykKa__category",
  "compareButton": "ProductCard-module__3cykKa__compareButton",
  "compareButtonActive": "ProductCard-module__3cykKa__compareButtonActive",
  "compareButtonLoading": "ProductCard-module__3cykKa__compareButtonLoading",
  "componentsBadge": "ProductCard-module__3cykKa__componentsBadge",
  "componentsIconWrapper": "ProductCard-module__3cykKa__componentsIconWrapper",
  "content": "ProductCard-module__3cykKa__content",
  "discountBadge": "ProductCard-module__3cykKa__discountBadge",
  "favoriteButton": "ProductCard-module__3cykKa__favoriteButton",
  "favoriteButtonActive": "ProductCard-module__3cykKa__favoriteButtonActive",
  "finalPrice": "ProductCard-module__3cykKa__finalPrice",
  "hitBadge": "ProductCard-module__3cykKa__hitBadge",
  "image": "ProductCard-module__3cykKa__image",
  "imageContainer": "ProductCard-module__3cykKa__imageContainer",
  "imageDot": "ProductCard-module__3cykKa__imageDot",
  "imageDotActive": "ProductCard-module__3cykKa__imageDotActive",
  "imageDots": "ProductCard-module__3cykKa__imageDots",
  "imageNavButton": "ProductCard-module__3cykKa__imageNavButton",
  "imageSection": "ProductCard-module__3cykKa__imageSection",
  "imageSideLeft": "ProductCard-module__3cykKa__imageSideLeft",
  "imageSideRight": "ProductCard-module__3cykKa__imageSideRight",
  "inCartLabel": "ProductCard-module__3cykKa__inCartLabel",
  "name": "ProductCard-module__3cykKa__name",
  "nameBlock": "ProductCard-module__3cykKa__nameBlock",
  "nameInContent": "ProductCard-module__3cykKa__nameInContent",
  "newBadge": "ProductCard-module__3cykKa__newBadge",
  "oldPrice": "ProductCard-module__3cykKa__oldPrice",
  "partnerBadge": "ProductCard-module__3cykKa__partnerBadge",
  "partnerLogo": "ProductCard-module__3cykKa__partnerLogo",
  "price": "ProductCard-module__3cykKa__price",
  "priceIcon": "ProductCard-module__3cykKa__priceIcon",
  "priceLabel": "ProductCard-module__3cykKa__priceLabel",
  "productCard": "ProductCard-module__3cykKa__productCard",
  "productCardCompact": "ProductCard-module__3cykKa__productCardCompact",
  "productCardCompare": "ProductCard-module__3cykKa__productCardCompare",
  "quantityButton": "ProductCard-module__3cykKa__quantityButton",
  "quantityControls": "ProductCard-module__3cykKa__quantityControls",
  "quantityDisplay": "ProductCard-module__3cykKa__quantityDisplay",
  "quantityValue": "ProductCard-module__3cykKa__quantityValue",
  "rating": "ProductCard-module__3cykKa__rating",
  "ratingValue": "ProductCard-module__3cykKa__ratingValue",
  "removeButton": "ProductCard-module__3cykKa__removeButton",
  "sku": "ProductCard-module__3cykKa__sku",
  "videoBadge": "ProductCard-module__3cykKa__videoBadge",
});
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductCard",
    ()=>ProductCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wallet.js [app-client] (ecmascript) <export default as Wallet>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CompareContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/WishlistContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const ProductCard = ({ product, isCompareMode = false, compact = false, onRemoveFromCompare, partnerLogoUrl = null, showPartnerIconOnCards = true })=>{
    _s();
    const { toggleWishlist, isInWishlist, wishlist } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"])();
    const { toggleCompare, isInCompare, compare, removeFromCompare } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompare"])();
    const { cart, addToCart, updateQuantity, updateCartItemQuantityById } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"])();
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCompareLoading, setIsCompareLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isAddingToCart, setIsAddingToCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentImageIndex, setCurrentImageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [selectedVariantIndex, setSelectedVariantIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const cardVariants = product.cardVariants && product.cardVariants.length > 0 ? product.cardVariants : [];
    const selectedVariant = cardVariants[selectedVariantIndex] ?? null;
    // Отображаемые данные: при выбранном варианте — из варианта, иначе из основного товара
    const displayName = selectedVariant ? selectedVariant.name : product.name;
    const displayPrice = selectedVariant ? selectedVariant.price : product.price;
    const displayOldPrice = selectedVariant ? undefined : product.oldPrice;
    const displayImage = selectedVariant?.image || (product.images?.[0] ?? product.image);
    const productImages = cardVariants.length > 0 ? cardVariants.map((v)=>v.image || product.image).filter(Boolean) : product.images && product.images.length > 0 ? product.images : product.image ? [
        product.image
    ] : [];
    const effectiveImages = productImages.length > 0 ? productImages : [
        product.image
    ].filter(Boolean);
    const hasMultipleImages = effectiveImages.length > 1;
    // Сбрасываем индекс изображения при смене товара
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductCard.useEffect": ()=>{
            setCurrentImageIndex(0);
        }
    }["ProductCard.useEffect"], [
        product.id
    ]);
    // Получаем оригинальный ID товара из API
    const getProductId = ()=>{
        // Используем originalId если он есть, иначе пробуем преобразовать id в string
        if (product.originalId) {
            return product.originalId;
        }
        // Fallback на id как string
        return String(product.id);
    };
    // Получаем ID товара один раз
    const productId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductCard.useMemo[productId]": ()=>getProductId()
    }["ProductCard.useMemo[productId]"], [
        product.id,
        product.originalId
    ]);
    // Используем глобальное состояние напрямую - автоматически обновляется при изменении wishlist/compare
    const isFavorite = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductCard.useMemo[isFavorite]": ()=>isInWishlist(productId)
    }["ProductCard.useMemo[isFavorite]"], [
        isInWishlist,
        productId,
        wishlist
    ]);
    const isInCompareState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductCard.useMemo[isInCompareState]": ()=>isInCompare(productId)
    }["ProductCard.useMemo[isInCompareState]"], [
        isInCompare,
        productId,
        compare
    ]);
    const finalPrice = displayPrice;
    const oldPrice = displayOldPrice;
    const handleFavoriteClick = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        try {
            setIsLoading(true);
            await toggleWishlist(productId);
        // Состояние обновится автоматически через глобальный контекст
        } catch (error) {
            if (error instanceof Error) {
                alert(error.message);
            } else {
                alert('Произошла ошибка при работе с избранным');
            }
        } finally{
            setIsLoading(false);
        }
    };
    const handleCompareClick = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
        if (isCompareLoading) {
            return;
        }
        try {
            setIsCompareLoading(true);
            await toggleCompare(productId);
        // Состояние обновится автоматически через глобальный контекст
        } catch (error) {
            if (error instanceof Error) {
                alert(error.message);
            } else {
                alert('Произошла ошибка при работе с сравнением');
            }
        } finally{
            setIsCompareLoading(false);
        }
    };
    const handleRemoveFromCompare = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        try {
            setIsCompareLoading(true);
            await removeFromCompare(productId);
            // Состояние обновится автоматически через глобальный контекст
            // Вызываем callback для обновления списка на странице сравнения
            if (onRemoveFromCompare) {
                onRemoveFromCompare();
            }
        } catch (error) {
            if (error instanceof Error) {
                alert(error.message);
            } else {
                alert('Произошла ошибка при удалении из сравнения');
            }
        } finally{
            setIsCompareLoading(false);
        }
    };
    const handleAddToCart = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const productId = getProductId();
        const cardVariantId = selectedVariant?.id;
        try {
            setIsAddingToCart(true);
            await addToCart(productId, 1, undefined, undefined, cardVariantId);
        } catch (error) {
            if (error instanceof Error) {
                alert(error.message);
            } else {
                alert('Произошла ошибка при добавлении в корзину');
            }
        } finally{
            setIsAddingToCart(false);
        }
    };
    const handlePreviousImage = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setCurrentImageIndex((prev)=>prev === 0 ? effectiveImages.length - 1 : prev - 1);
        if (cardVariants.length > 0) setSelectedVariantIndex((prev)=>prev === 0 ? cardVariants.length - 1 : prev - 1);
    };
    const handleNextImage = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setCurrentImageIndex((prev)=>prev === effectiveImages.length - 1 ? 0 : prev + 1);
        if (cardVariants.length > 0) setSelectedVariantIndex((prev)=>prev === cardVariants.length - 1 ? 0 : prev + 1);
    };
    const handleImageDotClick = (e, index)=>{
        e.preventDefault();
        e.stopPropagation();
        setCurrentImageIndex(index);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productCard} ${compact ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productCardCompact : ''} ${isCompareMode ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productCardCompare : ''}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: `/product/${product.slug}`,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardLink,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].nameBlock,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].name,
                        children: displayName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                        lineNumber: 202,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                    lineNumber: 201,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageSection,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageSideLeft,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badges,
                                    children: [
                                        product.isFeatured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].hitBadge,
                                            children: "ХИТ"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 207,
                                            columnNumber: 38
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        product.isNew && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].newBadge,
                                            children: "Новинка"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 208,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        product.discount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].discountBadge,
                                            children: [
                                                "-",
                                                product.discount,
                                                "%"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 210,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        product.videoUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoBadge,
                                            title: "Есть видео о товаре",
                                            children: "▶ Видео"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 213,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 206,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                product.isPartnerProduct && showPartnerIconOnCards && product.partnerShowLogoOnCards !== false && (product.partnerLogoUrl ?? partnerLogoUrl) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].partnerBadge,
                                    title: product.partnerShowTooltip !== false ? product.partnerTooltipText?.trim() || `Товар Партнёра : ${product.partnerName || 'Партнёр'}` : undefined,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: product.partnerLogoUrl ?? partnerLogoUrl ?? '',
                                        alt: "Партнёр",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].partnerLogo
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 231,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 222,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 205,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageContainer,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: cardVariants.length > 0 ? displayImage || product.image : effectiveImages[currentImageIndex] || product.image,
                                    alt: displayName,
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].image,
                                    loading: "lazy"
                                }, void 0, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 240,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                hasMultipleImages && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageNavButton,
                                            style: {
                                                left: '0.5rem'
                                            },
                                            onClick: handlePreviousImage,
                                            "aria-label": "Предыдущее изображение",
                                            children: "‹"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 252,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageNavButton,
                                            style: {
                                                right: '0.5rem'
                                            },
                                            onClick: handleNextImage,
                                            "aria-label": "Следующее изображение",
                                            children: "›"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 261,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageDots,
                                            children: effectiveImages.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageDot} ${index === currentImageIndex ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageDotActive : ''}`,
                                                    onClick: (e)=>handleImageDotClick(e, index),
                                                    "aria-label": `Изображение ${index + 1}`
                                                }, index, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 272,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 270,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageSideRight,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionButtons,
                                children: [
                                    isCompareMode ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].removeButton} ${isCompareLoading ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].compareButtonLoading : ''}`,
                                        "aria-label": "Удалить из сравнения",
                                        onClick: handleRemoveFromCompare,
                                        style: {
                                            pointerEvents: isCompareLoading ? 'none' : 'auto'
                                        },
                                        children: "🗑"
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 287,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].compareButton} ${isInCompareState ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].compareButtonActive : ''} ${isCompareLoading ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].compareButtonLoading : ''}`,
                                        "aria-label": isInCompareState ? 'Удалить из сравнения' : 'Добавить в сравнение',
                                        onClick: handleCompareClick,
                                        style: {
                                            pointerEvents: isCompareLoading ? 'none' : 'auto'
                                        },
                                        children: "⚖"
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 297,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].favoriteButton} ${isFavorite ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].favoriteButtonActive : ''}`,
                                        "aria-label": isFavorite ? 'Удалить из избранного' : 'Добавить в избранное',
                                        onClick: handleFavoriteClick,
                                        disabled: isLoading,
                                        children: isFavorite ? '♥' : '♡'
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 307,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                lineNumber: 285,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 284,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                    lineNumber: 204,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                    children: [
                        cardVariants.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardVariantsSelector,
                            onClick: (e)=>e.stopPropagation(),
                            children: cardVariants.map((v, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardVariantChip} ${i === selectedVariantIndex ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardVariantChipActive : ''}`,
                                    onClick: (e)=>{
                                        e.preventDefault();
                                        e.stopPropagation();
                                        setSelectedVariantIndex(i);
                                        setCurrentImageIndex(i);
                                    },
                                    title: v.name,
                                    children: v.image ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: v.image,
                                        alt: "",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardVariantChipImg
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 337,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: v.color || v.size || `${i + 1}`
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 339,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, v.id, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 324,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 322,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].name} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].nameInContent}`,
                            children: displayName
                        }, void 0, false, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 345,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        product.sku && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sku,
                            children: [
                                "Арт. ",
                                product.sku
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 346,
                            columnNumber: 27
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].category,
                            children: product.category
                        }, void 0, false, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 347,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        (product.rating > 0 || (product.reviewsCount ?? 0) > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rating,
                            children: [
                                '★'.repeat(Math.floor(product.rating || 0)),
                                '☆'.repeat(5 - Math.floor(product.rating || 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].ratingValue,
                                    children: [
                                        "(",
                                        product.rating?.toFixed(1) ?? '0',
                                        ")",
                                        (product.reviewsCount ?? 0) > 0 && ` · ${product.reviewsCount}`
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 353,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 350,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].price,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceLabel,
                                    children: "Стоимость:"
                                }, void 0, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 361,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceIcon,
                                    "aria-hidden": true,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__["Wallet"], {
                                        size: 18,
                                        strokeWidth: 2
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 363,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 362,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                oldPrice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].oldPrice,
                                    children: [
                                        oldPrice.toLocaleString(),
                                        " ₽"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 365,
                                    columnNumber: 26
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].finalPrice,
                                    children: [
                                        finalPrice.toLocaleString(),
                                        " ₽"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 366,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 360,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        (()=>{
                            const selectedVariantId = selectedVariant?.id ?? null;
                            const cartItem = cart.find((item)=>item.productId !== null && item.componentId === null && String(item.productId) === String(productId) && (item.cardVariantId ?? null) === selectedVariantId);
                            const quantity = cartItem ? Number(cartItem.quantity) : 0;
                            const isInCart = quantity > 0;
                            // Проверяем комплектующие этого товара в корзине
                            // Сопоставляем по productId (originalId если есть, иначе id) или по числовому id как fallback
                            const componentItems = cart.filter((item)=>{
                                if (item.componentId === null || item.productId !== null || item.component === null || item.component.product === null) {
                                    return false;
                                }
                                const componentProductId = String(item.component.product.id);
                                // Основное сопоставление: component.product.id должен совпадать с productId
                                // productId это либо originalId (если есть), либо String(id)
                                if (componentProductId === String(productId)) {
                                    return true;
                                }
                                // Fallback: проверяем числовой id на случай несоответствия
                                // (если backend вернул числовой id, а frontend использует originalId)
                                if (componentProductId === String(product.id)) {
                                    return true;
                                }
                                return false;
                            });
                            const componentsTotalQuantity = componentItems.reduce((sum, item)=>sum + Number(item.quantity), 0);
                            const hasComponents = componentsTotalQuantity > 0;
                            if (isInCart) {
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartControls,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartInfo,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inCartLabel,
                                                    children: "В корзине"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 415,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                hasComponents && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].componentsIconWrapper,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].componentsBadge,
                                                        children: componentsTotalQuantity > 99 ? '99+' : componentsTotalQuantity
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                        lineNumber: 418,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 417,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 414,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityControls,
                                            onClick: (e)=>e.stopPropagation(),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityButton,
                                                    onClick: async (e)=>{
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                        if (isAddingToCart) return;
                                                        try {
                                                            const newQuantity = Number(quantity) - 1;
                                                            if (newQuantity < 0) return;
                                                            if (cartItem?.id && selectedVariantId !== undefined) {
                                                                await updateCartItemQuantityById(cartItem.id, newQuantity);
                                                            } else {
                                                                await updateQuantity(productId, newQuantity);
                                                            }
                                                        } catch (error) {
                                                            if (error instanceof Error) {
                                                                alert(error.message);
                                                            } else {
                                                                alert('Произошла ошибка при обновлении количества');
                                                            }
                                                        }
                                                    },
                                                    onMouseDown: (e)=>{
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                    },
                                                    disabled: isAddingToCart,
                                                    children: "−"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 425,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityValue,
                                                    children: quantity
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 456,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityButton,
                                                    onClick: async (e)=>{
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                        if (isAddingToCart) return;
                                                        try {
                                                            const newQuantity = Number(quantity) + 1;
                                                            if (cartItem?.id && selectedVariantId !== undefined) {
                                                                await updateCartItemQuantityById(cartItem.id, newQuantity);
                                                            } else {
                                                                await updateQuantity(productId, newQuantity);
                                                            }
                                                        } catch (error) {
                                                            if (error instanceof Error) {
                                                                alert(error.message);
                                                            } else {
                                                                alert('Произошла ошибка при обновлении количества');
                                                            }
                                                        }
                                                    },
                                                    onMouseDown: (e)=>{
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                    },
                                                    disabled: isAddingToCart,
                                                    children: "+"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 457,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 424,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 413,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0));
                            }
                            // Если товара нет в корзине, но есть комплектующие
                            if (hasComponents && !isInCart) {
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartControlsYellow,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartInfo,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inCartLabel,
                                                children: "В корзине"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                lineNumber: 497,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 496,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityDisplay,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityValue,
                                                children: componentsTotalQuantity
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                lineNumber: 500,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 499,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 495,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0));
                            }
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].addToCartButton,
                                onClick: handleAddToCart,
                                disabled: isAddingToCart,
                                children: isAddingToCart ? 'Добавление...' : 'В корзину'
                            }, void 0, false, {
                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                lineNumber: 507,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0));
                        })()
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                    lineNumber: 320,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
            lineNumber: 200,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
        lineNumber: 197,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ProductCard, "mxDl/psDI+sw/ZoGzVLycsOhYVo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompare"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"]
    ];
});
_c = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductCard/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "empty": "ProductsGrid-module__XmqpHa__empty",
  "error": "ProductsGrid-module__XmqpHa__error",
  "grid": "ProductsGrid-module__XmqpHa__grid",
  "gridHeader": "ProductsGrid-module__XmqpHa__gridHeader",
  "gridMobile2": "ProductsGrid-module__XmqpHa__gridMobile2",
  "headerRight": "ProductsGrid-module__XmqpHa__headerRight",
  "loading": "ProductsGrid-module__XmqpHa__loading",
  "productsGrid": "ProductsGrid-module__XmqpHa__productsGrid",
  "sortLabel": "ProductsGrid-module__XmqpHa__sortLabel",
  "sortSelect": "ProductsGrid-module__XmqpHa__sortSelect",
  "sorting": "ProductsGrid-module__XmqpHa__sorting",
  "title": "ProductsGrid-module__XmqpHa__title",
  "totalCount": "ProductsGrid-module__XmqpHa__totalCount",
});
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductsGrid",
    ()=>ProductsGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useMobileCatalogColumns$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useMobileCatalogColumns.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const PRODUCTS_PER_PAGE = 20; // 5 строк × 4 столбца
const ProductsGrid = ({ categorySlug, categoryName = 'Каталог', currentPage = 1, onTotalPagesChange, onSortChange })=>{
    _s();
    const [products, setProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [originalProducts, setOriginalProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [sortBy, setSortBy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('default');
    const mobileCatalogColumns = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useMobileCatalogColumns$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMobileCatalogColumns"])();
    const [partnerSettings, setPartnerSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        partnerLogoUrl: null,
        showPartnerIconOnCards: true
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsGrid.useEffect": ()=>{
            const fetchProducts = {
                "ProductsGrid.useEffect.fetchProducts": async ()=>{
                    if (!categorySlug) {
                        setLoading(false);
                        return;
                    }
                    try {
                        setLoading(true);
                        setError(null);
                        // Для slug "all" используем специальный endpoint для всех товаров
                        const endpoint = categorySlug === 'all' ? `${API_URL}/products/catalog/all` : `${API_URL}/products/category/${categorySlug}`;
                        const response = await fetch(endpoint);
                        if (!response.ok) {
                            throw new Error('Не удалось загрузить товары');
                        }
                        const data = await response.json();
                        // Преобразуем API-формат в формат Product для компонента
                        const mappedProducts = data.products.map({
                            "ProductsGrid.useEffect.fetchProducts.mappedProducts": (p, index)=>({
                                    id: index + 1,
                                    originalId: p.id,
                                    slug: p.slug,
                                    name: p.name,
                                    sku: p.sku || undefined,
                                    description: p.description || undefined,
                                    price: parseFloat(p.price),
                                    oldPrice: p.comparePrice ? parseFloat(p.comparePrice) : undefined,
                                    image: p.images[0] || '/images/products/door-placeholder.jpg',
                                    images: p.images,
                                    category: p.category.name,
                                    categoryId: parseInt(p.category.id) || undefined,
                                    rating: p.rating ?? 0,
                                    reviewsCount: p.reviewsCount ?? 0,
                                    isNew: p.isNew,
                                    isFeatured: p.isFeatured,
                                    isPartnerProduct: p.isPartnerProduct ?? !!p.partner,
                                    partnerLogoUrl: p.partner?.logoUrl ?? null,
                                    partnerShowLogoOnCards: p.partner?.showLogoOnCards ?? true,
                                    partnerName: p.partner?.name ?? null,
                                    partnerTooltipText: p.partner?.tooltipText ?? null,
                                    partnerShowTooltip: p.partner?.showTooltip ?? true,
                                    inStock: p.stock > 0,
                                    discount: p.comparePrice ? Math.round((parseFloat(p.comparePrice) - parseFloat(p.price)) / parseFloat(p.comparePrice) * 100) : undefined,
                                    // Сохраняем дополнительные данные для сортировки
                                    sortOrder: p.sortOrder ?? 0,
                                    createdAt: p.createdAt ? new Date(p.createdAt).getTime() : Date.now(),
                                    videoUrl: p.videoUrl ?? undefined,
                                    cardVariants: p.cardVariants?.map({
                                        "ProductsGrid.useEffect.fetchProducts.mappedProducts": (v)=>({
                                                id: v.id,
                                                name: v.name,
                                                price: typeof v.price === 'string' ? parseFloat(v.price) : v.price,
                                                image: v.image ?? undefined,
                                                size: v.size ?? undefined,
                                                color: v.color ?? undefined,
                                                extraOption: v.extraOption ?? undefined,
                                                sortOrder: v.sortOrder
                                            })
                                    }["ProductsGrid.useEffect.fetchProducts.mappedProducts"])
                                })
                        }["ProductsGrid.useEffect.fetchProducts.mappedProducts"]);
                        setOriginalProducts(mappedProducts);
                        setProducts(mappedProducts);
                    } catch (err) {
                        setError(err instanceof Error ? err.message : 'Произошла ошибка');
                    } finally{
                        setLoading(false);
                    }
                }
            }["ProductsGrid.useEffect.fetchProducts"];
            fetchProducts();
            // Сбрасываем сортировку при изменении категории
            setSortBy('default');
        }
    }["ProductsGrid.useEffect"], [
        categorySlug
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsGrid.useEffect": ()=>{
            const fetchPartnerSettings = {
                "ProductsGrid.useEffect.fetchPartnerSettings": async ()=>{
                    try {
                        const res = await fetch(`${API_URL}/home/partner-products`);
                        if (res.ok) {
                            const data = await res.json();
                            setPartnerSettings({
                                partnerLogoUrl: data.partnerLogoUrl ?? null,
                                showPartnerIconOnCards: data.showPartnerIconOnCards ?? true
                            });
                        }
                    } catch  {
                    // ignore
                    }
                }
            }["ProductsGrid.useEffect.fetchPartnerSettings"];
            fetchPartnerSettings();
        }
    }["ProductsGrid.useEffect"], []);
    // Функция сортировки товаров
    const sortProducts = (productsToSort, sortOption)=>{
        const sorted = [
            ...productsToSort
        ];
        switch(sortOption){
            case 'price-asc':
                return sorted.sort((a, b)=>a.price - b.price);
            case 'price-desc':
                return sorted.sort((a, b)=>b.price - a.price);
            case 'name-asc':
                return sorted.sort((a, b)=>a.name.localeCompare(b.name, 'ru'));
            case 'name-desc':
                return sorted.sort((a, b)=>b.name.localeCompare(a.name, 'ru'));
            case 'new':
                return sorted.sort((a, b)=>{
                    // Сначала новые товары (isNew), затем по дате создания
                    if (a.isNew !== b.isNew) {
                        return a.isNew ? -1 : 1;
                    }
                    return (b.createdAt || 0) - (a.createdAt || 0);
                });
            case 'rating':
                return sorted.sort((a, b)=>(b.rating || 0) - (a.rating || 0));
            case 'default':
            default:
                // Сортировка по sortOrder (из админки), затем по дате создания
                return sorted.sort((a, b)=>{
                    const sortOrderA = a.sortOrder ?? 0;
                    const sortOrderB = b.sortOrder ?? 0;
                    if (sortOrderA !== sortOrderB) {
                        return sortOrderA - sortOrderB;
                    }
                    return (b.createdAt || 0) - (a.createdAt || 0);
                });
        }
    };
    // Применяем сортировку при изменении sortBy или originalProducts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsGrid.useEffect": ()=>{
            const sorted = sortProducts(originalProducts, sortBy);
            setProducts(sorted);
        }
    }["ProductsGrid.useEffect"], [
        sortBy,
        originalProducts
    ]);
    // Пагинация - вычисляем до условных возвратов
    const totalPages = Math.ceil(products.length / PRODUCTS_PER_PAGE);
    const startIndex = (currentPage - 1) * PRODUCTS_PER_PAGE;
    const endIndex = startIndex + PRODUCTS_PER_PAGE;
    const currentProducts = products.slice(startIndex, endIndex);
    // Передаём количество страниц в родительский компонент
    // Этот useEffect должен быть до условных return, чтобы соблюдать правила хуков
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsGrid.useEffect": ()=>{
            onTotalPagesChange?.(totalPages);
        }
    }["ProductsGrid.useEffect"], [
        totalPages,
        onTotalPagesChange
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridHeader,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: categoryName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 268,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 267,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading,
                    children: "Загрузка товаров..."
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 270,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
            lineNumber: 266,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridHeader,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: categoryName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 279,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 278,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                    children: error
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 281,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
            lineNumber: 277,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (products.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridHeader,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: categoryName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 290,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 289,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
                    children: "Товары не найдены"
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 292,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
            lineNumber: 288,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridHeader,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: categoryName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 300,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerRight,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].totalCount,
                                children: [
                                    products.length,
                                    ' ',
                                    products.length === 1 ? 'товар' : products.length < 5 ? 'товара' : 'товаров'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                lineNumber: 302,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sorting,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "sort-select",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sortLabel,
                                        children: "Сортировка:"
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                        lineNumber: 307,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        id: "sort-select",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sortSelect,
                                        value: sortBy,
                                        onChange: (e)=>{
                                            setSortBy(e.target.value);
                                            // Сбрасываем на первую страницу при изменении сортировки
                                            onSortChange?.();
                                            window.scrollTo({
                                                top: 0,
                                                behavior: 'smooth'
                                            });
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "default",
                                                children: "По умолчанию"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 321,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "price-asc",
                                                children: "По цене (сначала дешевые)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 322,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "price-desc",
                                                children: "По цене (сначала дорогие)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 323,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "name-asc",
                                                children: "По названию (А-Я)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 324,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "name-desc",
                                                children: "По названию (Я-А)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 325,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "new",
                                                children: "По новизне"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 326,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "rating",
                                                children: "По рейтингу"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 327,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                        lineNumber: 310,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                lineNumber: 306,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 301,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                lineNumber: 299,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid} ${mobileCatalogColumns === 2 ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridMobile2 : ''}`,
                children: currentProducts.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                        product: product,
                        partnerLogoUrl: partnerSettings.partnerLogoUrl,
                        showPartnerIconOnCards: partnerSettings.showPartnerIconOnCards
                    }, product.id, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 335,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                lineNumber: 333,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
        lineNumber: 298,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ProductsGrid, "zuEMyIMgDWw6P60QEKQhzTwdCzE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useMobileCatalogColumns$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMobileCatalogColumns"]
    ];
});
_c = ProductsGrid;
var _c;
__turbopack_context__.k.register(_c, "ProductsGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/views/catalog/ui/ProductsGrid/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/(site)/favorites/page.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "container": "page-module__zX5V-q__container",
  "empty": "page-module__zX5V-q__empty",
  "error": "page-module__zX5V-q__error",
  "grid": "page-module__zX5V-q__grid",
  "header": "page-module__zX5V-q__header",
  "link": "page-module__zX5V-q__link",
  "loading": "page-module__zX5V-q__loading",
  "subtitle": "page-module__zX5V-q__subtitle",
  "title": "page-module__zX5V-q__title",
});
}),
"[project]/src/app/(site)/favorites/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FavoritesPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$wishlist$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/wishlist.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/WishlistContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/app/(site)/favorites/page.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function FavoritesPage() {
    _s();
    const { count, refreshCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"])();
    const [products, setProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FavoritesPage.useEffect": ()=>{
            const loadWishlist = {
                "FavoritesPage.useEffect.loadWishlist": async ()=>{
                    try {
                        setLoading(true);
                        setError(null);
                        const wishlistProducts = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$wishlist$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWishlist"]();
                        setProducts(wishlistProducts);
                        await refreshCount();
                    } catch (err) {
                        if (err instanceof Error) {
                            if (err.message === 'Необходима авторизация') {
                                setError('Войдите в систему, чтобы просмотреть избранные товары');
                            } else {
                                setError(err.message);
                            }
                        } else {
                            setError('Произошла ошибка при загрузке избранного');
                        }
                    } finally{
                        setLoading(false);
                    }
                }
            }["FavoritesPage.useEffect.loadWishlist"];
            loadWishlist();
        }
    }["FavoritesPage.useEffect"], [
        refreshCount
    ]);
    // Преобразуем формат API в формат Product для ProductCard
    const mappedProducts = products.map((p, index)=>{
        const price = typeof p.price === 'string' ? parseFloat(p.price) : Number(p.price);
        const comparePrice = p.comparePrice ? typeof p.comparePrice === 'string' ? parseFloat(p.comparePrice) : Number(p.comparePrice) : undefined;
        return {
            id: index + 1,
            originalId: p.id,
            slug: p.slug,
            name: p.name,
            price,
            oldPrice: comparePrice,
            image: p.images?.[0] || '/images/products/door-placeholder.jpg',
            images: p.images || [],
            category: p.category.name,
            categoryId: parseInt(p.category.id) || undefined,
            rating: p.rating ?? 0,
            reviewsCount: p.reviewsCount ?? 0,
            isNew: p.isNew,
            isFeatured: p.isFeatured,
            inStock: (p.stock ?? 0) > 0,
            discount: comparePrice ? Math.round((comparePrice - price) / comparePrice * 100) : undefined
        };
    });
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading,
                children: "Загрузка избранного..."
            }, void 0, false, {
                fileName: "[project]/src/app/(site)/favorites/page.tsx",
                lineNumber: 98,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/(site)/favorites/page.tsx",
            lineNumber: 97,
            columnNumber: 7
        }, this);
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        children: "Ошибка"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 107,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 108,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link,
                        children: "Вернуться на главную"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 109,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(site)/favorites/page.tsx",
                lineNumber: 106,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/(site)/favorites/page.tsx",
            lineNumber: 105,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: "Избранное"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 120,
                        columnNumber: 9
                    }, this),
                    count > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                        children: [
                            count,
                            " ",
                            count === 1 ? 'товар' : count < 5 ? 'товара' : 'товаров',
                            " в избранном"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 122,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(site)/favorites/page.tsx",
                lineNumber: 119,
                columnNumber: 7
            }, this),
            products.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: "Ваш список избранного пуст"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 130,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Добавьте товары в избранное, чтобы вернуться к ним позже"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/catalog/products",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link,
                        children: "Перейти в каталог"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(site)/favorites/page.tsx",
                lineNumber: 129,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$favorites$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                children: mappedProducts.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                        product: product
                    }, product.originalId || product.slug, false, {
                        fileName: "[project]/src/app/(site)/favorites/page.tsx",
                        lineNumber: 139,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/(site)/favorites/page.tsx",
                lineNumber: 137,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(site)/favorites/page.tsx",
        lineNumber: 118,
        columnNumber: 5
    }, this);
}
_s(FavoritesPage, "pgmfrbDFSs/6dszkFbCEdxVkQ+M=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"]
    ];
});
_c = FavoritesPage;
var _c;
__turbopack_context__.k.register(_c, "FavoritesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_f0a7a077._.js.map