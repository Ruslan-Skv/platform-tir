(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/shared/api/home-sections.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAdminHomeSectionsVisibility",
    ()=>getAdminHomeSectionsVisibility,
    "getHomeSectionsVisibility",
    ()=>getHomeSectionsVisibility,
    "updateAdminHomeSectionsVisibility",
    ()=>updateAdminHomeSectionsVisibility
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function getAuthHeaders() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const token = localStorage.getItem('admin_token');
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
async function getHomeSectionsVisibility() {
    const res = await fetch(`${API_URL}/home/sections`);
    if (!res.ok) throw new Error('Не удалось загрузить настройки секций');
    return res.json();
}
async function getAdminHomeSectionsVisibility() {
    const res = await fetch(`${API_URL}/admin/home/sections`, {
        headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить настройки секций');
    return res.json();
}
async function updateAdminHomeSectionsVisibility(data) {
    const res = await fetch(`${API_URL}/admin/home/sections`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message || 'Ошибка сохранения');
    }
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/HomePage/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$HomePage$2f$HomePage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/HomePage/HomePage.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "advantageCard": "AdvantagesSection-module__uORtFa__advantageCard",
  "advantageDescription": "AdvantagesSection-module__uORtFa__advantageDescription",
  "advantageTitle": "AdvantagesSection-module__uORtFa__advantageTitle",
  "advantages": "AdvantagesSection-module__uORtFa__advantages",
  "container": "AdvantagesSection-module__uORtFa__container",
  "grid": "AdvantagesSection-module__uORtFa__grid",
  "header": "AdvantagesSection-module__uORtFa__header",
  "icon": "AdvantagesSection-module__uORtFa__icon",
  "iconImg": "AdvantagesSection-module__uORtFa__iconImg",
  "subtitle": "AdvantagesSection-module__uORtFa__subtitle",
  "title": "AdvantagesSection-module__uORtFa__title",
});
}),
"[project]/src/widgets/home/ui/AdvantagesSection/AdvantageCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AdvantageCard",
    ()=>AdvantageCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.module.css [app-client] (css module)");
;
;
const AdvantageCard = ({ advantage })=>{
    const isIconImage = advantage.icon?.includes('/uploads/');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].advantageCard,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon,
                children: isIconImage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: advantage.icon,
                    alt: "",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconImg
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantageCard.tsx",
                    lineNumber: 20,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)) : advantage.icon
            }, void 0, false, {
                fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantageCard.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].advantageTitle,
                children: advantage.title
            }, void 0, false, {
                fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantageCard.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].advantageDescription,
                children: advantage.description
            }, void 0, false, {
                fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantageCard.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantageCard.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = AdvantageCard;
var _c;
__turbopack_context__.k.register(_c, "AdvantageCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AdvantagesSection",
    ()=>AdvantagesSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantageCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/AdvantagesSection/AdvantageCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const UPLOADS_BASE = API_URL.replace(/\/api\/v1\/?$/, '');
const DEFAULT_DATA = {
    block: {
        title: 'Почему выбирают нас',
        subtitle: 'Мы делаем качество доступным'
    },
    items: []
};
const AdvantagesSection = ()=>{
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_DATA);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AdvantagesSection.useEffect": ()=>{
            fetch(`${API_URL}/home/advantages`).then({
                "AdvantagesSection.useEffect": (res)=>res.ok ? res.json() : null
            }["AdvantagesSection.useEffect"]).then({
                "AdvantagesSection.useEffect": (d)=>{
                    if (d?.block) setData(d);
                }
            }["AdvantagesSection.useEffect"]).catch({
                "AdvantagesSection.useEffect": ()=>{}
            }["AdvantagesSection.useEffect"]);
        }
    }["AdvantagesSection.useEffect"], []);
    const imageUrl = (url)=>{
        if (!url) return '';
        if (url.startsWith('http')) return url;
        return `${UPLOADS_BASE}${url.startsWith('/') ? '' : '/'}${url}`;
    };
    const isIconImageUrl = (icon)=>!!(icon && typeof icon === 'string' && icon.includes('/uploads/'));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].advantages,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                            children: data.block.title
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                            children: data.block.subtitle
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                    children: data.items.map((item)=>{
                        const advantage = {
                            id: item.id,
                            icon: isIconImageUrl(item.icon) ? imageUrl(item.icon) : item.icon,
                            title: item.title,
                            description: item.description
                        };
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantageCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdvantageCard"], {
                            advantage: advantage
                        }, item.id, false, {
                            fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx",
                            lineNumber: 66,
                            columnNumber: 20
                        }, ("TURBOPACK compile-time value", void 0));
                    })
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx",
            lineNumber: 52,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(AdvantagesSection, "FmfJ3JynE/UJNl80sX4VpLFa+sw=");
_c = AdvantagesSection;
var _c;
__turbopack_context__.k.register(_c, "AdvantagesSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/AdvantagesSection/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/lib/constants/homeConstants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_DIRECTION_IMAGES",
    ()=>DEFAULT_DIRECTION_IMAGES,
    "advantages",
    ()=>advantages,
    "categories",
    ()=>categories,
    "services",
    ()=>services
]);
const DEFAULT_DIRECTION_IMAGES = {
    furniture: '/images/mebel.jpg',
    repair: '/images/remont-kvartir.jpg',
    doors: '/images/dveri.jpg',
    windows: '/images/okna.jpg',
    ceilings: '/images/potolki.jpg',
    blinds: '/images/zhalyuzi.jpg',
    sales: '/images/akcii.jpg'
};
const categories = [
    {
        id: 1,
        slug: 'furniture',
        name: 'Мебель на заказ',
        description: 'Кухни, шкафы, гостиные по индивидуальным размерам',
        image: DEFAULT_DIRECTION_IMAGES.furniture ?? '',
        productCount: 156,
        href: '/catalog?category=мебель'
    },
    {
        id: 2,
        slug: 'repair',
        name: 'Ремонт квартир',
        description: 'Ремонт под ключ и отделочные работы',
        image: DEFAULT_DIRECTION_IMAGES.repair ?? '',
        productCount: 42,
        href: '/catalog?category=ремонт'
    },
    {
        id: 3,
        slug: 'doors',
        name: 'Двери',
        description: 'Межкомнатные и входные двери',
        image: DEFAULT_DIRECTION_IMAGES.doors ?? '',
        productCount: 89,
        href: '/catalog?category=двери'
    },
    {
        id: 4,
        slug: 'windows',
        name: 'Окна',
        description: 'Пластиковые и алюминиевые окна',
        image: DEFAULT_DIRECTION_IMAGES.windows ?? '',
        productCount: 67,
        href: '/catalog?category=окна'
    },
    {
        id: 5,
        slug: 'ceilings',
        name: 'Потолки',
        description: 'Натяжные и гипсокартонные потолки',
        image: DEFAULT_DIRECTION_IMAGES.ceilings ?? '',
        productCount: 54,
        href: '/catalog?category=потолки'
    },
    {
        id: 6,
        slug: 'blinds',
        name: 'Жалюзи',
        description: 'Горизонтальные, вертикальные, рулонные',
        image: DEFAULT_DIRECTION_IMAGES.blinds ?? '',
        productCount: 73,
        href: '/catalog?category=жалюзи'
    },
    {
        id: 7,
        slug: 'sales',
        name: 'Акции',
        description: 'Специальные предложения и скидки',
        image: DEFAULT_DIRECTION_IMAGES.sales ?? '',
        productCount: 28,
        href: '/catalog?category=акции',
        isSale: true
    }
];
const advantages = [
    {
        id: 1,
        title: 'Собственное производство',
        description: 'Изготавливаем мебель и конструкции на собственном производстве в Мурманске',
        icon: '🏭'
    },
    {
        id: 2,
        title: 'Бесплатный замер',
        description: 'Выезд специалиста для точных замеров и консультации',
        icon: '📐'
    },
    {
        id: 3,
        title: 'Опыт 15+ лет',
        description: 'Более 15 лет создаем интерьеры в Мурманске и области',
        icon: '🏆'
    },
    {
        id: 4,
        title: 'Сроки от 1 дня',
        description: 'Быстрое изготовление и монтаж без задержек',
        icon: '⚡'
    },
    {
        id: 5,
        title: 'Гарантия 3 года',
        description: 'Предоставляем гарантию на все работы и материалы',
        icon: '🛡️'
    },
    {
        id: 6,
        title: 'Дизайн-проект',
        description: 'Разработка индивидуального дизайн-проекта',
        icon: '🎨'
    }
];
const services = [
    {
        id: 1,
        title: 'Ремонт под ключ',
        description: 'Полный цикл от дизайна до чистовой отделки',
        features: [
            'Дизайн-проект',
            'Черновые работы',
            'Чистовая отделка',
            'Мебель на заказ',
            'Авторский надзор'
        ],
        price: 'от 5 000 ₽/м²',
        image: ''
    },
    {
        id: 2,
        title: 'Мебель на заказ',
        description: 'Изготовление мебели по индивидуальным размерам',
        features: [
            'Кухни любой сложности',
            'Шкафы-купе и гардеробные',
            'Гостиные и стенки',
            'Спальни и детские'
        ],
        price: 'от 15 000 ₽',
        image: ''
    },
    {
        id: 3,
        title: 'Дизайн интерьера',
        description: 'Создание индивидуального дизайн-проекта',
        features: [
            '3D-визуализация',
            'Подбор материалов',
            'Смета и планировка',
            'Авторский надзор'
        ],
        price: 'от 1 500 ₽/м²',
        image: ''
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/lib/constants/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$lib$2f$constants$2f$homeConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/lib/constants/homeConstants.ts [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "arrow": "CategoriesGrid-module__ZU2VNq__arrow",
  "card": "CategoriesGrid-module__ZU2VNq__card",
  "cardContent": "CategoriesGrid-module__ZU2VNq__cardContent",
  "cardDescription": "CategoriesGrid-module__ZU2VNq__cardDescription",
  "cardFooter": "CategoriesGrid-module__ZU2VNq__cardFooter",
  "cardImage": "CategoriesGrid-module__ZU2VNq__cardImage",
  "cardTitle": "CategoriesGrid-module__ZU2VNq__cardTitle",
  "categories": "CategoriesGrid-module__ZU2VNq__categories",
  "container": "CategoriesGrid-module__ZU2VNq__container",
  "grid": "CategoriesGrid-module__ZU2VNq__grid",
  "header": "CategoriesGrid-module__ZU2VNq__header",
  "productCount": "CategoriesGrid-module__ZU2VNq__productCount",
  "saleBadge": "CategoriesGrid-module__ZU2VNq__saleBadge",
  "subtitle": "CategoriesGrid-module__ZU2VNq__subtitle",
  "title": "CategoriesGrid-module__ZU2VNq__title",
});
}),
"[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CategoryCard",
    ()=>CategoryCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.module.css [app-client] (css module)");
;
;
const CategoryCard = ({ category, onClick })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card} ${category.isSale ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].saleCard : ''}`,
        onClick: onClick,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardImage,
                style: category.image ? {
                    backgroundImage: `url(${category.image})`
                } : undefined,
                children: category.isSale && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].saleBadge,
                    children: "Акция"
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
                    lineNumber: 22,
                    columnNumber: 29
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardContent,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardTitle,
                        children: category.name
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardDescription,
                        children: category.description
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardFooter,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productCount,
                                children: [
                                    category.productCount,
                                    " товаров"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
                                lineNumber: 28,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].arrow,
                                children: "→"
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = CategoryCard;
var _c;
__turbopack_context__.k.register(_c, "CategoryCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CategoriesGrid",
    ()=>CategoriesGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$lib$2f$constants$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/lib/constants/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$lib$2f$constants$2f$homeConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/lib/constants/homeConstants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoryCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/CategoriesGrid/CategoryCard.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const DIRECTIONS_IMAGES_STORAGE_KEY = 'platform-tir:home-directions-images';
function getStoredDirectionImages() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = localStorage.getItem(DIRECTIONS_IMAGES_STORAGE_KEY);
        if (!raw) return {};
        const data = JSON.parse(raw);
        return data && typeof data === 'object' ? data : {};
    } catch  {
        return {};
    }
}
function setStoredDirectionImages(data) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        localStorage.setItem(DIRECTIONS_IMAGES_STORAGE_KEY, JSON.stringify(data));
    } catch  {
    // ignore
    }
}
const CategoriesGrid = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    // Стартуем с дефолтных картинок (локальные пути), чтобы при остановленном бэкенде
    // не рендерить URL с localhost:3001 и не получать ERR_CONNECTION_REFUSED в консоли.
    const [directionImages, setDirectionImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "CategoriesGrid.useState": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$lib$2f$constants$2f$homeConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_DIRECTION_IMAGES"]
    }["CategoriesGrid.useState"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CategoriesGrid.useEffect": ()=>{
            fetch(`${API_URL}/home/directions/images`).then({
                "CategoriesGrid.useEffect": (res)=>res.ok ? res.json() : Promise.reject(new Error('Not ok'))
            }["CategoriesGrid.useEffect"]).then({
                "CategoriesGrid.useEffect": (data)=>{
                    const next = data && typeof data === 'object' ? data : {};
                    const hasAnyImages = Object.keys(next).length > 0;
                    if (hasAnyImages) {
                        setStoredDirectionImages(next);
                        setDirectionImages(next);
                    }
                }
            }["CategoriesGrid.useEffect"]).catch({
                "CategoriesGrid.useEffect": ()=>{
                    // При недоступности бэкенда используем только локальные картинки из констант,
                    // чтобы не запрашивать http://localhost:3001/uploads/... (ERR_CONNECTION_REFUSED).
                    setDirectionImages(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$lib$2f$constants$2f$homeConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_DIRECTION_IMAGES"]);
                }
            }["CategoriesGrid.useEffect"]);
        }
    }["CategoriesGrid.useEffect"], []);
    const categoriesWithImages = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$lib$2f$constants$2f$homeConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["categories"].map((cat)=>({
            ...cat,
            image: directionImages[cat.slug] || cat.image
        }));
    const handleCategoryClick = (href)=>{
        router.push(href);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categories,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                            children: "Наши направления"
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                            children: "Полный спектр услуг для вашего интерьера"
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx",
                    lineNumber: 75,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                    children: categoriesWithImages.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoryCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CategoryCard"], {
                            category: category,
                            onClick: ()=>handleCategoryClick(category.href)
                        }, category.id, false, {
                            fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx",
                            lineNumber: 82,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)))
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx",
            lineNumber: 74,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx",
        lineNumber: 73,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CategoriesGrid, "QClNZ3Uk15LbV3gTQ1plbgoJ9Vo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = CategoriesGrid;
var _c;
__turbopack_context__.k.register(_c, "CategoriesGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/CategoriesGrid/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/contact-form.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAdminContactFormBlock",
    ()=>getAdminContactFormBlock,
    "getContactFormBlock",
    ()=>getContactFormBlock,
    "updateAdminContactFormBlock",
    ()=>updateAdminContactFormBlock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function getAuthHeaders() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const token = localStorage.getItem('admin_token');
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
async function getContactFormBlock() {
    const res = await fetch(`${API_URL}/home/contact-form`);
    if (!res.ok) throw new Error('Не удалось загрузить блок');
    return res.json();
}
async function getAdminContactFormBlock() {
    const res = await fetch(`${API_URL}/admin/home/contact-form`, {
        headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить блок');
    return res.json();
}
async function updateAdminContactFormBlock(data) {
    const res = await fetch(`${API_URL}/admin/home/contact-form`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message || 'Ошибка сохранения');
    }
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/ContactSection/ContactSection.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "ContactSection-module__PXWClq__actions",
  "background": "ContactSection-module__PXWClq__background",
  "callbackLink": "ContactSection-module__PXWClq__callbackLink",
  "contact": "ContactSection-module__PXWClq__contact",
  "contactInfo": "ContactSection-module__PXWClq__contactInfo",
  "container": "ContactSection-module__PXWClq__container",
  "content": "ContactSection-module__PXWClq__content",
  "infoItem": "ContactSection-module__PXWClq__infoItem",
  "infoLabel": "ContactSection-module__PXWClq__infoLabel",
  "infoValue": "ContactSection-module__PXWClq__infoValue",
  "measurementButtonWrap": "ContactSection-module__PXWClq__measurementButtonWrap",
  "subtitle": "ContactSection-module__PXWClq__subtitle",
  "title": "ContactSection-module__PXWClq__title",
  "titleFirst": "ContactSection-module__PXWClq__titleFirst",
  "titleSecond": "ContactSection-module__PXWClq__titleSecond",
});
}),
"[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContactSection",
    ()=>ContactSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/index.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/ActionButtons/ActionButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/context/FormContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$contact$2d$form$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/contact-form.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/ContactSection/ContactSection.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const UPLOADS_BASE = API_URL.replace(/\/api\/v1\/?$/, '');
const DEFAULT_BLOCK = {
    title: 'Готовы начать проект?',
    subtitle: 'Оставьте заявку и получите бесплатную консультацию специалиста'
};
function resolveBackgroundImageUrl(url) {
    if (!url?.trim()) return null;
    if (url.startsWith('http')) return url;
    return `${UPLOADS_BASE}${url.startsWith('/') ? '' : '/'}${url}`;
}
const ContactSection = ()=>{
    _s();
    const { measurementModal, callbackModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const [block, setBlock] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_BLOCK);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ContactSection.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$contact$2d$form$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getContactFormBlock"])().then(setBlock).catch({
                "ContactSection.useEffect": ()=>{}
            }["ContactSection.useEffect"]);
        }
    }["ContactSection.useEffect"], []);
    const backgroundImageUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactSection.useMemo[backgroundImageUrl]": ()=>resolveBackgroundImageUrl(block.backgroundImage ?? null)
    }["ContactSection.useMemo[backgroundImageUrl]"], [
        block.backgroundImage
    ]);
    const backgroundOpacity = block.backgroundOpacity != null ? block.backgroundOpacity : 0.5;
    const sectionStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactSection.useMemo[sectionStyle]": ()=>{
            if (!backgroundImageUrl) return undefined;
            const safeUrl = backgroundImageUrl.replace(/'/g, "\\'");
            return {
                '--contact-bg-image': `url('${safeUrl}')`,
                '--contact-bg-opacity': String(backgroundOpacity)
            };
        }
    }["ContactSection.useMemo[sectionStyle]"], [
        backgroundImageUrl,
        backgroundOpacity
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contact,
        style: sectionStyle,
        "data-has-bg": !!backgroundImageUrl || undefined,
        children: [
            backgroundImageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].background,
                "aria-hidden": true
            }, void 0, false, {
                fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                lineNumber: 56,
                columnNumber: 29
            }, ("TURBOPACK compile-time value", void 0)) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                            children: (()=>{
                                const spaceIndex = block.title.indexOf(' ');
                                if (spaceIndex === -1) {
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleFirst,
                                        children: block.title
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                                        lineNumber: 63,
                                        columnNumber: 24
                                    }, ("TURBOPACK compile-time value", void 0));
                                }
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleFirst,
                                            children: [
                                                block.title.slice(0, spaceIndex),
                                                " "
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                                            lineNumber: 67,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleSecond,
                                            children: block.title.slice(spaceIndex + 1)
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                                            lineNumber: 68,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true);
                            })()
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                            children: block.subtitle
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actions,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].measurementButtonWrap,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionButton"], {
                                        variant: "measurement",
                                        onClick: measurementModal.open
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                                        lineNumber: 77,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                                    lineNumber: 76,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].callbackLink,
                                    onClick: callbackModal.open,
                                    children: "Заказать обратный звонок"
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                            lineNumber: 75,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ContactSection, "gNHgDUJhtOCwjwSSMFAHTExb2pc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"]
    ];
});
_c = ContactSection;
var _c;
__turbopack_context__.k.register(_c, "ContactSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/ContactSection/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actionButtons": "ProductCard-module__3cykKa__actionButtons",
  "addToCartButton": "ProductCard-module__3cykKa__addToCartButton",
  "badges": "ProductCard-module__3cykKa__badges",
  "cardLink": "ProductCard-module__3cykKa__cardLink",
  "cardVariantChip": "ProductCard-module__3cykKa__cardVariantChip",
  "cardVariantChipActive": "ProductCard-module__3cykKa__cardVariantChipActive",
  "cardVariantChipImg": "ProductCard-module__3cykKa__cardVariantChipImg",
  "cardVariantsSelector": "ProductCard-module__3cykKa__cardVariantsSelector",
  "cartControls": "ProductCard-module__3cykKa__cartControls",
  "cartControlsYellow": "ProductCard-module__3cykKa__cartControlsYellow",
  "cartInfo": "ProductCard-module__3cykKa__cartInfo",
  "category": "ProductCard-module__3cykKa__category",
  "compareButton": "ProductCard-module__3cykKa__compareButton",
  "compareButtonActive": "ProductCard-module__3cykKa__compareButtonActive",
  "compareButtonLoading": "ProductCard-module__3cykKa__compareButtonLoading",
  "componentsBadge": "ProductCard-module__3cykKa__componentsBadge",
  "componentsIconWrapper": "ProductCard-module__3cykKa__componentsIconWrapper",
  "content": "ProductCard-module__3cykKa__content",
  "discountBadge": "ProductCard-module__3cykKa__discountBadge",
  "favoriteButton": "ProductCard-module__3cykKa__favoriteButton",
  "favoriteButtonActive": "ProductCard-module__3cykKa__favoriteButtonActive",
  "finalPrice": "ProductCard-module__3cykKa__finalPrice",
  "hitBadge": "ProductCard-module__3cykKa__hitBadge",
  "image": "ProductCard-module__3cykKa__image",
  "imageContainer": "ProductCard-module__3cykKa__imageContainer",
  "imageDot": "ProductCard-module__3cykKa__imageDot",
  "imageDotActive": "ProductCard-module__3cykKa__imageDotActive",
  "imageDots": "ProductCard-module__3cykKa__imageDots",
  "imageNavButton": "ProductCard-module__3cykKa__imageNavButton",
  "imageSection": "ProductCard-module__3cykKa__imageSection",
  "imageSideLeft": "ProductCard-module__3cykKa__imageSideLeft",
  "imageSideRight": "ProductCard-module__3cykKa__imageSideRight",
  "inCartLabel": "ProductCard-module__3cykKa__inCartLabel",
  "name": "ProductCard-module__3cykKa__name",
  "nameBlock": "ProductCard-module__3cykKa__nameBlock",
  "nameInContent": "ProductCard-module__3cykKa__nameInContent",
  "newBadge": "ProductCard-module__3cykKa__newBadge",
  "oldPrice": "ProductCard-module__3cykKa__oldPrice",
  "partnerBadge": "ProductCard-module__3cykKa__partnerBadge",
  "partnerLogo": "ProductCard-module__3cykKa__partnerLogo",
  "price": "ProductCard-module__3cykKa__price",
  "priceIcon": "ProductCard-module__3cykKa__priceIcon",
  "priceLabel": "ProductCard-module__3cykKa__priceLabel",
  "productCard": "ProductCard-module__3cykKa__productCard",
  "productCardCompact": "ProductCard-module__3cykKa__productCardCompact",
  "productCardCompare": "ProductCard-module__3cykKa__productCardCompare",
  "quantityButton": "ProductCard-module__3cykKa__quantityButton",
  "quantityControls": "ProductCard-module__3cykKa__quantityControls",
  "quantityDisplay": "ProductCard-module__3cykKa__quantityDisplay",
  "quantityValue": "ProductCard-module__3cykKa__quantityValue",
  "rating": "ProductCard-module__3cykKa__rating",
  "ratingValue": "ProductCard-module__3cykKa__ratingValue",
  "removeButton": "ProductCard-module__3cykKa__removeButton",
  "sku": "ProductCard-module__3cykKa__sku",
  "videoBadge": "ProductCard-module__3cykKa__videoBadge",
});
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductCard",
    ()=>ProductCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wallet.js [app-client] (ecmascript) <export default as Wallet>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CompareContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/WishlistContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const ProductCard = ({ product, isCompareMode = false, compact = false, onRemoveFromCompare, partnerLogoUrl = null, showPartnerIconOnCards = true })=>{
    _s();
    const { toggleWishlist, isInWishlist, wishlist } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"])();
    const { toggleCompare, isInCompare, compare, removeFromCompare } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompare"])();
    const { cart, addToCart, updateQuantity, updateCartItemQuantityById } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"])();
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCompareLoading, setIsCompareLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isAddingToCart, setIsAddingToCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentImageIndex, setCurrentImageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [selectedVariantIndex, setSelectedVariantIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const cardVariants = product.cardVariants && product.cardVariants.length > 0 ? product.cardVariants : [];
    const selectedVariant = cardVariants[selectedVariantIndex] ?? null;
    // Отображаемые данные: при выбранном варианте — из варианта, иначе из основного товара
    const displayName = selectedVariant ? selectedVariant.name : product.name;
    const displayPrice = selectedVariant ? selectedVariant.price : product.price;
    const displayOldPrice = selectedVariant ? undefined : product.oldPrice;
    const displayImage = selectedVariant?.image || (product.images?.[0] ?? product.image);
    const productImages = cardVariants.length > 0 ? cardVariants.map((v)=>v.image || product.image).filter(Boolean) : product.images && product.images.length > 0 ? product.images : product.image ? [
        product.image
    ] : [];
    const effectiveImages = productImages.length > 0 ? productImages : [
        product.image
    ].filter(Boolean);
    const hasMultipleImages = effectiveImages.length > 1;
    // Сбрасываем индекс изображения при смене товара
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductCard.useEffect": ()=>{
            setCurrentImageIndex(0);
        }
    }["ProductCard.useEffect"], [
        product.id
    ]);
    // Получаем оригинальный ID товара из API
    const getProductId = ()=>{
        // Используем originalId если он есть, иначе пробуем преобразовать id в string
        if (product.originalId) {
            return product.originalId;
        }
        // Fallback на id как string
        return String(product.id);
    };
    // Получаем ID товара один раз
    const productId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductCard.useMemo[productId]": ()=>getProductId()
    }["ProductCard.useMemo[productId]"], [
        product.id,
        product.originalId
    ]);
    // Используем глобальное состояние напрямую - автоматически обновляется при изменении wishlist/compare
    const isFavorite = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductCard.useMemo[isFavorite]": ()=>isInWishlist(productId)
    }["ProductCard.useMemo[isFavorite]"], [
        isInWishlist,
        productId,
        wishlist
    ]);
    const isInCompareState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductCard.useMemo[isInCompareState]": ()=>isInCompare(productId)
    }["ProductCard.useMemo[isInCompareState]"], [
        isInCompare,
        productId,
        compare
    ]);
    const finalPrice = displayPrice;
    const oldPrice = displayOldPrice;
    const handleFavoriteClick = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        try {
            setIsLoading(true);
            await toggleWishlist(productId);
        // Состояние обновится автоматически через глобальный контекст
        } catch (error) {
            if (error instanceof Error) {
                alert(error.message);
            } else {
                alert('Произошла ошибка при работе с избранным');
            }
        } finally{
            setIsLoading(false);
        }
    };
    const handleCompareClick = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
        if (isCompareLoading) {
            return;
        }
        try {
            setIsCompareLoading(true);
            await toggleCompare(productId);
        // Состояние обновится автоматически через глобальный контекст
        } catch (error) {
            if (error instanceof Error) {
                alert(error.message);
            } else {
                alert('Произошла ошибка при работе с сравнением');
            }
        } finally{
            setIsCompareLoading(false);
        }
    };
    const handleRemoveFromCompare = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        try {
            setIsCompareLoading(true);
            await removeFromCompare(productId);
            // Состояние обновится автоматически через глобальный контекст
            // Вызываем callback для обновления списка на странице сравнения
            if (onRemoveFromCompare) {
                onRemoveFromCompare();
            }
        } catch (error) {
            if (error instanceof Error) {
                alert(error.message);
            } else {
                alert('Произошла ошибка при удалении из сравнения');
            }
        } finally{
            setIsCompareLoading(false);
        }
    };
    const handleAddToCart = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const productId = getProductId();
        const cardVariantId = selectedVariant?.id;
        try {
            setIsAddingToCart(true);
            await addToCart(productId, 1, undefined, undefined, cardVariantId);
        } catch (error) {
            if (error instanceof Error) {
                alert(error.message);
            } else {
                alert('Произошла ошибка при добавлении в корзину');
            }
        } finally{
            setIsAddingToCart(false);
        }
    };
    const handlePreviousImage = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setCurrentImageIndex((prev)=>prev === 0 ? effectiveImages.length - 1 : prev - 1);
        if (cardVariants.length > 0) setSelectedVariantIndex((prev)=>prev === 0 ? cardVariants.length - 1 : prev - 1);
    };
    const handleNextImage = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setCurrentImageIndex((prev)=>prev === effectiveImages.length - 1 ? 0 : prev + 1);
        if (cardVariants.length > 0) setSelectedVariantIndex((prev)=>prev === cardVariants.length - 1 ? 0 : prev + 1);
    };
    const handleImageDotClick = (e, index)=>{
        e.preventDefault();
        e.stopPropagation();
        setCurrentImageIndex(index);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productCard} ${compact ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productCardCompact : ''} ${isCompareMode ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productCardCompare : ''}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: `/product/${product.slug}`,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardLink,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].nameBlock,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].name,
                        children: displayName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                        lineNumber: 202,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                    lineNumber: 201,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageSection,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageSideLeft,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badges,
                                    children: [
                                        product.isFeatured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].hitBadge,
                                            children: "ХИТ"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 207,
                                            columnNumber: 38
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        product.isNew && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].newBadge,
                                            children: "Новинка"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 208,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        product.discount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].discountBadge,
                                            children: [
                                                "-",
                                                product.discount,
                                                "%"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 210,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        product.videoUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoBadge,
                                            title: "Есть видео о товаре",
                                            children: "▶ Видео"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 213,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 206,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                product.isPartnerProduct && showPartnerIconOnCards && product.partnerShowLogoOnCards !== false && (product.partnerLogoUrl ?? partnerLogoUrl) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].partnerBadge,
                                    title: product.partnerShowTooltip !== false ? product.partnerTooltipText?.trim() || `Товар Партнёра : ${product.partnerName || 'Партнёр'}` : undefined,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: product.partnerLogoUrl ?? partnerLogoUrl ?? '',
                                        alt: "Партнёр",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].partnerLogo
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 231,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 222,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 205,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageContainer,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: cardVariants.length > 0 ? displayImage || product.image : effectiveImages[currentImageIndex] || product.image,
                                    alt: displayName,
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].image,
                                    loading: "lazy"
                                }, void 0, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 240,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                hasMultipleImages && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageNavButton,
                                            style: {
                                                left: '0.5rem'
                                            },
                                            onClick: handlePreviousImage,
                                            "aria-label": "Предыдущее изображение",
                                            children: "‹"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 252,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageNavButton,
                                            style: {
                                                right: '0.5rem'
                                            },
                                            onClick: handleNextImage,
                                            "aria-label": "Следующее изображение",
                                            children: "›"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 261,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageDots,
                                            children: effectiveImages.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageDot} ${index === currentImageIndex ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageDotActive : ''}`,
                                                    onClick: (e)=>handleImageDotClick(e, index),
                                                    "aria-label": `Изображение ${index + 1}`
                                                }, index, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 272,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 270,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageSideRight,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionButtons,
                                children: [
                                    isCompareMode ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].removeButton} ${isCompareLoading ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].compareButtonLoading : ''}`,
                                        "aria-label": "Удалить из сравнения",
                                        onClick: handleRemoveFromCompare,
                                        style: {
                                            pointerEvents: isCompareLoading ? 'none' : 'auto'
                                        },
                                        children: "🗑"
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 287,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].compareButton} ${isInCompareState ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].compareButtonActive : ''} ${isCompareLoading ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].compareButtonLoading : ''}`,
                                        "aria-label": isInCompareState ? 'Удалить из сравнения' : 'Добавить в сравнение',
                                        onClick: handleCompareClick,
                                        style: {
                                            pointerEvents: isCompareLoading ? 'none' : 'auto'
                                        },
                                        children: "⚖"
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 297,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].favoriteButton} ${isFavorite ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].favoriteButtonActive : ''}`,
                                        "aria-label": isFavorite ? 'Удалить из избранного' : 'Добавить в избранное',
                                        onClick: handleFavoriteClick,
                                        disabled: isLoading,
                                        children: isFavorite ? '♥' : '♡'
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 307,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                lineNumber: 285,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 284,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                    lineNumber: 204,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                    children: [
                        cardVariants.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardVariantsSelector,
                            onClick: (e)=>e.stopPropagation(),
                            children: cardVariants.map((v, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardVariantChip} ${i === selectedVariantIndex ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardVariantChipActive : ''}`,
                                    onClick: (e)=>{
                                        e.preventDefault();
                                        e.stopPropagation();
                                        setSelectedVariantIndex(i);
                                        setCurrentImageIndex(i);
                                    },
                                    title: v.name,
                                    children: v.image ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: v.image,
                                        alt: "",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardVariantChipImg
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 337,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: v.color || v.size || `${i + 1}`
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 339,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, v.id, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 324,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 322,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].name} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].nameInContent}`,
                            children: displayName
                        }, void 0, false, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 345,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        product.sku && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sku,
                            children: [
                                "Арт. ",
                                product.sku
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 346,
                            columnNumber: 27
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].category,
                            children: product.category
                        }, void 0, false, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 347,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        (product.rating > 0 || (product.reviewsCount ?? 0) > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rating,
                            children: [
                                '★'.repeat(Math.floor(product.rating || 0)),
                                '☆'.repeat(5 - Math.floor(product.rating || 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].ratingValue,
                                    children: [
                                        "(",
                                        product.rating?.toFixed(1) ?? '0',
                                        ")",
                                        (product.reviewsCount ?? 0) > 0 && ` · ${product.reviewsCount}`
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 353,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 350,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].price,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceLabel,
                                    children: "Стоимость:"
                                }, void 0, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 361,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceIcon,
                                    "aria-hidden": true,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__["Wallet"], {
                                        size: 18,
                                        strokeWidth: 2
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                        lineNumber: 363,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 362,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                oldPrice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].oldPrice,
                                    children: [
                                        oldPrice.toLocaleString(),
                                        " ₽"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 365,
                                    columnNumber: 26
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].finalPrice,
                                    children: [
                                        finalPrice.toLocaleString(),
                                        " ₽"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 366,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                            lineNumber: 360,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        (()=>{
                            const selectedVariantId = selectedVariant?.id ?? null;
                            const cartItem = cart.find((item)=>item.productId !== null && item.componentId === null && String(item.productId) === String(productId) && (item.cardVariantId ?? null) === selectedVariantId);
                            const quantity = cartItem ? Number(cartItem.quantity) : 0;
                            const isInCart = quantity > 0;
                            // Проверяем комплектующие этого товара в корзине
                            // Сопоставляем по productId (originalId если есть, иначе id) или по числовому id как fallback
                            const componentItems = cart.filter((item)=>{
                                if (item.componentId === null || item.productId !== null || item.component === null || item.component.product === null) {
                                    return false;
                                }
                                const componentProductId = String(item.component.product.id);
                                // Основное сопоставление: component.product.id должен совпадать с productId
                                // productId это либо originalId (если есть), либо String(id)
                                if (componentProductId === String(productId)) {
                                    return true;
                                }
                                // Fallback: проверяем числовой id на случай несоответствия
                                // (если backend вернул числовой id, а frontend использует originalId)
                                if (componentProductId === String(product.id)) {
                                    return true;
                                }
                                return false;
                            });
                            const componentsTotalQuantity = componentItems.reduce((sum, item)=>sum + Number(item.quantity), 0);
                            const hasComponents = componentsTotalQuantity > 0;
                            if (isInCart) {
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartControls,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartInfo,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inCartLabel,
                                                    children: "В корзине"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 415,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                hasComponents && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].componentsIconWrapper,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].componentsBadge,
                                                        children: componentsTotalQuantity > 99 ? '99+' : componentsTotalQuantity
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                        lineNumber: 418,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 417,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 414,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityControls,
                                            onClick: (e)=>e.stopPropagation(),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityButton,
                                                    onClick: async (e)=>{
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                        if (isAddingToCart) return;
                                                        try {
                                                            const newQuantity = Number(quantity) - 1;
                                                            if (newQuantity < 0) return;
                                                            if (cartItem?.id && selectedVariantId !== undefined) {
                                                                await updateCartItemQuantityById(cartItem.id, newQuantity);
                                                            } else {
                                                                await updateQuantity(productId, newQuantity);
                                                            }
                                                        } catch (error) {
                                                            if (error instanceof Error) {
                                                                alert(error.message);
                                                            } else {
                                                                alert('Произошла ошибка при обновлении количества');
                                                            }
                                                        }
                                                    },
                                                    onMouseDown: (e)=>{
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                    },
                                                    disabled: isAddingToCart,
                                                    children: "−"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 425,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityValue,
                                                    children: quantity
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 456,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityButton,
                                                    onClick: async (e)=>{
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                        if (isAddingToCart) return;
                                                        try {
                                                            const newQuantity = Number(quantity) + 1;
                                                            if (cartItem?.id && selectedVariantId !== undefined) {
                                                                await updateCartItemQuantityById(cartItem.id, newQuantity);
                                                            } else {
                                                                await updateQuantity(productId, newQuantity);
                                                            }
                                                        } catch (error) {
                                                            if (error instanceof Error) {
                                                                alert(error.message);
                                                            } else {
                                                                alert('Произошла ошибка при обновлении количества');
                                                            }
                                                        }
                                                    },
                                                    onMouseDown: (e)=>{
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                    },
                                                    disabled: isAddingToCart,
                                                    children: "+"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                    lineNumber: 457,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 424,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 413,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0));
                            }
                            // Если товара нет в корзине, но есть комплектующие
                            if (hasComponents && !isInCart) {
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartControlsYellow,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartInfo,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inCartLabel,
                                                children: "В корзине"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                lineNumber: 497,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 496,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityDisplay,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityValue,
                                                children: componentsTotalQuantity
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                                lineNumber: 500,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                            lineNumber: 499,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                    lineNumber: 495,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0));
                            }
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].addToCartButton,
                                onClick: handleAddToCart,
                                disabled: isAddingToCart,
                                children: isAddingToCart ? 'Добавление...' : 'В корзину'
                            }, void 0, false, {
                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                                lineNumber: 507,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0));
                        })()
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
                    lineNumber: 320,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
            lineNumber: 200,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx",
        lineNumber: 197,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ProductCard, "mxDl/psDI+sw/ZoGzVLycsOhYVo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompare"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"]
    ];
});
_c = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductCard/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "empty": "ProductsGrid-module__XmqpHa__empty",
  "error": "ProductsGrid-module__XmqpHa__error",
  "grid": "ProductsGrid-module__XmqpHa__grid",
  "gridHeader": "ProductsGrid-module__XmqpHa__gridHeader",
  "gridMobile2": "ProductsGrid-module__XmqpHa__gridMobile2",
  "headerRight": "ProductsGrid-module__XmqpHa__headerRight",
  "loading": "ProductsGrid-module__XmqpHa__loading",
  "productsGrid": "ProductsGrid-module__XmqpHa__productsGrid",
  "sortLabel": "ProductsGrid-module__XmqpHa__sortLabel",
  "sortSelect": "ProductsGrid-module__XmqpHa__sortSelect",
  "sorting": "ProductsGrid-module__XmqpHa__sorting",
  "title": "ProductsGrid-module__XmqpHa__title",
  "totalCount": "ProductsGrid-module__XmqpHa__totalCount",
});
}),
"[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductsGrid",
    ()=>ProductsGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useMobileCatalogColumns$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useMobileCatalogColumns.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const PRODUCTS_PER_PAGE = 20; // 5 строк × 4 столбца
const ProductsGrid = ({ categorySlug, categoryName = 'Каталог', currentPage = 1, onTotalPagesChange, onSortChange })=>{
    _s();
    const [products, setProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [originalProducts, setOriginalProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [sortBy, setSortBy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('default');
    const mobileCatalogColumns = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useMobileCatalogColumns$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMobileCatalogColumns"])();
    const [partnerSettings, setPartnerSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        partnerLogoUrl: null,
        showPartnerIconOnCards: true
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsGrid.useEffect": ()=>{
            const fetchProducts = {
                "ProductsGrid.useEffect.fetchProducts": async ()=>{
                    if (!categorySlug) {
                        setLoading(false);
                        return;
                    }
                    try {
                        setLoading(true);
                        setError(null);
                        // Для slug "all" используем специальный endpoint для всех товаров
                        const endpoint = categorySlug === 'all' ? `${API_URL}/products/catalog/all` : `${API_URL}/products/category/${categorySlug}`;
                        const response = await fetch(endpoint);
                        if (!response.ok) {
                            throw new Error('Не удалось загрузить товары');
                        }
                        const data = await response.json();
                        // Преобразуем API-формат в формат Product для компонента
                        const mappedProducts = data.products.map({
                            "ProductsGrid.useEffect.fetchProducts.mappedProducts": (p, index)=>({
                                    id: index + 1,
                                    originalId: p.id,
                                    slug: p.slug,
                                    name: p.name,
                                    sku: p.sku || undefined,
                                    description: p.description || undefined,
                                    price: parseFloat(p.price),
                                    oldPrice: p.comparePrice ? parseFloat(p.comparePrice) : undefined,
                                    image: p.images[0] || '/images/products/door-placeholder.jpg',
                                    images: p.images,
                                    category: p.category.name,
                                    categoryId: parseInt(p.category.id) || undefined,
                                    rating: p.rating ?? 0,
                                    reviewsCount: p.reviewsCount ?? 0,
                                    isNew: p.isNew,
                                    isFeatured: p.isFeatured,
                                    isPartnerProduct: p.isPartnerProduct ?? !!p.partner,
                                    partnerLogoUrl: p.partner?.logoUrl ?? null,
                                    partnerShowLogoOnCards: p.partner?.showLogoOnCards ?? true,
                                    partnerName: p.partner?.name ?? null,
                                    partnerTooltipText: p.partner?.tooltipText ?? null,
                                    partnerShowTooltip: p.partner?.showTooltip ?? true,
                                    inStock: p.stock > 0,
                                    discount: p.comparePrice ? Math.round((parseFloat(p.comparePrice) - parseFloat(p.price)) / parseFloat(p.comparePrice) * 100) : undefined,
                                    // Сохраняем дополнительные данные для сортировки
                                    sortOrder: p.sortOrder ?? 0,
                                    createdAt: p.createdAt ? new Date(p.createdAt).getTime() : Date.now(),
                                    videoUrl: p.videoUrl ?? undefined,
                                    cardVariants: p.cardVariants?.map({
                                        "ProductsGrid.useEffect.fetchProducts.mappedProducts": (v)=>({
                                                id: v.id,
                                                name: v.name,
                                                price: typeof v.price === 'string' ? parseFloat(v.price) : v.price,
                                                image: v.image ?? undefined,
                                                size: v.size ?? undefined,
                                                color: v.color ?? undefined,
                                                extraOption: v.extraOption ?? undefined,
                                                sortOrder: v.sortOrder
                                            })
                                    }["ProductsGrid.useEffect.fetchProducts.mappedProducts"])
                                })
                        }["ProductsGrid.useEffect.fetchProducts.mappedProducts"]);
                        setOriginalProducts(mappedProducts);
                        setProducts(mappedProducts);
                    } catch (err) {
                        setError(err instanceof Error ? err.message : 'Произошла ошибка');
                    } finally{
                        setLoading(false);
                    }
                }
            }["ProductsGrid.useEffect.fetchProducts"];
            fetchProducts();
            // Сбрасываем сортировку при изменении категории
            setSortBy('default');
        }
    }["ProductsGrid.useEffect"], [
        categorySlug
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsGrid.useEffect": ()=>{
            const fetchPartnerSettings = {
                "ProductsGrid.useEffect.fetchPartnerSettings": async ()=>{
                    try {
                        const res = await fetch(`${API_URL}/home/partner-products`);
                        if (res.ok) {
                            const data = await res.json();
                            setPartnerSettings({
                                partnerLogoUrl: data.partnerLogoUrl ?? null,
                                showPartnerIconOnCards: data.showPartnerIconOnCards ?? true
                            });
                        }
                    } catch  {
                    // ignore
                    }
                }
            }["ProductsGrid.useEffect.fetchPartnerSettings"];
            fetchPartnerSettings();
        }
    }["ProductsGrid.useEffect"], []);
    // Функция сортировки товаров
    const sortProducts = (productsToSort, sortOption)=>{
        const sorted = [
            ...productsToSort
        ];
        switch(sortOption){
            case 'price-asc':
                return sorted.sort((a, b)=>a.price - b.price);
            case 'price-desc':
                return sorted.sort((a, b)=>b.price - a.price);
            case 'name-asc':
                return sorted.sort((a, b)=>a.name.localeCompare(b.name, 'ru'));
            case 'name-desc':
                return sorted.sort((a, b)=>b.name.localeCompare(a.name, 'ru'));
            case 'new':
                return sorted.sort((a, b)=>{
                    // Сначала новые товары (isNew), затем по дате создания
                    if (a.isNew !== b.isNew) {
                        return a.isNew ? -1 : 1;
                    }
                    return (b.createdAt || 0) - (a.createdAt || 0);
                });
            case 'rating':
                return sorted.sort((a, b)=>(b.rating || 0) - (a.rating || 0));
            case 'default':
            default:
                // Сортировка по sortOrder (из админки), затем по дате создания
                return sorted.sort((a, b)=>{
                    const sortOrderA = a.sortOrder ?? 0;
                    const sortOrderB = b.sortOrder ?? 0;
                    if (sortOrderA !== sortOrderB) {
                        return sortOrderA - sortOrderB;
                    }
                    return (b.createdAt || 0) - (a.createdAt || 0);
                });
        }
    };
    // Применяем сортировку при изменении sortBy или originalProducts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsGrid.useEffect": ()=>{
            const sorted = sortProducts(originalProducts, sortBy);
            setProducts(sorted);
        }
    }["ProductsGrid.useEffect"], [
        sortBy,
        originalProducts
    ]);
    // Пагинация - вычисляем до условных возвратов
    const totalPages = Math.ceil(products.length / PRODUCTS_PER_PAGE);
    const startIndex = (currentPage - 1) * PRODUCTS_PER_PAGE;
    const endIndex = startIndex + PRODUCTS_PER_PAGE;
    const currentProducts = products.slice(startIndex, endIndex);
    // Передаём количество страниц в родительский компонент
    // Этот useEffect должен быть до условных return, чтобы соблюдать правила хуков
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsGrid.useEffect": ()=>{
            onTotalPagesChange?.(totalPages);
        }
    }["ProductsGrid.useEffect"], [
        totalPages,
        onTotalPagesChange
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridHeader,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: categoryName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 268,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 267,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading,
                    children: "Загрузка товаров..."
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 270,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
            lineNumber: 266,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridHeader,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: categoryName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 279,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 278,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                    children: error
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 281,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
            lineNumber: 277,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (products.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridHeader,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: categoryName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 290,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 289,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
                    children: "Товары не найдены"
                }, void 0, false, {
                    fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                    lineNumber: 292,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
            lineNumber: 288,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridHeader,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: categoryName
                    }, void 0, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 300,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerRight,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].totalCount,
                                children: [
                                    products.length,
                                    ' ',
                                    products.length === 1 ? 'товар' : products.length < 5 ? 'товара' : 'товаров'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                lineNumber: 302,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sorting,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "sort-select",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sortLabel,
                                        children: "Сортировка:"
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                        lineNumber: 307,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        id: "sort-select",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sortSelect,
                                        value: sortBy,
                                        onChange: (e)=>{
                                            setSortBy(e.target.value);
                                            // Сбрасываем на первую страницу при изменении сортировки
                                            onSortChange?.();
                                            window.scrollTo({
                                                top: 0,
                                                behavior: 'smooth'
                                            });
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "default",
                                                children: "По умолчанию"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 321,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "price-asc",
                                                children: "По цене (сначала дешевые)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 322,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "price-desc",
                                                children: "По цене (сначала дорогие)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 323,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "name-asc",
                                                children: "По названию (А-Я)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 324,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "name-desc",
                                                children: "По названию (Я-А)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 325,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "new",
                                                children: "По новизне"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 326,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "rating",
                                                children: "По рейтингу"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                                lineNumber: 327,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                        lineNumber: 310,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                                lineNumber: 306,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 301,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                lineNumber: 299,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid} ${mobileCatalogColumns === 2 ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridMobile2 : ''}`,
                children: currentProducts.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                        product: product,
                        partnerLogoUrl: partnerSettings.partnerLogoUrl,
                        showPartnerIconOnCards: partnerSettings.showPartnerIconOnCards
                    }, product.id, false, {
                        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                        lineNumber: 335,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
                lineNumber: 333,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx",
        lineNumber: 298,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ProductsGrid, "zuEMyIMgDWw6P60QEKQhzTwdCzE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useMobileCatalogColumns$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMobileCatalogColumns"]
    ];
});
_c = ProductsGrid;
var _c;
__turbopack_context__.k.register(_c, "ProductsGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/views/catalog/ui/ProductsGrid/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductsGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductsGrid.tsx [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "container": "FeaturedProducts-module__kSO60G__container",
  "empty": "FeaturedProducts-module__kSO60G__empty",
  "featured": "FeaturedProducts-module__kSO60G__featured",
  "header": "FeaturedProducts-module__kSO60G__header",
  "loading": "FeaturedProducts-module__kSO60G__loading",
  "productsGrid": "FeaturedProducts-module__kSO60G__productsGrid",
  "subtitle": "FeaturedProducts-module__kSO60G__subtitle",
  "title": "FeaturedProducts-module__kSO60G__title",
  "viewAllButton": "FeaturedProducts-module__kSO60G__viewAllButton",
});
}),
"[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FeaturedProducts",
    ()=>FeaturedProducts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/views/catalog/ui/ProductsGrid/ProductCard/ProductCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function mapApiProductToProduct(p, index) {
    const price = parseFloat(p.price);
    const comparePrice = p.comparePrice ? parseFloat(p.comparePrice) : null;
    return {
        id: index + 1,
        originalId: p.id,
        slug: p.slug,
        name: p.name,
        sku: p.sku || undefined,
        description: p.description || undefined,
        price,
        oldPrice: comparePrice ?? undefined,
        image: p.images[0] || '',
        images: p.images,
        category: p.category.name,
        categoryId: parseInt(p.category.id, 10) || undefined,
        rating: p.rating ?? 0,
        reviewsCount: p.reviewsCount ?? 0,
        isNew: p.isNew,
        isFeatured: p.isFeatured,
        isPartnerProduct: p.isPartnerProduct ?? !!p.partner,
        partnerLogoUrl: p.partner?.logoUrl ?? null,
        partnerShowLogoOnCards: p.partner?.showLogoOnCards ?? true,
        partnerName: p.partner?.name ?? null,
        partnerTooltipText: p.partner?.tooltipText ?? null,
        partnerShowTooltip: p.partner?.showTooltip ?? true,
        inStock: p.stock > 0,
        discount: comparePrice && comparePrice > price ? Math.round((comparePrice - price) / comparePrice * 100) : undefined,
        sortOrder: p.sortOrder ?? 0,
        createdAt: p.createdAt ? new Date(p.createdAt).getTime() : Date.now(),
        videoUrl: p.videoUrl ?? undefined
    };
}
const defaultBlock = {
    title: 'Популярные товары',
    subtitle: 'Товары, которые выбирают наши клиенты',
    limit: 8,
    primaryFilter: 'featured',
    secondaryOrder: 'sort_order'
};
const FeaturedProducts = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [products, setProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [block, setBlock] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultBlock);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [partnerSettings, setPartnerSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        partnerLogoUrl: null,
        showPartnerIconOnCards: true
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FeaturedProducts.useEffect": ()=>{
            const fetchBlock = {
                "FeaturedProducts.useEffect.fetchBlock": async ()=>{
                    try {
                        const res = await fetch(`${API_URL}/home/featured-products`);
                        if (res.ok) {
                            const data = await res.json();
                            setBlock({
                                ...defaultBlock,
                                ...data,
                                primaryFilter: data.primaryFilter ?? 'featured',
                                secondaryOrder: data.secondaryOrder ?? 'sort_order'
                            });
                        }
                    } catch  {
                    // используем defaultBlock
                    }
                }
            }["FeaturedProducts.useEffect.fetchBlock"];
            fetchBlock();
        }
    }["FeaturedProducts.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FeaturedProducts.useEffect": ()=>{
            const fetchPartnerSettings = {
                "FeaturedProducts.useEffect.fetchPartnerSettings": async ()=>{
                    try {
                        const res = await fetch(`${API_URL}/home/partner-products`);
                        if (res.ok) {
                            const data = await res.json();
                            setPartnerSettings({
                                partnerLogoUrl: data.partnerLogoUrl ?? null,
                                showPartnerIconOnCards: data.showPartnerIconOnCards ?? true
                            });
                        }
                    } catch  {
                    // ignore
                    }
                }
            }["FeaturedProducts.useEffect.fetchPartnerSettings"];
            fetchPartnerSettings();
        }
    }["FeaturedProducts.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FeaturedProducts.useEffect": ()=>{
            const fetchFeatured = {
                "FeaturedProducts.useEffect.fetchFeatured": async ()=>{
                    try {
                        setLoading(true);
                        const params = new URLSearchParams({
                            limit: String(block.limit),
                            primaryFilter: block.primaryFilter,
                            secondaryOrder: block.secondaryOrder
                        });
                        const response = await fetch(`${API_URL}/products/featured?${params}`);
                        if (!response.ok) return;
                        const data = await response.json();
                        const mapped = (data.products || []).map({
                            "FeaturedProducts.useEffect.fetchFeatured.mapped": (p, i)=>mapApiProductToProduct(p, i)
                        }["FeaturedProducts.useEffect.fetchFeatured.mapped"]);
                        setProducts(mapped);
                    } catch  {
                        setProducts([]);
                    } finally{
                        setLoading(false);
                    }
                }
            }["FeaturedProducts.useEffect.fetchFeatured"];
            fetchFeatured();
        }
    }["FeaturedProducts.useEffect"], [
        block.limit,
        block.primaryFilter,
        block.secondaryOrder
    ]);
    const handleViewAll = ()=>{
        router.push('/catalog');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].featured,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                                    children: block.title
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                                    lineNumber: 181,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                                    children: block.subtitle
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                                    lineNumber: 182,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                            lineNumber: 180,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].viewAllButton,
                            onClick: handleViewAll,
                            children: "Смотреть все →"
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                            lineNumber: 184,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                    lineNumber: 179,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading,
                    children: "Загрузка..."
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                    lineNumber: 190,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)) : products.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productsGrid,
                    children: products.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$catalog$2f$ui$2f$ProductsGrid$2f$ProductCard$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                            product: product,
                            partnerLogoUrl: partnerSettings.partnerLogoUrl,
                            showPartnerIconOnCards: partnerSettings.showPartnerIconOnCards
                        }, product.originalId ?? product.id, false, {
                            fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                            lineNumber: 194,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)))
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                    lineNumber: 192,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
                    children: "Популярных товаров пока нет"
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
                    lineNumber: 203,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
            lineNumber: 178,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx",
        lineNumber: 177,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(FeaturedProducts, "TsJfUvFGcakTW9MigEZ3eNBzcVA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = FeaturedProducts;
var _c;
__turbopack_context__.k.register(_c, "FeaturedProducts");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/FeaturedProducts/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/HeroSection/HeroSection.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "buttons": "HeroSection-module__h8_9vq__buttons",
  "container": "HeroSection-module__h8_9vq__container",
  "feature": "HeroSection-module__h8_9vq__feature",
  "featureIcon": "HeroSection-module__h8_9vq__featureIcon",
  "featureIconImg": "HeroSection-module__h8_9vq__featureIconImg",
  "features": "HeroSection-module__h8_9vq__features",
  "hero": "HeroSection-module__h8_9vq__hero",
  "heroButton": "HeroSection-module__h8_9vq__heroButton",
  "imagePlaceholder": "HeroSection-module__h8_9vq__imagePlaceholder",
  "imageText": "HeroSection-module__h8_9vq__imageText",
  "imageWrapper": "HeroSection-module__h8_9vq__imageWrapper",
  "leftPart": "HeroSection-module__h8_9vq__leftPart",
  "slideDot": "HeroSection-module__h8_9vq__slideDot",
  "slideDotActive": "HeroSection-module__h8_9vq__slideDotActive",
  "slideDots": "HeroSection-module__h8_9vq__slideDots",
  "slideshow": "HeroSection-module__h8_9vq__slideshow",
  "slideshowSlide": "HeroSection-module__h8_9vq__slideshowSlide",
  "slideshowTrack": "HeroSection-module__h8_9vq__slideshowTrack",
  "slideshowTrackNoTransition": "HeroSection-module__h8_9vq__slideshowTrackNoTransition",
  "subtitle": "HeroSection-module__h8_9vq__subtitle",
  "title": "HeroSection-module__h8_9vq__title",
  "titleAccent": "HeroSection-module__h8_9vq__titleAccent",
});
}),
"[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeroSection",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/ActionButtons/ActionButton.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/HeroSection/HeroSection.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const DEFAULT_DATA = {
    block: {
        titleMain: 'Создаем интерьеры мечты',
        titleAccent: 'в Мурманске',
        subtitle: 'Мебель на заказ, ремонт под ключ, двери входные и межкомнатные, натяжные потолки, жалюзи, мягкая мебель, кровати, матрасы .....',
        slideShowMode: 'auto',
        slideGap: 16
    },
    slides: [],
    features: [
        {
            id: '1',
            icon: '🏭',
            title: 'Собственное производство',
            sortOrder: 0
        },
        {
            id: '2',
            icon: '📐',
            title: 'Бесплатный замер',
            sortOrder: 1
        },
        {
            id: '3',
            icon: '🛡️',
            title: 'Гарантия 3 года',
            sortOrder: 2
        },
        {
            id: '4',
            icon: '⚡',
            title: 'Сроки от 1 дня',
            sortOrder: 3
        }
    ]
};
const SLIDE_INTERVAL_MS = 5000;
const HeroSection = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const slideshowRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_DATA);
    const [slideIndex, setSlideIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [noTransition, setNoTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [viewportWidth, setViewportWidth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const mode = data.block.slideShowMode ?? 'auto';
    const count = data.slides.length;
    const isStatic = mode === 'static';
    const isCarousel = count > 1 && !isStatic;
    const displaySlides = isCarousel ? [
        ...data.slides,
        data.slides[0]
    ] : data.slides;
    const displayCount = displaySlides.length;
    const showDots = count > 1 && (mode === 'auto' || mode === 'manual');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeroSection.useEffect": ()=>{
            fetch(`${API_URL}/home/hero`).then({
                "HeroSection.useEffect": (res)=>res.ok ? res.json() : null
            }["HeroSection.useEffect"]).then({
                "HeroSection.useEffect": (d)=>{
                    if (d?.block) setData(d);
                }
            }["HeroSection.useEffect"]).catch({
                "HeroSection.useEffect": ()=>{}
            }["HeroSection.useEffect"]);
        }
    }["HeroSection.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeroSection.useEffect": ()=>{
            if (data.slides.length === 0) return;
            const el = slideshowRef.current;
            if (!el) return;
            const ro = new ResizeObserver({
                "HeroSection.useEffect": (entries)=>{
                    const { width } = entries[0]?.contentRect ?? {
                        width: 0
                    };
                    setViewportWidth(width);
                }
            }["HeroSection.useEffect"]);
            ro.observe(el);
            setViewportWidth(el.getBoundingClientRect().width);
            return ({
                "HeroSection.useEffect": ()=>ro.disconnect()
            })["HeroSection.useEffect"];
        }
    }["HeroSection.useEffect"], [
        data.slides.length
    ]);
    const goNext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "HeroSection.useCallback[goNext]": ()=>{
            if (count <= 1 || isStatic) return;
            setSlideIndex({
                "HeroSection.useCallback[goNext]": (i)=>(i + 1) % displayCount
            }["HeroSection.useCallback[goNext]"]);
        }
    }["HeroSection.useCallback[goNext]"], [
        count,
        displayCount,
        isStatic
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeroSection.useEffect": ()=>{
            if (count <= 1 || mode !== 'auto' || isStatic) return;
            const timer = setInterval(goNext, SLIDE_INTERVAL_MS);
            return ({
                "HeroSection.useEffect": ()=>clearInterval(timer)
            })["HeroSection.useEffect"];
        }
    }["HeroSection.useEffect"], [
        count,
        mode,
        isStatic,
        goNext
    ]);
    const handleTransitionEnd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "HeroSection.useCallback[handleTransitionEnd]": ()=>{
            if (slideIndex === count) {
                setNoTransition(true);
                setSlideIndex(0);
                requestAnimationFrame({
                    "HeroSection.useCallback[handleTransitionEnd]": ()=>{
                        requestAnimationFrame({
                            "HeroSection.useCallback[handleTransitionEnd]": ()=>setNoTransition(false)
                        }["HeroSection.useCallback[handleTransitionEnd]"]);
                    }
                }["HeroSection.useCallback[handleTransitionEnd]"]);
            }
        }
    }["HeroSection.useCallback[handleTransitionEnd]"], [
        slideIndex,
        count
    ]);
    const imageUrl = (url)=>{
        if (!url) return '';
        if (url.startsWith('http')) return url;
        const base = API_URL.replace(/\/api\/v1\/?$/, '');
        return `${base}${url.startsWith('/') ? '' : '/'}${url}`;
    };
    const SLIDE_GAP_PX = data.block.slideGap ?? 16;
    const SLIDE_WIDTH_RATIO = 0.75;
    const hasSize = viewportWidth > 0;
    const slideWidthPx = hasSize ? viewportWidth * SLIDE_WIDTH_RATIO : 300;
    const slideStep = slideWidthPx + SLIDE_GAP_PX;
    const trackWidth = isCarousel ? `${displayCount * slideWidthPx + (displayCount - 1) * SLIDE_GAP_PX}px` : '100%';
    const slideWidth = isCarousel ? `${slideWidthPx}px` : '100%';
    const centerOffset = hasSize ? viewportWidth * 0.5 - slideWidthPx * 0.5 : 0;
    const effectiveIndex = isStatic ? 0 : slideIndex;
    const translatePx = isCarousel ? centerOffset - effectiveIndex * slideStep : 0;
    const translateOffset = `translateX(${translatePx}px)`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].hero,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftPart,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                            children: [
                                data.block.titleMain,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleAccent,
                                    children: [
                                        " ",
                                        data.block.titleAccent
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                    lineNumber: 134,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                            lineNumber: 132,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                            children: data.block.subtitle
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                            lineNumber: 136,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].buttons,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                onClick: ()=>router.push('/constructor'),
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].measurement} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroButton}`,
                                "data-action-button": "measurement",
                                children: "Рассчитать стоимость"
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                lineNumber: 138,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                            lineNumber: 137,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].features,
                            children: data.features.map((f)=>{
                                const icon = f.icon?.startsWith('http') && !f.icon.includes('/uploads/') ? f.icon.replace(/^https?:\/\/[^/]+/, '') : f.icon;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].feature,
                                    children: [
                                        icon && icon.includes('/uploads/') ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: imageUrl(icon),
                                            alt: "",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].featureIconImg
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                            lineNumber: 156,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)) : icon ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].featureIcon,
                                            children: icon
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                            lineNumber: 158,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)) : null,
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: f.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                            lineNumber: 160,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, f.id, true, {
                                    fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                    lineNumber: 154,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0));
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                            lineNumber: 147,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                    lineNumber: 131,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageWrapper,
                    children: data.slides.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].slideshow,
                        ref: slideshowRef,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].slideshowTrack} ${noTransition ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].slideshowTrackNoTransition : ''}`,
                                style: {
                                    gap: `${SLIDE_GAP_PX}px`,
                                    transform: translateOffset,
                                    width: trackWidth
                                },
                                onTransitionEnd: handleTransitionEnd,
                                children: displaySlides.map((slide, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].slideshowSlide,
                                        style: {
                                            backgroundImage: `url(${imageUrl(slide.imageUrl)})`,
                                            flex: `0 0 ${slideWidth}`
                                        }
                                    }, isCarousel && i === count ? `${slide.id}-clone` : slide.id, false, {
                                        fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                        lineNumber: 180,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                lineNumber: 170,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            showDots && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].slideDots,
                                "aria-label": "Выбор слайда",
                                children: data.slides.map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].slideDot} ${effectiveIndex % count === i ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].slideDotActive : ''}`,
                                        "aria-label": `Слайд ${i + 1}`,
                                        "aria-pressed": effectiveIndex % count === i,
                                        onClick: ()=>mode === 'manual' && setSlideIndex(i)
                                    }, data.slides[i].id, false, {
                                        fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                        lineNumber: 193,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                                lineNumber: 191,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                        lineNumber: 169,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imagePlaceholder,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageText,
                            children: "3D визуализация интерьера"
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                            lineNumber: 207,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                        lineNumber: 206,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
                    lineNumber: 167,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
            lineNumber: 130,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx",
        lineNumber: 129,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(HeroSection, "J1AyH3z78ylNUThlunELmL33rs4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = HeroSection;
var _c;
__turbopack_context__.k.register(_c, "HeroSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/HeroSection/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/ServicesSection/ServicesSection.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "container": "ServicesSection-module__0RAjLq__container",
  "feature": "ServicesSection-module__0RAjLq__feature",
  "header": "ServicesSection-module__0RAjLq__header",
  "price": "ServicesSection-module__0RAjLq__price",
  "serviceButton": "ServicesSection-module__0RAjLq__serviceButton",
  "serviceCard": "ServicesSection-module__0RAjLq__serviceCard",
  "serviceContent": "ServicesSection-module__0RAjLq__serviceContent",
  "serviceDescription": "ServicesSection-module__0RAjLq__serviceDescription",
  "serviceFeatures": "ServicesSection-module__0RAjLq__serviceFeatures",
  "serviceFooter": "ServicesSection-module__0RAjLq__serviceFooter",
  "serviceImage": "ServicesSection-module__0RAjLq__serviceImage",
  "serviceTitle": "ServicesSection-module__0RAjLq__serviceTitle",
  "services": "ServicesSection-module__0RAjLq__services",
  "servicesGrid": "ServicesSection-module__0RAjLq__servicesGrid",
  "subtitle": "ServicesSection-module__0RAjLq__subtitle",
  "title": "ServicesSection-module__0RAjLq__title",
});
}),
"[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ServicesSection",
    ()=>ServicesSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/ServicesSection/ServicesSection.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const UPLOADS_BASE = API_URL.replace(/\/api\/v1\/?$/, '');
const DEFAULT_DATA = {
    block: {
        title: 'Комплексные решения',
        subtitle: 'Полный цикл услуг для вашего комфорта'
    },
    items: []
};
const ServicesSection = ()=>{
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_DATA);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ServicesSection.useEffect": ()=>{
            fetch(`${API_URL}/home/services`).then({
                "ServicesSection.useEffect": (res)=>res.ok ? res.json() : null
            }["ServicesSection.useEffect"]).then({
                "ServicesSection.useEffect": (d)=>{
                    if (d?.block) setData(d);
                }
            }["ServicesSection.useEffect"]).catch({
                "ServicesSection.useEffect": ()=>{}
            }["ServicesSection.useEffect"]);
        }
    }["ServicesSection.useEffect"], []);
    const imageUrl = (url)=>{
        if (!url) return '';
        if (url.startsWith('http')) return url;
        return `${UPLOADS_BASE}${url.startsWith('/') ? '' : '/'}${url}`;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].services,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                            children: data.block.title
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                            children: data.block.subtitle
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].servicesGrid,
                    children: data.items.map((service)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceCard,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceImage,
                                    style: service.imageUrl ? {
                                        backgroundImage: `url(${imageUrl(service.imageUrl)})`
                                    } : undefined
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                    lineNumber: 62,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceContent,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceTitle,
                                            children: service.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                            lineNumber: 71,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceDescription,
                                            children: service.description
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                            lineNumber: 72,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceFeatures,
                                            children: service.features.map((feature, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].feature,
                                                    children: feature
                                                }, index, false, {
                                                    fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                                    lineNumber: 75,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                            lineNumber: 73,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceFooter,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].price,
                                                    children: service.price
                                                }, void 0, false, {
                                                    fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                                    lineNumber: 81,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceButton,
                                                    children: "Подробнее"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                                    lineNumber: 82,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                            lineNumber: 80,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                                    lineNumber: 70,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, service.id, true, {
                            fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                            lineNumber: 61,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)))
                }, void 0, false, {
                    fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
                    lineNumber: 59,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
            lineNumber: 53,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ServicesSection, "FmfJ3JynE/UJNl80sX4VpLFa+sw=");
_c = ServicesSection;
var _c;
__turbopack_context__.k.register(_c, "ServicesSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/ui/ServicesSection/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/index.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// Home widgets exports
__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$HomePage$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/HomePage/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/AdvantagesSection/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/CategoriesGrid/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/ContactSection/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/FeaturedProducts/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/HeroSection/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/ServicesSection/index.ts [app-client] (ecmascript) <locals>");
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/home/HomePage/HomePage.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "homePage": "HomePage-module__fc7LVa__homePage",
});
}),
"[project]/src/widgets/home/HomePage/HomePage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HomePage",
    ()=>HomePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$home$2d$sections$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/home-sections.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/home/index.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/AdvantagesSection/AdvantagesSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/CategoriesGrid/CategoriesGrid.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/ContactSection/ContactSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/FeaturedProducts/FeaturedProducts.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/HeroSection/HeroSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/home/ui/ServicesSection/ServicesSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$HomePage$2f$HomePage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/home/HomePage/HomePage.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const DEFAULT_VISIBILITY = {
    heroVisible: true,
    directionsVisible: true,
    advantagesVisible: true,
    servicesVisible: true,
    featuredProductsVisible: true,
    contactFormVisible: true
};
const HomePage = ()=>{
    _s();
    const [visibility, setVisibility] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_VISIBILITY);
    const loadVisibility = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "HomePage.useCallback[loadVisibility]": async ()=>{
            try {
                const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$home$2d$sections$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHomeSectionsVisibility"])();
                setVisibility(data);
            } catch  {
                setVisibility(DEFAULT_VISIBILITY);
            }
        }
    }["HomePage.useCallback[loadVisibility]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomePage.useEffect": ()=>{
            loadVisibility();
        }
    }["HomePage.useEffect"], [
        loadVisibility
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$HomePage$2f$HomePage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].homePage,
        children: [
            visibility.heroVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$HeroSection$2f$HeroSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeroSection"], {}, void 0, false, {
                fileName: "[project]/src/widgets/home/HomePage/HomePage.tsx",
                lineNumber: 45,
                columnNumber: 34
            }, ("TURBOPACK compile-time value", void 0)),
            visibility.directionsVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$CategoriesGrid$2f$CategoriesGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CategoriesGrid"], {}, void 0, false, {
                fileName: "[project]/src/widgets/home/HomePage/HomePage.tsx",
                lineNumber: 46,
                columnNumber: 40
            }, ("TURBOPACK compile-time value", void 0)),
            visibility.advantagesVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$AdvantagesSection$2f$AdvantagesSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdvantagesSection"], {}, void 0, false, {
                fileName: "[project]/src/widgets/home/HomePage/HomePage.tsx",
                lineNumber: 47,
                columnNumber: 40
            }, ("TURBOPACK compile-time value", void 0)),
            visibility.servicesVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ServicesSection$2f$ServicesSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServicesSection"], {}, void 0, false, {
                fileName: "[project]/src/widgets/home/HomePage/HomePage.tsx",
                lineNumber: 48,
                columnNumber: 38
            }, ("TURBOPACK compile-time value", void 0)),
            visibility.featuredProductsVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$FeaturedProducts$2f$FeaturedProducts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedProducts"], {}, void 0, false, {
                fileName: "[project]/src/widgets/home/HomePage/HomePage.tsx",
                lineNumber: 49,
                columnNumber: 46
            }, ("TURBOPACK compile-time value", void 0)),
            visibility.contactFormVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$home$2f$ui$2f$ContactSection$2f$ContactSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContactSection"], {}, void 0, false, {
                fileName: "[project]/src/widgets/home/HomePage/HomePage.tsx",
                lineNumber: 50,
                columnNumber: 41
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/home/HomePage/HomePage.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(HomePage, "/nVFsXk7hc1JnH8y3UTuqOiNl8w=");
_c = HomePage;
var _c;
__turbopack_context__.k.register(_c, "HomePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_14be3d4e._.js.map