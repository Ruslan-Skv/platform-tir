(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b6ecdeba._.js",
  "static/chunks/src_views_blog_ui_BlogPage_BlogPage_module_f58e4aea.css"
],
    source: "dynamic"
});
