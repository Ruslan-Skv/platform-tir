(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/shared/api/blog.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createBlogComment",
    ()=>createBlogComment,
    "getBlogCategories",
    ()=>getBlogCategories,
    "getBlogPostBySlug",
    ()=>getBlogPostBySlug,
    "getBlogPostBySlugWithGuest",
    ()=>getBlogPostBySlugWithGuest,
    "getBlogPosts",
    ()=>getBlogPosts,
    "toggleBlogPostLike",
    ()=>toggleBlogPostLike
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
async function getBlogPosts(params) {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.set('category', params.category);
    if (params?.search) searchParams.set('search', params.search);
    if (params?.page) searchParams.set('page', String(params.page));
    if (params?.limit) searchParams.set('limit', String(params.limit));
    const res = await fetch(`${API_URL}/blog/posts?${searchParams}`);
    if (!res.ok) throw new Error('Не удалось загрузить записи блога');
    return res.json();
}
async function getBlogPostBySlug(slug) {
    return getBlogPostBySlugWithGuest(slug, ("TURBOPACK compile-time truthy", 1) ? getGuestId() : "TURBOPACK unreachable");
}
async function getBlogCategories() {
    const res = await fetch(`${API_URL}/blog/categories`);
    if (!res.ok) throw new Error('Не удалось загрузить категории блога');
    return res.json();
}
function getAuthHeaders() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const token = localStorage.getItem('admin_token') || localStorage.getItem('user_token');
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
function getGuestId() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let guestId = localStorage.getItem('blog_guest_id');
    if (!guestId) {
        guestId = crypto.randomUUID();
        localStorage.setItem('blog_guest_id', guestId);
    }
    return guestId;
}
async function getBlogPostBySlugWithGuest(slug, guestId) {
    const params = new URLSearchParams();
    if (guestId) params.set('guestId', guestId);
    const url = `${API_URL}/blog/posts/slug/${slug}${params.toString() ? `?${params}` : ''}`;
    const res = await fetch(url, {
        headers: getAuthHeaders()
    });
    if (!res.ok) {
        if (res.status === 404) throw new Error('Запись не найдена');
        throw new Error('Не удалось загрузить запись');
    }
    return res.json();
}
async function toggleBlogPostLike(postId, guestId) {
    const res = await fetch(`${API_URL}/blog/posts/${postId}/like`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            guestId: guestId || getGuestId()
        })
    });
    if (!res.ok) throw new Error('Не удалось поставить лайк');
    return res.json();
}
async function createBlogComment(postId, dto) {
    const res = await fetch(`${API_URL}/blog/posts/${postId}/comments`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(dto)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message || 'Не удалось отправить комментарий');
    }
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/views/blog/ui/BlogPage/BlogPage.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "BlogPage-module__kh88Na__active",
  "blogPage": "BlogPage-module__kh88Na__blogPage",
  "breadcrumbs": "BlogPage-module__kh88Na__breadcrumbs",
  "breadcrumbsList": "BlogPage-module__kh88Na__breadcrumbsList",
  "card": "BlogPage-module__kh88Na__card",
  "cardCategory": "BlogPage-module__kh88Na__cardCategory",
  "cardContent": "BlogPage-module__kh88Na__cardContent",
  "cardExcerpt": "BlogPage-module__kh88Na__cardExcerpt",
  "cardImage": "BlogPage-module__kh88Na__cardImage",
  "cardImagePlaceholder": "BlogPage-module__kh88Na__cardImagePlaceholder",
  "cardLink": "BlogPage-module__kh88Na__cardLink",
  "cardMeta": "BlogPage-module__kh88Na__cardMeta",
  "cardTitle": "BlogPage-module__kh88Na__cardTitle",
  "categoryCount": "BlogPage-module__kh88Na__categoryCount",
  "categoryItem": "BlogPage-module__kh88Na__categoryItem",
  "categoryList": "BlogPage-module__kh88Na__categoryList",
  "content": "BlogPage-module__kh88Na__content",
  "current": "BlogPage-module__kh88Na__current",
  "empty": "BlogPage-module__kh88Na__empty",
  "grid": "BlogPage-module__kh88Na__grid",
  "header": "BlogPage-module__kh88Na__header",
  "loading": "BlogPage-module__kh88Na__loading",
  "main": "BlogPage-module__kh88Na__main",
  "pagination": "BlogPage-module__kh88Na__pagination",
  "paginationButton": "BlogPage-module__kh88Na__paginationButton",
  "paginationInfo": "BlogPage-module__kh88Na__paginationInfo",
  "searchButton": "BlogPage-module__kh88Na__searchButton",
  "searchForm": "BlogPage-module__kh88Na__searchForm",
  "searchInput": "BlogPage-module__kh88Na__searchInput",
  "separator": "BlogPage-module__kh88Na__separator",
  "sidebar": "BlogPage-module__kh88Na__sidebar",
  "sidebarSection": "BlogPage-module__kh88Na__sidebarSection",
  "sidebarTitle": "BlogPage-module__kh88Na__sidebarTitle",
  "subtitle": "BlogPage-module__kh88Na__subtitle",
  "title": "BlogPage-module__kh88Na__title",
});
}),
"[project]/src/views/blog/ui/BlogPage/BlogPage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BlogPage",
    ()=>BlogPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$blog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/blog.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/views/blog/ui/BlogPage/BlogPage.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const BlogPage = ()=>{
    _s();
    const [posts, setPosts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [categories, setCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [totalPages, setTotalPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const loadPosts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BlogPage.useCallback[loadPosts]": async ()=>{
            setLoading(true);
            try {
                const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$blog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBlogPosts"])({
                    category: selectedCategory || undefined,
                    search: search || undefined,
                    page: currentPage,
                    limit: 12
                });
                setPosts(res.data);
                setTotalPages(res.totalPages);
            } catch  {
                setPosts([]);
            } finally{
                setLoading(false);
            }
        }
    }["BlogPage.useCallback[loadPosts]"], [
        currentPage,
        selectedCategory,
        search
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BlogPage.useEffect": ()=>{
            loadPosts();
        }
    }["BlogPage.useEffect"], [
        loadPosts
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BlogPage.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$blog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBlogCategories"])().then(setCategories).catch({
                "BlogPage.useEffect": ()=>setCategories([])
            }["BlogPage.useEffect"]);
        }
    }["BlogPage.useEffect"], []);
    const handlePageChange = (page)=>{
        setCurrentPage(page);
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };
    const formatDate = (dateStr)=>{
        return new Date(dateStr).toLocaleDateString('ru-RU', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
    };
    const getAuthorName = (post)=>{
        const { firstName, lastName } = post.author;
        return [
            firstName,
            lastName
        ].filter(Boolean).join(' ') || 'Автор';
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].blogPage,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].breadcrumbs,
                "aria-label": "Хлебные крошки",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].breadcrumbsList,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    children: "Главная"
                                }, void 0, false, {
                                    fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                    lineNumber: 76,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].separator,
                                    children: "/"
                                }, void 0, false, {
                                    fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                            lineNumber: 75,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].current,
                                children: "Блог"
                            }, void 0, false, {
                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                lineNumber: 80,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                            lineNumber: 79,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                    lineNumber: 74,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: "Блог"
                    }, void 0, false, {
                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                        children: "Полезные статьи, советы и новости от Территории интерьерных решений"
                    }, void 0, false, {
                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                        lineNumber: 87,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sidebar,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sidebarSection,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sidebarTitle,
                                        children: "Категории"
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                        lineNumber: 95,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryList,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryItem} ${!selectedCategory ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].active : ''}`,
                                                    onClick: ()=>{
                                                        setSelectedCategory(null);
                                                        setCurrentPage(1);
                                                    },
                                                    children: "Все записи"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                    lineNumber: 98,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                lineNumber: 97,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryItem} ${selectedCategory === cat.slug ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].active : ''}`,
                                                        onClick: ()=>{
                                                            setSelectedCategory(cat.slug);
                                                            setCurrentPage(1);
                                                        },
                                                        children: [
                                                            cat.name,
                                                            cat._count?.posts != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryCount,
                                                                children: [
                                                                    "(",
                                                                    cat._count.posts,
                                                                    ")"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                                lineNumber: 121,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                        lineNumber: 111,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, cat.id, false, {
                                                    fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                    lineNumber: 110,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                        lineNumber: 96,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sidebarSection,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sidebarTitle,
                                        children: "Поиск"
                                    }, void 0, false, {
                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                        lineNumber: 130,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchForm,
                                        onSubmit: (e)=>{
                                            e.preventDefault();
                                            setCurrentPage(1);
                                            loadPosts();
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "search",
                                                placeholder: "Поиск по блогу...",
                                                value: search,
                                                onChange: (e)=>setSearch(e.target.value),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchInput
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                lineNumber: 139,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "submit",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchButton,
                                                children: "Найти"
                                            }, void 0, false, {
                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                lineNumber: 146,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                        lineNumber: 131,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                        lineNumber: 93,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].main,
                        children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading,
                            children: "Загрузка..."
                        }, void 0, false, {
                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                            lineNumber: 155,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)) : posts.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "Записей пока нет."
                            }, void 0, false, {
                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                lineNumber: 158,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                            lineNumber: 157,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                                    children: posts.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: `/blog/${post.slug}`,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardLink,
                                                children: [
                                                    post.featuredImage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardImage,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                            src: post.featuredImage,
                                                            alt: ""
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                            lineNumber: 168,
                                                            columnNumber: 27
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                        lineNumber: 167,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardImagePlaceholder
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                        lineNumber: 171,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardContent,
                                                        children: [
                                                            post.category && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardCategory,
                                                                children: post.category.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                                lineNumber: 175,
                                                                columnNumber: 27
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardTitle,
                                                                children: post.title
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                                lineNumber: 177,
                                                                columnNumber: 25
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            post.excerpt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardExcerpt,
                                                                children: post.excerpt
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                                lineNumber: 178,
                                                                columnNumber: 42
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardMeta,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: getAuthorName(post)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                                        lineNumber: 180,
                                                                        columnNumber: 27
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: formatDate(post.publishedAt || post.createdAt)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                                        lineNumber: 181,
                                                                        columnNumber: 27
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    post.likeCount != null && post.likeCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: [
                                                                            "❤️ ",
                                                                            post.likeCount
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                                        lineNumber: 183,
                                                                        columnNumber: 29
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                                lineNumber: 179,
                                                                columnNumber: 25
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                        lineNumber: 173,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                                lineNumber: 165,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, post.id, false, {
                                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                            lineNumber: 164,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                    lineNumber: 162,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pagination,
                                    "aria-label": "Пагинация",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].paginationButton,
                                            disabled: currentPage <= 1,
                                            onClick: ()=>handlePageChange(currentPage - 1),
                                            children: "← Назад"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                            lineNumber: 194,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].paginationInfo,
                                            children: [
                                                "Страница ",
                                                currentPage,
                                                " из ",
                                                totalPages
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                            lineNumber: 202,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$views$2f$blog$2f$ui$2f$BlogPage$2f$BlogPage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].paginationButton,
                                            disabled: currentPage >= totalPages,
                                            onClick: ()=>handlePageChange(currentPage + 1),
                                            children: "Вперёд →"
                                        }, void 0, false, {
                                            fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                            lineNumber: 205,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                                    lineNumber: 193,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                        lineNumber: 153,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
                lineNumber: 92,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/views/blog/ui/BlogPage/BlogPage.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(BlogPage, "N7tjj6Z1ZkI1YKJyUx745WtTlJ8=");
_c = BlogPage;
var _c;
__turbopack_context__.k.register(_c, "BlogPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_b6ecdeba._.js.map