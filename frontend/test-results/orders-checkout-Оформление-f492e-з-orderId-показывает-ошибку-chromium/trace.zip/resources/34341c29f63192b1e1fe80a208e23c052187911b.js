(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(site)_checkout_page_module_d0446388.css",
  "static/chunks/src_app_(site)_checkout_9218b609._.js"
],
    source: "dynamic"
});
