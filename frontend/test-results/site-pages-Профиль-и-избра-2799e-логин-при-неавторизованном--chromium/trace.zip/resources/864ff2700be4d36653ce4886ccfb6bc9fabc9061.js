(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/shared/api/cart.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addComponentToCart",
    ()=>addComponentToCart,
    "addServiceToCart",
    ()=>addServiceToCart,
    "addToCart",
    ()=>addToCart,
    "clearCart",
    ()=>clearCart,
    "getCart",
    ()=>getCart,
    "getCartCount",
    ()=>getCartCount,
    "getCartServiceItems",
    ()=>getCartServiceItems,
    "removeCartItemById",
    ()=>removeCartItemById,
    "removeCartServiceItemById",
    ()=>removeCartServiceItemById,
    "removeComponentFromCart",
    ()=>removeComponentFromCart,
    "removeFromCart",
    ()=>removeFromCart,
    "updateCartItemQuantity",
    ()=>updateCartItemQuantity,
    "updateCartItemQuantityById",
    ()=>updateCartItemQuantityById,
    "updateComponentQuantity",
    ()=>updateComponentQuantity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function getAuthToken() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return localStorage.getItem('user_token') || localStorage.getItem('admin_token');
}
function getAuthHeaders() {
    const token = getAuthToken();
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
async function getCart() {
    const response = await fetch(`${API_URL}/cart`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        throw new Error('Ошибка при загрузке корзины');
    }
    return response.json();
}
async function getCartCount() {
    const response = await fetch(`${API_URL}/cart/count`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            return 0;
        }
        throw new Error('Ошибка при загрузке количества товаров в корзине');
    }
    const data = await response.json();
    // API возвращает число напрямую
    return typeof data === 'number' ? data : Number(data) || 0;
}
async function addToCart(productId, quantity = 1, size, openingSide, cardVariantId) {
    const response = await fetch(`${API_URL}/cart/${productId}`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            quantity,
            size,
            openingSide,
            cardVariantId
        })
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Товар не найден');
        }
        throw new Error('Ошибка при добавлении в корзину');
    }
    return response.json();
}
async function updateCartItemQuantityById(itemId, quantity) {
    const response = await fetch(`${API_URL}/cart/item/${itemId}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            quantity: Number(quantity)
        })
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Элемент корзины не найден');
        }
        throw new Error('Ошибка при обновлении количества');
    }
    return response.json();
}
async function updateCartItemQuantity(productId, quantity) {
    const response = await fetch(`${API_URL}/cart/${productId}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            quantity: Number(quantity)
        })
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Товар не найден в корзине');
        }
        throw new Error('Ошибка при обновлении количества');
    }
    return response.json();
}
async function removeCartItemById(itemId) {
    const response = await fetch(`${API_URL}/cart/item/${itemId}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Элемент корзины не найден');
        }
        throw new Error('Ошибка при удалении из корзины');
    }
}
async function removeFromCart(productId) {
    const response = await fetch(`${API_URL}/cart/${productId}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Товар не найден в корзине');
        }
        throw new Error('Ошибка при удалении из корзины');
    }
}
async function clearCart() {
    const response = await fetch(`${API_URL}/cart`, {
        method: 'DELETE',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        throw new Error('Ошибка при очистке корзины');
    }
}
async function addComponentToCart(componentId, quantity = 1) {
    const response = await fetch(`${API_URL}/cart/component/${componentId}`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            quantity
        })
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Комплектующее не найдено');
        }
        throw new Error('Ошибка при добавлении в корзину');
    }
    return response.json();
}
async function updateComponentQuantity(componentId, quantity) {
    const response = await fetch(`${API_URL}/cart/component/${componentId}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            quantity: Number(quantity)
        })
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Комплектующее не найдено в корзине');
        }
        throw new Error('Ошибка при обновлении количества');
    }
    return response.json();
}
async function getCartServiceItems() {
    const response = await fetch(`${API_URL}/cart/service-items`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) return [];
        throw new Error('Ошибка при загрузке услуг в корзине');
    }
    return response.json();
}
async function addServiceToCart(categoryId, payload) {
    const response = await fetch(`${API_URL}/cart/service`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            categoryId,
            ...payload
        })
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        const err = await response.json().catch(()=>({}));
        const msg = err.message;
        const text = Array.isArray(msg) ? msg.join('; ') : msg || 'Ошибка при добавлении в корзину';
        throw new Error(text);
    }
    return response.json();
}
async function removeCartServiceItemById(itemId) {
    const response = await fetch(`${API_URL}/cart/service/${itemId}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        throw new Error('Ошибка при удалении из корзины');
    }
}
async function removeComponentFromCart(componentId) {
    const response = await fetch(`${API_URL}/cart/component/${componentId}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Комплектующее не найдено в корзине');
        }
        throw new Error('Ошибка при удалении из корзины');
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/user-orders.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_APPROVAL_VALID_MINUTES",
    ()=>DEFAULT_APPROVAL_VALID_MINUTES,
    "addCartItemToOrder",
    ()=>addCartItemToOrder,
    "calculateDelivery",
    ()=>calculateDelivery,
    "canResendOrderToEmail",
    ()=>canResendOrderToEmail,
    "cancelOrderByCustomer",
    ()=>cancelOrderByCustomer,
    "formatApprovalCountdown",
    ()=>formatApprovalCountdown,
    "getApprovalRemainingMs",
    ()=>getApprovalRemainingMs,
    "getDeliverySettlements",
    ()=>getDeliverySettlements,
    "getShippingMethods",
    ()=>getShippingMethods,
    "getUserOrder",
    ()=>getUserOrder,
    "getUserOrderByToken",
    ()=>getUserOrderByToken,
    "getUserOrders",
    ()=>getUserOrders,
    "resendOrderToCustomerEmail",
    ()=>resendOrderToCustomerEmail,
    "submitOrderFromCart",
    ()=>submitOrderFromCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function getAuthHeaders() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const token = localStorage.getItem('user_token') || localStorage.getItem('admin_token');
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
const DEFAULT_APPROVAL_VALID_MINUTES = 60;
function getApprovalRemainingMs(approvedAt, approvalValidMinutes = DEFAULT_APPROVAL_VALID_MINUTES) {
    if (!approvedAt) return 0;
    const validUntil = new Date(approvedAt).getTime() + approvalValidMinutes * 60 * 1000;
    return Math.max(0, validUntil - Date.now());
}
function formatApprovalCountdown(remainingMs) {
    const totalSeconds = Math.floor(remainingMs / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}
async function getDeliverySettlements() {
    const res = await fetch(`${API_URL}/orders/delivery-settlements`, {
        headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить список городов');
    return res.json();
}
async function getShippingMethods() {
    const res = await fetch(`${API_URL}/orders/shipping-methods`, {
        headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить способы доставки');
    return res.json();
}
async function calculateDelivery(params) {
    const res = await fetch(`${API_URL}/orders/calculate-delivery`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            subtotal: params.subtotal,
            city: params.city.trim(),
            distanceKm: params.distanceKm,
            deliveryType: params.deliveryType,
            deliveryFloor: params.deliveryFloor,
            deliveryHasElevator: params.deliveryHasElevator
        })
    });
    if (!res.ok) throw new Error('Не удалось рассчитать доставку');
    return res.json();
}
async function submitOrderFromCart(payload) {
    const basePayload = payload && 'deliveryAddress' in payload && payload.deliveryAddress ? {
        deliveryAddress: payload.deliveryAddress,
        deliveryType: payload.deliveryType,
        deliveryFloor: payload.deliveryFloor,
        deliveryHasElevator: payload.deliveryHasElevator,
        distanceKm: payload.distanceKm,
        preferredDeliveryTime: payload.preferredDeliveryTime
    } : payload && 'shippingMethodId' in payload && payload.shippingMethodId ? {
        shippingMethodId: payload.shippingMethodId
    } : {};
    const body = {
        ...basePayload
    };
    if (payload?.cartItemIds && payload.cartItemIds.length > 0) {
        body.cartItemIds = payload.cartItemIds;
    }
    if (payload?.addToApproved === true) {
        body.addToApproved = true;
    }
    if (payload?.addToPendingReview === true) {
        body.addToPendingReview = true;
    }
    const res = await fetch(`${API_URL}/orders/submit-from-cart`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(body)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err?.message || 'Не удалось отправить заказ на проверку');
    }
    return res.json();
}
async function cancelOrderByCustomer(orderId) {
    const res = await fetch(`${API_URL}/orders/${orderId}/cancel-by-customer`, {
        method: 'POST',
        headers: getAuthHeaders()
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err?.message || 'Не удалось отменить проверку');
    }
    return res.json();
}
async function addCartItemToOrder(orderId, cartItemId) {
    const res = await fetch(`${API_URL}/orders/${orderId}/add-cart-item`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            cartItemId
        })
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err?.message || 'Не удалось добавить товар в заказ');
    }
    return res.json();
}
async function getUserOrders() {
    const res = await fetch(`${API_URL}/orders`, {
        headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить заказы');
    return res.json();
}
async function getUserOrder(id) {
    const res = await fetch(`${API_URL}/orders/${id}`, {
        headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить заказ');
    return res.json();
}
async function getUserOrderByToken(token) {
    const res = await fetch(`${API_URL}/orders/view-by-token?token=${encodeURIComponent(token)}`);
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось загрузить заказ');
    }
    return res.json();
}
async function canResendOrderToEmail() {
    const res = await fetch(`${API_URL}/orders/can-resend-order-to-email`, {
        headers: getAuthHeaders()
    });
    if (!res.ok) return false;
    const data = await res.json();
    return !!data.canResend;
}
async function resendOrderToCustomerEmail(token) {
    const res = await fetch(`${API_URL}/orders/resend-to-email`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
            token
        })
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось отправить');
    }
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/contexts/CartContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CartProvider",
    ()=>CartProvider,
    "useCart",
    ()=>useCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/cart.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/user-orders.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
const CartContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function CartProvider({ children }) {
    _s();
    const [cart, setCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [cartServiceItems, setCartServiceItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [serviceOrderCategoryKeys, setServiceOrderCategoryKeys] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [detachedServiceCategoryKeys, setDetachedServiceCategoryKeys] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const lastTokenRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const getOrderServiceCategoryKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[getOrderServiceCategoryKeys]": (orders)=>{
            const activeStatuses = new Set([
                'PENDING_REVIEW',
                'RETURNED_FOR_CORRECTION',
                'APPROVED'
            ]);
            const keys = new Set();
            for (const order of orders){
                if (!activeStatuses.has(order.status)) continue;
                for (const item of order.orderServiceItems ?? []){
                    const slug = item.serviceCatalogItem?.category?.slug;
                    const name = item.categoryName;
                    const key = slug ? `slug:${slug}` : name ? `name:${name}` : null;
                    if (key) keys.add(key);
                }
            }
            return [
                ...keys
            ];
        }
    }["CartProvider.useCallback[getOrderServiceCategoryKeys]"], []);
    const getDetachedServiceCategoryKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[getDetachedServiceCategoryKeys]": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            try {
                const raw = window.sessionStorage.getItem('detached_service_categories');
                const entries = raw ? JSON.parse(raw) : [];
                const keys = new Set();
                for (const entry of entries){
                    if (entry.categorySlug) keys.add(`slug:${entry.categorySlug}`);
                    if (entry.categoryName) keys.add(`name:${entry.categoryName}`);
                }
                return [
                    ...keys
                ];
            } catch  {
                return [];
            }
        }
    }["CartProvider.useCallback[getDetachedServiceCategoryKeys]"], []);
    const getAuthToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[getAuthToken]": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            return localStorage.getItem('user_token') || localStorage.getItem('admin_token');
        }
    }["CartProvider.useCallback[getAuthToken]"], []);
    const refreshCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[refreshCart]": async ()=>{
            try {
                setIsLoading(true);
                const [items, serviceItems, orders] = await Promise.all([
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCart"](),
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCartServiceItems"]().catch({
                        "CartProvider.useCallback[refreshCart]": ()=>[]
                    }["CartProvider.useCallback[refreshCart]"]),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserOrders"])().catch({
                        "CartProvider.useCallback[refreshCart]": ()=>[]
                    }["CartProvider.useCallback[refreshCart]"])
                ]);
                setCart(items);
                setCartServiceItems(serviceItems);
                setServiceOrderCategoryKeys(getOrderServiceCategoryKeys(orders));
                setDetachedServiceCategoryKeys(getDetachedServiceCategoryKeys());
            } catch (error) {
                setCart([]);
                setCartServiceItems([]);
                setServiceOrderCategoryKeys([]);
                setDetachedServiceCategoryKeys([]);
            } finally{
                setIsLoading(false);
            }
        }
    }["CartProvider.useCallback[refreshCart]"], [
        getOrderServiceCategoryKeys,
        getDetachedServiceCategoryKeys
    ]);
    // Счётчик: товары/комплектующие + каждая категория услуг (1 за категорию)
    const count = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CartProvider.useMemo[count]": ()=>{
            const productCount = cart.reduce({
                "CartProvider.useMemo[count].productCount": (sum, item)=>{
                    if (item.product || item.component) return sum + item.quantity;
                    return sum;
                }
            }["CartProvider.useMemo[count].productCount"], 0);
            const serviceCategoryKeys = new Set();
            cartServiceItems.forEach({
                "CartProvider.useMemo[count]": (item)=>{
                    const slug = item.category?.slug;
                    const id = item.serviceCatalogCategoryId || item.category?.id;
                    const name = item.category?.name;
                    const key = slug ? `slug:${slug}` : id ? `id:${id}` : name ? `name:${name}` : null;
                    if (key) serviceCategoryKeys.add(key);
                }
            }["CartProvider.useMemo[count]"]);
            serviceOrderCategoryKeys.forEach({
                "CartProvider.useMemo[count]": (key)=>serviceCategoryKeys.add(key)
            }["CartProvider.useMemo[count]"]);
            detachedServiceCategoryKeys.forEach({
                "CartProvider.useMemo[count]": (key)=>serviceCategoryKeys.delete(key)
            }["CartProvider.useMemo[count]"]);
            const serviceCategoryCount = serviceCategoryKeys.size;
            return Math.round(productCount) + serviceCategoryCount;
        }
    }["CartProvider.useMemo[count]"], [
        cart,
        cartServiceItems,
        serviceOrderCategoryKeys,
        detachedServiceCategoryKeys
    ]);
    const refreshCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[refreshCount]": async ()=>{
            // Обновляем корзину, счетчик обновится автоматически
            await refreshCart();
        }
    }["CartProvider.useCallback[refreshCount]"], [
        refreshCart
    ]);
    // Синхронизация корзины при смене токена (логин/логаут/смена аккаунта)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartProvider.useEffect": ()=>{
            const syncCart = {
                "CartProvider.useEffect.syncCart": async ()=>{
                    const token = getAuthToken();
                    if (!token) {
                        setCart([]);
                        lastTokenRef.current = null;
                        setServiceOrderCategoryKeys([]);
                        return;
                    }
                    if (lastTokenRef.current && lastTokenRef.current !== token) {
                        setCart([]);
                        setServiceOrderCategoryKeys([]);
                    }
                    lastTokenRef.current = token;
                    await refreshCart();
                }
            }["CartProvider.useEffect.syncCart"];
            const handler = {
                "CartProvider.useEffect.handler": ()=>{
                    syncCart().catch({
                        "CartProvider.useEffect.handler": ()=>{
                        // Игнорируем ошибки при загрузке (пользователь может быть не авторизован)
                        }
                    }["CartProvider.useEffect.handler"]);
                }
            }["CartProvider.useEffect.handler"];
            handler();
            window.addEventListener('auth-token-changed', handler);
            const onVisibilityChange = {
                "CartProvider.useEffect.onVisibilityChange": ()=>{
                    if (document.visibilityState === 'visible' && getAuthToken()) {
                        refreshCart().catch({
                            "CartProvider.useEffect.onVisibilityChange": ()=>{}
                        }["CartProvider.useEffect.onVisibilityChange"]);
                    }
                }
            }["CartProvider.useEffect.onVisibilityChange"];
            document.addEventListener('visibilitychange', onVisibilityChange);
            return ({
                "CartProvider.useEffect": ()=>{
                    window.removeEventListener('auth-token-changed', handler);
                    document.removeEventListener('visibilitychange', onVisibilityChange);
                }
            })["CartProvider.useEffect"];
        }
    }["CartProvider.useEffect"], [
        getAuthToken,
        refreshCart
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartProvider.useEffect": ()=>{
            const handleDetachedChange = {
                "CartProvider.useEffect.handleDetachedChange": ()=>{
                    setDetachedServiceCategoryKeys(getDetachedServiceCategoryKeys());
                }
            }["CartProvider.useEffect.handleDetachedChange"];
            handleDetachedChange();
            window.addEventListener('cart-service-detached', handleDetachedChange);
            window.addEventListener('cart-service-restored', handleDetachedChange);
            return ({
                "CartProvider.useEffect": ()=>{
                    window.removeEventListener('cart-service-detached', handleDetachedChange);
                    window.removeEventListener('cart-service-restored', handleDetachedChange);
                }
            })["CartProvider.useEffect"];
        }
    }["CartProvider.useEffect"], [
        getDetachedServiceCategoryKeys
    ]);
    const addToCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[addToCart]": async (productId, quantity = 1, size, openingSide, cardVariantId)=>{
            try {
                const newItem = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addToCart"](productId, quantity, size, openingSide, cardVariantId);
                setCart({
                    "CartProvider.useCallback[addToCart]": (prev)=>{
                        const existingIndex = prev.findIndex({
                            "CartProvider.useCallback[addToCart].existingIndex": (item)=>item.productId != null && item.componentId == null && String(item.productId) === String(productId) && item.size === (size || null) && item.openingSide === (openingSide || null) && (item.cardVariantId ?? null) === (cardVariantId ?? null)
                        }["CartProvider.useCallback[addToCart].existingIndex"]);
                        if (existingIndex >= 0) {
                            const updated = [
                                ...prev
                            ];
                            updated[existingIndex] = newItem;
                            return updated;
                        }
                        return [
                            ...prev,
                            newItem
                        ];
                    }
                }["CartProvider.useCallback[addToCart]"]);
                // Обновляем корзину с сервера для синхронизации
                await refreshCart();
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы добавить товар в корзину');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[addToCart]"], [
        refreshCart
    ]);
    const addServiceToCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[addServiceToCart]": async (categoryId, payload)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addServiceToCart"](categoryId, payload);
                await refreshCart();
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы добавить услуги в корзину');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[addServiceToCart]"], [
        refreshCart
    ]);
    const removeCartServiceItemById = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[removeCartServiceItemById]": async (itemId)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeCartServiceItemById"](itemId);
                await refreshCart();
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[removeCartServiceItemById]"], [
        refreshCart
    ]);
    const addComponentToCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[addComponentToCart]": async (componentId, quantity = 1)=>{
            try {
                const newItem = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addComponentToCart"](componentId, quantity);
                setCart({
                    "CartProvider.useCallback[addComponentToCart]": (prev)=>{
                        // Для комплектующих ищем по componentId (где componentId не null и совпадает, а productId null)
                        const existingIndex = prev.findIndex({
                            "CartProvider.useCallback[addComponentToCart].existingIndex": (item)=>item.componentId !== null && item.productId === null && String(item.componentId) === String(componentId)
                        }["CartProvider.useCallback[addComponentToCart].existingIndex"]);
                        if (existingIndex >= 0) {
                            // Обновляем существующий элемент
                            const updated = [
                                ...prev
                            ];
                            updated[existingIndex] = newItem;
                            return updated;
                        }
                        // Добавляем новый элемент
                        return [
                            ...prev,
                            newItem
                        ];
                    }
                }["CartProvider.useCallback[addComponentToCart]"]);
                // Обновляем корзину с сервера для синхронизации
                await refreshCart();
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы добавить комплектующее в корзину');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[addComponentToCart]"], [
        refreshCart
    ]);
    const removeFromCartInternal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[removeFromCartInternal]": async (productId)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeFromCart"](productId);
                setCart({
                    "CartProvider.useCallback[removeFromCartInternal]": (prev)=>prev.filter({
                            "CartProvider.useCallback[removeFromCartInternal]": (item)=>item.productId === null || item.productId !== productId
                        }["CartProvider.useCallback[removeFromCartInternal]"])
                }["CartProvider.useCallback[removeFromCartInternal]"]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы удалить товар из корзины');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[removeFromCartInternal]"], []);
    const removeCartItemById = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[removeCartItemById]": async (itemId)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeCartItemById"](itemId);
                setCart({
                    "CartProvider.useCallback[removeCartItemById]": (prev)=>prev.filter({
                            "CartProvider.useCallback[removeCartItemById]": (item)=>item.id !== itemId
                        }["CartProvider.useCallback[removeCartItemById]"])
                }["CartProvider.useCallback[removeCartItemById]"]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы удалить товар из корзины');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[removeCartItemById]"], []);
    const updateQuantity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[updateQuantity]": async (productId, quantity)=>{
            try {
                if (quantity <= 0) {
                    await removeFromCartInternal(productId);
                    return;
                }
                const updatedItem = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCartItemQuantity"](productId, quantity);
                setCart({
                    "CartProvider.useCallback[updateQuantity]": (prev)=>{
                        // Ищем только среди товаров (productId !== null) с приведением типов
                        const existingIndex = prev.findIndex({
                            "CartProvider.useCallback[updateQuantity].existingIndex": (item)=>item.productId !== null && item.componentId === null && String(item.productId) === String(productId)
                        }["CartProvider.useCallback[updateQuantity].existingIndex"]);
                        if (existingIndex >= 0) {
                            const updated = [
                                ...prev
                            ];
                            updated[existingIndex] = updatedItem;
                            return updated;
                        }
                        return prev;
                    }
                }["CartProvider.useCallback[updateQuantity]"]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы обновить корзину');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[updateQuantity]"], [
        removeFromCartInternal
    ]);
    const updateCartItemQuantityById = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[updateCartItemQuantityById]": async (itemId, quantity)=>{
            try {
                if (quantity <= 0) {
                    await removeCartItemById(itemId);
                    return;
                }
                const updatedItem = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCartItemQuantityById"](itemId, quantity);
                setCart({
                    "CartProvider.useCallback[updateCartItemQuantityById]": (prev)=>{
                        const existingIndex = prev.findIndex({
                            "CartProvider.useCallback[updateCartItemQuantityById].existingIndex": (item)=>item.id === itemId
                        }["CartProvider.useCallback[updateCartItemQuantityById].existingIndex"]);
                        if (existingIndex >= 0) {
                            const updated = [
                                ...prev
                            ];
                            updated[existingIndex] = updatedItem;
                            return updated;
                        }
                        return prev;
                    }
                }["CartProvider.useCallback[updateCartItemQuantityById]"]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы обновить корзину');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[updateCartItemQuantityById]"], [
        removeCartItemById
    ]);
    const removeFromCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[removeFromCart]": async (productId)=>{
            await removeFromCartInternal(productId);
        }
    }["CartProvider.useCallback[removeFromCart]"], [
        removeFromCartInternal
    ]);
    const removeComponentFromCartInternal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[removeComponentFromCartInternal]": async (componentId)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeComponentFromCart"](componentId);
                setCart({
                    "CartProvider.useCallback[removeComponentFromCartInternal]": (prev)=>prev.filter({
                            "CartProvider.useCallback[removeComponentFromCartInternal]": (item)=>item.componentId === null || item.componentId !== componentId
                        }["CartProvider.useCallback[removeComponentFromCartInternal]"])
                }["CartProvider.useCallback[removeComponentFromCartInternal]"]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы удалить комплектующее из корзины');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[removeComponentFromCartInternal]"], []);
    const removeComponentFromCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[removeComponentFromCart]": async (componentId)=>{
            await removeComponentFromCartInternal(componentId);
        }
    }["CartProvider.useCallback[removeComponentFromCart]"], [
        removeComponentFromCartInternal
    ]);
    const updateComponentQuantity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[updateComponentQuantity]": async (componentId, quantity)=>{
            try {
                if (quantity <= 0) {
                    await removeComponentFromCartInternal(componentId);
                    return;
                }
                const updatedItem = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateComponentQuantity"](componentId, quantity);
                setCart({
                    "CartProvider.useCallback[updateComponentQuantity]": (prev)=>{
                        // Ищем только среди комплектующих (componentId !== null) с приведением типов
                        const existingIndex = prev.findIndex({
                            "CartProvider.useCallback[updateComponentQuantity].existingIndex": (item)=>item.componentId !== null && item.productId === null && String(item.componentId) === String(componentId)
                        }["CartProvider.useCallback[updateComponentQuantity].existingIndex"]);
                        if (existingIndex >= 0) {
                            const updated = [
                                ...prev
                            ];
                            updated[existingIndex] = updatedItem;
                            return updated;
                        }
                        return prev;
                    }
                }["CartProvider.useCallback[updateComponentQuantity]"]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы обновить корзину');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[updateComponentQuantity]"], [
        removeComponentFromCartInternal
    ]);
    const clearCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[clearCart]": async ()=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearCart"]();
                setCart([]);
                setCartServiceItems([]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы очистить корзину');
                }
                throw error;
            }
        }
    }["CartProvider.useCallback[clearCart]"], []);
    const getTotalPrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CartProvider.useCallback[getTotalPrice]": ()=>{
            const productTotal = cart.reduce({
                "CartProvider.useCallback[getTotalPrice].productTotal": (total, item)=>{
                    if (item.product) {
                        return total + item.product.price * item.quantity;
                    }
                    if (item.component) {
                        return total + item.component.price * item.quantity;
                    }
                    return total;
                }
            }["CartProvider.useCallback[getTotalPrice].productTotal"], 0);
            const serviceTotal = cartServiceItems.reduce({
                "CartProvider.useCallback[getTotalPrice].serviceTotal": (sum, item)=>sum + (item.total != null && item.total > 0 ? item.total : 0)
            }["CartProvider.useCallback[getTotalPrice].serviceTotal"], 0);
            return productTotal + serviceTotal;
        }
    }["CartProvider.useCallback[getTotalPrice]"], [
        cart,
        cartServiceItems
    ]);
    const value = {
        cart,
        cartServiceItems,
        count,
        isLoading,
        addServiceToCart,
        removeCartServiceItemById,
        addToCart,
        addComponentToCart,
        updateQuantity,
        updateCartItemQuantityById,
        updateComponentQuantity,
        removeFromCart,
        removeCartItemById,
        removeComponentFromCart,
        clearCart,
        refreshCart,
        refreshCount,
        getTotalPrice
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CartContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/shared/lib/contexts/CartContext.tsx",
        lineNumber: 501,
        columnNumber: 10
    }, this);
}
_s(CartProvider, "6u8JlcqXO8u7DqQGqLYX2P0jQYA=");
_c = CartProvider;
function useCart() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CartContext);
    if (context === undefined) {
        throw new Error('useCart must be used within a CartProvider');
    }
    return context;
}
_s1(useCart, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "CartProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/compare.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addToCompare",
    ()=>addToCompare,
    "checkInCompare",
    ()=>checkInCompare,
    "getCompare",
    ()=>getCompare,
    "getCompareCount",
    ()=>getCompareCount,
    "removeFromCompare",
    ()=>removeFromCompare
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function getAuthToken() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return localStorage.getItem('admin_token') || localStorage.getItem('user_token');
}
function getAuthHeaders() {
    const token = getAuthToken();
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
async function getCompare() {
    const response = await fetch(`${API_URL}/compare`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        throw new Error('Ошибка при загрузке сравнения');
    }
    return response.json();
}
async function getCompareCount() {
    const response = await fetch(`${API_URL}/compare/count`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            return 0;
        }
        throw new Error('Ошибка при загрузке количества сравнения');
    }
    const data = await response.json();
    // API возвращает число напрямую
    return typeof data === 'number' ? data : Number(data) || 0;
}
async function addToCompare(productId) {
    const response = await fetch(`${API_URL}/compare/${productId}`, {
        method: 'POST',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 409) {
            const errorData = await response.json().catch(()=>({}));
            if (errorData.message?.includes('Maximum')) {
                throw new Error('Максимум 10 товаров можно сравнить одновременно');
            }
            throw new Error('Товар уже в сравнении');
        }
        throw new Error('Ошибка при добавлении в сравнение');
    }
    return response.json();
}
async function removeFromCompare(productId) {
    const response = await fetch(`${API_URL}/compare/${productId}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Товар не найден в сравнении');
        }
        throw new Error('Ошибка при удалении из сравнения');
    }
}
async function checkInCompare(productId) {
    const response = await fetch(`${API_URL}/compare/check/${productId}`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            return false;
        }
        return false;
    }
    const data = await response.json();
    return data.isInCompare;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/contexts/CompareContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CompareProvider",
    ()=>CompareProvider,
    "useCompare",
    ()=>useCompare
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$compare$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/compare.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const CompareContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function CompareProvider({ children }) {
    _s();
    const [compare, setCompare] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [count, setCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isChecking, setIsChecking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const refreshCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CompareProvider.useCallback[refreshCount]": async ()=>{
            try {
                const newCount = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$compare$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCompareCount"]();
                setCount(newCount);
            } catch  {
                setCount(0);
            }
        }
    }["CompareProvider.useCallback[refreshCount]"], []);
    // Загружаем полный список сравнения при инициализации (1 запрос вместо N проверок на карточках)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CompareProvider.useEffect": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$compare$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCompare"]().then({
                "CompareProvider.useEffect": (products)=>{
                    const ids = products.map({
                        "CompareProvider.useEffect.ids": (p)=>p.id
                    }["CompareProvider.useEffect.ids"]);
                    setCompare(ids);
                    setCount(ids.length);
                }
            }["CompareProvider.useEffect"]).catch({
                "CompareProvider.useEffect": ()=>{
                    setCompare([]);
                    refreshCount().catch({
                        "CompareProvider.useEffect": ()=>{}
                    }["CompareProvider.useEffect"]);
                }
            }["CompareProvider.useEffect"]);
        }
    }["CompareProvider.useEffect"], [
        refreshCount
    ]);
    const addToCompare = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CompareProvider.useCallback[addToCompare]": async (productId)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$compare$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addToCompare"](productId);
                setCompare({
                    "CompareProvider.useCallback[addToCompare]": (prev)=>prev.includes(productId) ? prev : [
                            ...prev,
                            productId
                        ]
                }["CompareProvider.useCallback[addToCompare]"]);
                // Синхронизируем счетчик с сервером после успешной операции
                await refreshCount();
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы добавить товар в сравнение');
                }
                throw error;
            }
        }
    }["CompareProvider.useCallback[addToCompare]"], [
        refreshCount
    ]);
    const removeFromCompare = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CompareProvider.useCallback[removeFromCompare]": async (productId)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$compare$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeFromCompare"](productId);
                setCompare({
                    "CompareProvider.useCallback[removeFromCompare]": (prev)=>prev.filter({
                            "CompareProvider.useCallback[removeFromCompare]": (id)=>id !== productId
                        }["CompareProvider.useCallback[removeFromCompare]"])
                }["CompareProvider.useCallback[removeFromCompare]"]);
                // Синхронизируем счетчик с сервером после успешной операции
                await refreshCount();
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы удалить товар из сравнения');
                }
                throw error;
            }
        }
    }["CompareProvider.useCallback[removeFromCompare]"], [
        refreshCount
    ]);
    const toggleCompare = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CompareProvider.useCallback[toggleCompare]": async (productId)=>{
            const inList = compare.includes(productId);
            if (inList) {
                await removeFromCompare(productId);
            } else {
                await addToCompare(productId);
            }
        }
    }["CompareProvider.useCallback[toggleCompare]"], [
        compare,
        addToCompare,
        removeFromCompare
    ]);
    const isInCompare = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CompareProvider.useCallback[isInCompare]": (productId)=>compare.includes(productId)
    }["CompareProvider.useCallback[isInCompare]"], [
        compare
    ]);
    const checkInCompare = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CompareProvider.useCallback[checkInCompare]": async (productId)=>{
            setIsChecking(true);
            try {
                const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$compare$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkInCompare"](productId);
                if (result && !compare.includes(productId)) {
                    setCompare({
                        "CompareProvider.useCallback[checkInCompare]": (prev)=>[
                                ...prev,
                                productId
                            ]
                    }["CompareProvider.useCallback[checkInCompare]"]);
                } else if (!result && compare.includes(productId)) {
                    setCompare({
                        "CompareProvider.useCallback[checkInCompare]": (prev)=>prev.filter({
                                "CompareProvider.useCallback[checkInCompare]": (id)=>id !== productId
                            }["CompareProvider.useCallback[checkInCompare]"])
                    }["CompareProvider.useCallback[checkInCompare]"]);
                }
                return result;
            } catch  {
                return false;
            } finally{
                setIsChecking(false);
            }
        }
    }["CompareProvider.useCallback[checkInCompare]"], [
        compare
    ]);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CompareProvider.useMemo[value]": ()=>({
                compare,
                count,
                isLoading,
                isChecking,
                addToCompare,
                removeFromCompare,
                toggleCompare,
                isInCompare,
                checkInCompare,
                refreshCount
            })
    }["CompareProvider.useMemo[value]"], [
        compare,
        count,
        isLoading,
        isChecking,
        addToCompare,
        removeFromCompare,
        toggleCompare,
        isInCompare,
        checkInCompare,
        refreshCount
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CompareContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/shared/lib/contexts/CompareContext.tsx",
        lineNumber: 147,
        columnNumber: 10
    }, this);
}
_s(CompareProvider, "Ip/EMJ3im4bjGnFl8BYq9fuCLXg=");
_c = CompareProvider;
function useCompare() {
    _s1();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CompareContext);
    if (ctx === undefined) {
        throw new Error('useCompare must be used within a CompareProvider');
    }
    return ctx;
}
_s1(useCompare, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
__turbopack_context__.k.register(_c, "CompareProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/navigation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchNavigation",
    ()=>fetchNavigation,
    "mapApiItemToNavItem",
    ()=>mapApiItemToNavItem
]);
function mapApiItemToNavItem(item) {
    return {
        name: item.name,
        href: item.href || '#',
        hasDropdown: item.hasDropdown === true,
        dropdownItems: item.dropdownItems?.length ? item.dropdownItems : undefined
    };
}
async function fetchNavigation(apiUrl) {
    try {
        const res = await fetch(`${apiUrl}/navigation`, {
            cache: 'no-store'
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (!Array.isArray(data) || data.length === 0) return null;
        return data.map(mapApiItemToNavItem);
    } catch  {
        return null;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/constants/navigation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dropdownMenus",
    ()=>dropdownMenus,
    "getMenuItemByProductType",
    ()=>getMenuItemByProductType,
    "getPathForProductType",
    ()=>getPathForProductType,
    "getProductTypesForCategory",
    ()=>getProductTypesForCategory,
    "mainCategories",
    ()=>mainCategories,
    "navigation",
    ()=>navigation
]);
const navigation = [
    {
        name: 'Каталог',
        href: '/catalog/products',
        hasDropdown: true,
        category: 'products'
    },
    {
        name: 'Каталог услуг',
        href: '/catalog/services',
        hasDropdown: true,
        category: 'services'
    },
    {
        name: 'Мебель на заказ',
        href: '/catalog/products/custom-furniture',
        hasDropdown: false
    },
    {
        name: 'Натяжные потолки',
        href: '/catalog/products/stretch-ceilings',
        hasDropdown: false
    },
    {
        name: 'Акции',
        href: '/promotions',
        hasDropdown: true,
        category: 'promotions'
    },
    {
        name: 'Блог',
        href: '/blog',
        hasDropdown: true,
        category: 'blog'
    },
    {
        name: 'Фото',
        href: '/photo',
        hasDropdown: true,
        category: 'photo'
    }
];
const dropdownMenus = {
    Каталог: {
        category: 'products',
        image: '../images/catalog-products.jpg',
        items: [
            {
                name: 'Двери входные',
                href: '/catalog/products/entrance-doors',
                productType: 'entrance_doors',
                icon: 'RectangleStack',
                hasSubmenu: true,
                submenu: [
                    {
                        name: 'Входные двери ТТ XL / XXL',
                        href: '/catalog/products/entrance-doors/tt-xl-xxl',
                        productType: 'entrance_doors_tt_xl_xxl'
                    },
                    {
                        name: 'Входные двери М',
                        href: '/catalog/products/entrance-doors/m',
                        productType: 'entrance_doors_m'
                    },
                    {
                        name: 'Входные двери Аргус',
                        href: '/catalog/products/entrance-doors/argus',
                        productType: 'entrance_doors_argus'
                    }
                ]
            },
            {
                name: 'Двери межкомнатные',
                href: '/catalog/products/interior-doors',
                productType: 'interior_doors',
                icon: 'RectangleStack'
            },
            {
                name: 'Фурнитура для дверей',
                href: '/catalog/products/door-hardware',
                productType: 'door_hardware',
                icon: 'WrenchScrewdriver'
            },
            {
                name: 'Окна',
                href: '/catalog/products/windows',
                productType: 'windows',
                icon: 'Squares2X2'
            },
            {
                name: 'Жалюзи',
                href: '/catalog/products/blinds',
                productType: 'blinds',
                icon: 'ViewColumns'
            },
            {
                name: 'Потолки натяжные',
                href: '/catalog/products/stretch-ceilings',
                productType: 'stretch_ceilings',
                icon: 'Cube'
            },
            {
                name: 'Мягкая мебель',
                href: '/catalog/products/upholstered-furniture',
                productType: 'upholstered_furniture',
                icon: 'Home'
            },
            {
                name: 'Обеденные группы',
                href: '/catalog/products/dining-groups',
                productType: 'dining_groups',
                icon: 'TableCells'
            },
            {
                name: 'Товары для сна',
                href: '/catalog/products/sleep-products',
                productType: 'sleep_products',
                icon: 'Moon'
            },
            {
                name: 'Мебель по индивидуальным размерам',
                href: '/catalog/products/custom-furniture',
                productType: 'custom_furniture',
                icon: 'CubeTransparent'
            },
            {
                name: 'Освещение',
                href: '/catalog/products/lighting',
                productType: 'lighting',
                icon: 'LightBulb'
            }
        ]
    },
    Акции: {
        category: 'promotions',
        image: '../images/promotions.jpg',
        items: [
            {
                name: 'Все акции',
                href: '/promotions',
                productType: 'all_promotions',
                icon: 'Tag'
            }
        ]
    },
    Блог: {
        category: 'blog',
        image: '../images/blog.jpg',
        items: [
            {
                name: 'Все записи',
                href: '/blog',
                productType: 'all_blog',
                icon: 'DocumentText'
            }
        ]
    },
    Фото: {
        category: 'photo',
        image: '../images/remont-kvartir.jpg',
        items: [
            {
                name: 'Ремонт санузла',
                href: '/photo/bathroom-renovation',
                productType: 'bathroom_renovation',
                icon: 'Home'
            },
            {
                name: 'Ремонт квартиры',
                href: '/photo/apartment-renovation',
                productType: 'apartment_renovation',
                icon: 'BuildingOffice'
            },
            {
                name: 'Кухни',
                href: '/photo/kitchens',
                productType: 'kitchens',
                icon: 'Home'
            },
            {
                name: 'Гардеробные',
                href: '/photo/wardrobes',
                productType: 'wardrobes',
                icon: 'CubeTransparent'
            },
            {
                name: 'Шкафы-купе',
                href: '/photo/sliding-wardrobes',
                productType: 'sliding_wardrobes',
                icon: 'CubeTransparent'
            },
            {
                name: 'Двери',
                href: '/photo/doors',
                productType: 'photo_doors',
                icon: 'RectangleStack'
            },
            {
                name: 'Окна',
                href: '/photo/windows',
                productType: 'photo_windows',
                icon: 'Squares2X2'
            },
            {
                name: 'Потолки натяжные',
                href: '/photo/stretch-ceilings',
                productType: 'photo_stretch_ceilings',
                icon: 'Cube'
            },
            {
                name: 'Жалюзи',
                href: '/photo/blinds',
                productType: 'photo_blinds',
                icon: 'ViewColumns'
            }
        ]
    }
};
function getPathForProductType(productType) {
    for (const menu of Object.values(dropdownMenus)){
        const item = menu.items.find((item)=>item.productType === productType);
        if (item) {
            return item.href;
        }
        for (const mainItem of menu.items){
            if (mainItem.submenu) {
                const subItem = mainItem.submenu.find((subItem)=>subItem.productType === productType);
                if (subItem) {
                    return subItem.href;
                }
            }
        }
    }
    return '/catalog';
}
function getProductTypesForCategory(category) {
    const menu = Object.values(dropdownMenus).find((m)=>m.category === category);
    if (!menu) return [];
    const productTypes = [];
    menu.items.forEach((item)=>{
        if (item.productType) {
            productTypes.push(item.productType);
        }
        if (item.submenu) {
            item.submenu.forEach((subItem)=>{
                if (subItem.productType) {
                    productTypes.push(subItem.productType);
                }
            });
        }
    });
    return productTypes;
}
function getMenuItemByProductType(productType) {
    for (const menu of Object.values(dropdownMenus)){
        for (const item of menu.items){
            if (item.productType === productType) {
                return item;
            }
            if (item.submenu) {
                const subItem = item.submenu.find((subItem)=>subItem.productType === productType);
                if (subItem) {
                    return subItem;
                }
            }
        }
    }
    return null;
}
const mainCategories = navigation.map((item)=>({
        name: item.name,
        href: item.href
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/contexts/NavigationContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NavigationProvider",
    ()=>NavigationProvider,
    "useNavigationItems",
    ()=>useNavigationItems
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/navigation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$constants$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/constants/navigation.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const NAV_FALLBACK_STORAGE_KEY = 'platform-tir:navigation-fallback';
function getStoredFallback() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = localStorage.getItem(NAV_FALLBACK_STORAGE_KEY);
        if (!raw) return null;
        const data = JSON.parse(raw);
        if (!Array.isArray(data) || data.length === 0) return null;
        return data.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapApiItemToNavItem"]);
    } catch  {
        return null;
    }
}
function setStoredFallback(data) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        localStorage.setItem(NAV_FALLBACK_STORAGE_KEY, JSON.stringify(data));
    } catch  {
    // ignore
    }
}
const NavigationContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function NavigationProvider({ children, initialItems }) {
    _s();
    // Когда бэкенд доступен — initialItems с сервера, перескока нет. Когда недоступен — остаёмся на defaultNavigation и не подставляем localStorage, чтобы не было перескока через ~0.5 с.
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "NavigationProvider.useState": ()=>{
            if (initialItems != null && initialItems.length > 0) return initialItems;
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$constants$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navigation"];
        }
    }["NavigationProvider.useState"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavigationProvider.useEffect": ()=>{
            let cancelled = false;
            fetch(`${API_URL}/navigation`, {
                cache: 'no-store'
            }).then({
                "NavigationProvider.useEffect": (res)=>res.ok ? res.json() : Promise.reject(new Error('Failed to fetch'))
            }["NavigationProvider.useEffect"]).then({
                "NavigationProvider.useEffect": (data)=>{
                    if (cancelled) return;
                    if (Array.isArray(data) && data.length > 0) {
                        setStoredFallback(data);
                        setItems(data.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapApiItemToNavItem"]));
                    } else {
                        const stored = getStoredFallback();
                        setItems(stored ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$constants$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navigation"]);
                    }
                }
            }["NavigationProvider.useEffect"]).catch({
                "NavigationProvider.useEffect": ()=>{
                    if (!cancelled) {
                        // Бэкенд недоступен: не подставляем stored, чтобы порядок не менялся после первого кадра (остаётся defaultNavigation).
                        setItems(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$constants$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navigation"]);
                    }
                }
            }["NavigationProvider.useEffect"]);
            return ({
                "NavigationProvider.useEffect": ()=>{
                    cancelled = true;
                }
            })["NavigationProvider.useEffect"];
        }
    }["NavigationProvider.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavigationContext.Provider, {
        value: items,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/shared/lib/contexts/NavigationContext.tsx",
        lineNumber: 74,
        columnNumber: 10
    }, this);
}
_s(NavigationProvider, "DWy56NQZ0BX1yx+4SPb4NcLBhCM=");
_c = NavigationProvider;
function useNavigationItems() {
    _s1();
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(NavigationContext);
    if (value === undefined) {
        throw new Error('useNavigationItems must be used within NavigationProvider');
    }
    return value;
}
_s1(useNavigationItems, "ksutO2/Ix3UeCrGnhyM+QEP505Y=");
var _c;
__turbopack_context__.k.register(_c, "NavigationProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/wishlist.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addToWishlist",
    ()=>addToWishlist,
    "checkInWishlist",
    ()=>checkInWishlist,
    "getWishlist",
    ()=>getWishlist,
    "getWishlistCount",
    ()=>getWishlistCount,
    "removeFromWishlist",
    ()=>removeFromWishlist
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function getAuthToken() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return localStorage.getItem('admin_token') || localStorage.getItem('user_token');
}
function getAuthHeaders() {
    const token = getAuthToken();
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
async function getWishlist() {
    const response = await fetch(`${API_URL}/wishlist`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        throw new Error('Ошибка при загрузке избранного');
    }
    return response.json();
}
async function getWishlistCount() {
    const response = await fetch(`${API_URL}/wishlist/count`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            return 0;
        }
        throw new Error('Ошибка при загрузке количества избранного');
    }
    const data = await response.json();
    // API возвращает число напрямую
    return typeof data === 'number' ? data : Number(data) || 0;
}
async function addToWishlist(productId) {
    const response = await fetch(`${API_URL}/wishlist/${productId}`, {
        method: 'POST',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 409) {
            throw new Error('Товар уже в избранном');
        }
        throw new Error('Ошибка при добавлении в избранное');
    }
    return response.json();
}
async function removeFromWishlist(productId) {
    const response = await fetch(`${API_URL}/wishlist/${productId}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            throw new Error('Необходима авторизация');
        }
        if (response.status === 404) {
            throw new Error('Товар не найден в избранном');
        }
        throw new Error('Ошибка при удалении из избранного');
    }
}
async function checkInWishlist(productId) {
    const response = await fetch(`${API_URL}/wishlist/check/${productId}`, {
        method: 'GET',
        headers: getAuthHeaders()
    });
    if (!response.ok) {
        if (response.status === 401) {
            return false;
        }
        return false;
    }
    const data = await response.json();
    return data.isInWishlist;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/contexts/WishlistContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WishlistProvider",
    ()=>WishlistProvider,
    "useWishlist",
    ()=>useWishlist
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$wishlist$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/wishlist.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const WishlistContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function WishlistProvider({ children }) {
    _s();
    const [wishlist, setWishlist] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [count, setCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isChecking, setIsChecking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const refreshCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WishlistProvider.useCallback[refreshCount]": async ()=>{
            try {
                const newCount = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$wishlist$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWishlistCount"]();
                setCount(newCount);
            } catch  {
                setCount(0);
            }
        }
    }["WishlistProvider.useCallback[refreshCount]"], []);
    // Загружаем полный список избранного при инициализации (1 запрос вместо N проверок на карточках)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WishlistProvider.useEffect": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$wishlist$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWishlist"]().then({
                "WishlistProvider.useEffect": (products)=>{
                    const ids = products.map({
                        "WishlistProvider.useEffect.ids": (p)=>p.id
                    }["WishlistProvider.useEffect.ids"]);
                    setWishlist(ids);
                    setCount(ids.length);
                }
            }["WishlistProvider.useEffect"]).catch({
                "WishlistProvider.useEffect": ()=>{
                    setWishlist([]);
                    refreshCount().catch({
                        "WishlistProvider.useEffect": ()=>{}
                    }["WishlistProvider.useEffect"]);
                }
            }["WishlistProvider.useEffect"]);
        }
    }["WishlistProvider.useEffect"], [
        refreshCount
    ]);
    const addToWishlist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WishlistProvider.useCallback[addToWishlist]": async (productId)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$wishlist$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addToWishlist"](productId);
                setWishlist({
                    "WishlistProvider.useCallback[addToWishlist]": (prev)=>prev.includes(productId) ? prev : [
                            ...prev,
                            productId
                        ]
                }["WishlistProvider.useCallback[addToWishlist]"]);
                setCount({
                    "WishlistProvider.useCallback[addToWishlist]": (prev)=>prev + 1
                }["WishlistProvider.useCallback[addToWishlist]"]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы добавить товар в избранное');
                }
                throw error;
            }
        }
    }["WishlistProvider.useCallback[addToWishlist]"], []);
    const removeFromWishlist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WishlistProvider.useCallback[removeFromWishlist]": async (productId)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$wishlist$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeFromWishlist"](productId);
                setWishlist({
                    "WishlistProvider.useCallback[removeFromWishlist]": (prev)=>prev.filter({
                            "WishlistProvider.useCallback[removeFromWishlist]": (id)=>id !== productId
                        }["WishlistProvider.useCallback[removeFromWishlist]"])
                }["WishlistProvider.useCallback[removeFromWishlist]"]);
                setCount({
                    "WishlistProvider.useCallback[removeFromWishlist]": (prev)=>Math.max(0, prev - 1)
                }["WishlistProvider.useCallback[removeFromWishlist]"]);
            } catch (error) {
                if (error instanceof Error && error.message === 'Необходима авторизация') {
                    throw new Error('Войдите в систему, чтобы удалить товар из избранного');
                }
                throw error;
            }
        }
    }["WishlistProvider.useCallback[removeFromWishlist]"], []);
    const toggleWishlist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WishlistProvider.useCallback[toggleWishlist]": async (productId)=>{
            const inList = wishlist.includes(productId);
            if (inList) {
                await removeFromWishlist(productId);
            } else {
                await addToWishlist(productId);
            }
        }
    }["WishlistProvider.useCallback[toggleWishlist]"], [
        wishlist,
        addToWishlist,
        removeFromWishlist
    ]);
    const isInWishlist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WishlistProvider.useCallback[isInWishlist]": (productId)=>wishlist.includes(productId)
    }["WishlistProvider.useCallback[isInWishlist]"], [
        wishlist
    ]);
    const checkInWishlist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WishlistProvider.useCallback[checkInWishlist]": async (productId)=>{
            setIsChecking(true);
            try {
                const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$wishlist$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkInWishlist"](productId);
                if (result && !wishlist.includes(productId)) {
                    setWishlist({
                        "WishlistProvider.useCallback[checkInWishlist]": (prev)=>[
                                ...prev,
                                productId
                            ]
                    }["WishlistProvider.useCallback[checkInWishlist]"]);
                } else if (!result && wishlist.includes(productId)) {
                    setWishlist({
                        "WishlistProvider.useCallback[checkInWishlist]": (prev)=>prev.filter({
                                "WishlistProvider.useCallback[checkInWishlist]": (id)=>id !== productId
                            }["WishlistProvider.useCallback[checkInWishlist]"])
                    }["WishlistProvider.useCallback[checkInWishlist]"]);
                }
                return result;
            } catch  {
                return false;
            } finally{
                setIsChecking(false);
            }
        }
    }["WishlistProvider.useCallback[checkInWishlist]"], [
        wishlist
    ]);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "WishlistProvider.useMemo[value]": ()=>({
                wishlist,
                count,
                isLoading,
                isChecking,
                addToWishlist,
                removeFromWishlist,
                toggleWishlist,
                isInWishlist,
                checkInWishlist,
                refreshCount
            })
    }["WishlistProvider.useMemo[value]"], [
        wishlist,
        count,
        isLoading,
        isChecking,
        addToWishlist,
        removeFromWishlist,
        toggleWishlist,
        isInWishlist,
        checkInWishlist,
        refreshCount
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WishlistContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/shared/lib/contexts/WishlistContext.tsx",
        lineNumber: 139,
        columnNumber: 10
    }, this);
}
_s(WishlistProvider, "h8N0KmudARWjHzGhSFhDNVbQTcQ=");
_c = WishlistProvider;
function useWishlist() {
    _s1();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(WishlistContext);
    if (ctx === undefined) {
        throw new Error('useWishlist must be used within a WishlistProvider');
    }
    return ctx;
}
_s1(useWishlist, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
__turbopack_context__.k.register(_c, "WishlistProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/auth/context/UserAuthContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UserAuthProvider",
    ()=>UserAuthProvider,
    "useUserAuth",
    ()=>useUserAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const UserAuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const USER_TOKEN_KEY = 'user_token';
const USER_DATA_KEY = 'user_data';
const ADMIN_TOKEN_KEY = 'admin_token';
const ADMIN_USER_KEY = 'admin_user';
/** Загрузить состояние авторизации: приоритет user_*, fallback на admin_* (админ в публичке). */ function loadAuthFromStorage() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let token = localStorage.getItem(USER_TOKEN_KEY);
    let userJson = localStorage.getItem(USER_DATA_KEY);
    let source = 'user';
    if (!token || !userJson) {
        token = localStorage.getItem(ADMIN_TOKEN_KEY);
        userJson = localStorage.getItem(ADMIN_USER_KEY);
        source = 'admin';
    }
    if (!token || !userJson) {
        return {
            token: null,
            user: null,
            source: 'user'
        };
    }
    try {
        const parsedUser = JSON.parse(userJson);
        return {
            token,
            user: parsedUser,
            source
        };
    } catch  {
        return {
            token: null,
            user: null,
            source: 'user'
        };
    }
}
function UserAuthProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [token, setToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[logout]": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.removeItem(USER_TOKEN_KEY);
                localStorage.removeItem(USER_DATA_KEY);
                localStorage.removeItem(ADMIN_TOKEN_KEY);
                localStorage.removeItem(ADMIN_USER_KEY);
                window.dispatchEvent(new Event('auth-token-changed'));
            }
            setToken(null);
            setUser(null);
        }
    }["UserAuthProvider.useCallback[logout]"], []);
    const applyAuthFromStorage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[applyAuthFromStorage]": ()=>{
            const { token: loadedToken, user: loadedUser } = loadAuthFromStorage();
            setToken(loadedToken);
            setUser(loadedUser);
            return loadedToken;
        }
    }["UserAuthProvider.useCallback[applyAuthFromStorage]"], []);
    // Load auth state on mount: user_token first, fallback to admin_token (админ в публичке)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UserAuthProvider.useEffect": ()=>{
            const loadedToken = applyAuthFromStorage();
            if (loadedToken) {
                const isAdminSource = localStorage.getItem(ADMIN_TOKEN_KEY) === loadedToken;
                verifyToken(loadedToken).then({
                    "UserAuthProvider.useEffect": (isValid)=>{
                        if (!isValid) {
                            const { token: current } = loadAuthFromStorage();
                            if (current === loadedToken) {
                                setToken(null);
                                setUser(null);
                                if (isAdminSource) {
                                    localStorage.removeItem(ADMIN_TOKEN_KEY);
                                    localStorage.removeItem(ADMIN_USER_KEY);
                                } else {
                                    localStorage.removeItem(USER_TOKEN_KEY);
                                    localStorage.removeItem(USER_DATA_KEY);
                                }
                            }
                        }
                    }
                }["UserAuthProvider.useEffect"]);
            }
            setIsLoading(false);
        }
    }["UserAuthProvider.useEffect"], [
        applyAuthFromStorage
    ]);
    // Синхронизация при смене токена (вход/выход в админке или другой вкладке)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UserAuthProvider.useEffect": ()=>{
            const handleAuthChange = {
                "UserAuthProvider.useEffect.handleAuthChange": ()=>{
                    applyAuthFromStorage();
                }
            }["UserAuthProvider.useEffect.handleAuthChange"];
            window.addEventListener('auth-token-changed', handleAuthChange);
            window.addEventListener('storage', {
                "UserAuthProvider.useEffect": (e)=>{
                    if (e.key === USER_TOKEN_KEY || e.key === USER_DATA_KEY || e.key === ADMIN_TOKEN_KEY || e.key === ADMIN_USER_KEY) {
                        handleAuthChange();
                    }
                }
            }["UserAuthProvider.useEffect"]);
            return ({
                "UserAuthProvider.useEffect": ()=>{
                    window.removeEventListener('auth-token-changed', handleAuthChange);
                }
            })["UserAuthProvider.useEffect"];
        }
    }["UserAuthProvider.useEffect"], [
        applyAuthFromStorage
    ]);
    const verifyToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[verifyToken]": async (tokenToVerify)=>{
            try {
                const response = await fetch(`${API_URL}/auth/profile`, {
                    headers: {
                        Authorization: `Bearer ${tokenToVerify}`
                    }
                });
                if (response.ok) {
                    const userData = await response.json();
                    setUser(userData);
                    const isFromAdmin = localStorage.getItem(ADMIN_TOKEN_KEY) === tokenToVerify;
                    if (isFromAdmin) {
                        localStorage.setItem(ADMIN_USER_KEY, JSON.stringify(userData));
                    } else {
                        localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData));
                    }
                    return true;
                }
                return false;
            } catch  {
                return false;
            }
        }
    }["UserAuthProvider.useCallback[verifyToken]"], []);
    const refreshUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[refreshUser]": async ()=>{
            const savedToken = localStorage.getItem(USER_TOKEN_KEY) || localStorage.getItem(ADMIN_TOKEN_KEY);
            if (!savedToken) return;
            try {
                const response = await fetch(`${API_URL}/auth/profile`, {
                    headers: {
                        Authorization: `Bearer ${savedToken}`
                    }
                });
                if (response.ok) {
                    const userData = await response.json();
                    setUser(userData);
                    const isFromAdmin = localStorage.getItem(ADMIN_TOKEN_KEY) === savedToken;
                    if (isFromAdmin) {
                        localStorage.setItem(ADMIN_USER_KEY, JSON.stringify(userData));
                    } else {
                        localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData));
                    }
                }
            } catch  {
            // ignore
            }
        }
    }["UserAuthProvider.useCallback[refreshUser]"], []);
    const login = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[login]": async (email, password)=>{
            try {
                const response = await fetch(`${API_URL}/auth/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email,
                        password
                    })
                });
                if (!response.ok) {
                    const error = await response.json().catch({
                        "UserAuthProvider.useCallback[login]": ()=>({})
                    }["UserAuthProvider.useCallback[login]"]);
                    return {
                        success: false,
                        error: error.message || 'Неверный email или пароль'
                    };
                }
                const data = await response.json();
                const adminRoles = [
                    'SUPER_ADMIN',
                    'ADMIN',
                    'CONTENT_MANAGER',
                    'MODERATOR',
                    'SUPPORT',
                    'PARTNER',
                    'BRIGADIER',
                    'LEAD_SPECIALIST_FURNITURE',
                    'LEAD_SPECIALIST_WINDOWS_DOORS',
                    'SURVEYOR',
                    'DRIVER',
                    'INSTALLER'
                ];
                const isAdmin = adminRoles.includes(data.user?.role);
                // Save to state and localStorage
                setToken(data.access_token);
                setUser(data.user);
                localStorage.setItem(USER_TOKEN_KEY, data.access_token);
                localStorage.setItem(USER_DATA_KEY, JSON.stringify(data.user));
                if (isAdmin) {
                    localStorage.setItem(ADMIN_TOKEN_KEY, data.access_token);
                    localStorage.setItem(ADMIN_USER_KEY, JSON.stringify(data.user));
                } else {
                    localStorage.removeItem(ADMIN_TOKEN_KEY);
                    localStorage.removeItem(ADMIN_USER_KEY);
                }
                if ("TURBOPACK compile-time truthy", 1) {
                    window.dispatchEvent(new Event('auth-token-changed'));
                }
                return {
                    success: true
                };
            } catch (error) {
                console.error('Login error:', error);
                return {
                    success: false,
                    error: 'Ошибка подключения к серверу'
                };
            }
        }
    }["UserAuthProvider.useCallback[login]"], []);
    const register = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[register]": async (email, password, firstName, lastName)=>{
            try {
                const response = await fetch(`${API_URL}/auth/register`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email,
                        password,
                        firstName,
                        lastName
                    })
                });
                if (!response.ok) {
                    const error = await response.json().catch({
                        "UserAuthProvider.useCallback[register]": ()=>({})
                    }["UserAuthProvider.useCallback[register]"]);
                    return {
                        success: false,
                        error: error.message || 'Ошибка при регистрации'
                    };
                }
                const data = await response.json();
                const adminRoles = [
                    'SUPER_ADMIN',
                    'ADMIN',
                    'CONTENT_MANAGER',
                    'MODERATOR',
                    'SUPPORT',
                    'PARTNER',
                    'BRIGADIER',
                    'LEAD_SPECIALIST_FURNITURE',
                    'LEAD_SPECIALIST_WINDOWS_DOORS',
                    'SURVEYOR',
                    'DRIVER',
                    'INSTALLER'
                ];
                const isAdmin = adminRoles.includes(data.user?.role);
                // Save to state and localStorage
                setToken(data.access_token);
                setUser(data.user);
                localStorage.setItem(USER_TOKEN_KEY, data.access_token);
                localStorage.setItem(USER_DATA_KEY, JSON.stringify(data.user));
                if (isAdmin) {
                    localStorage.setItem(ADMIN_TOKEN_KEY, data.access_token);
                    localStorage.setItem(ADMIN_USER_KEY, JSON.stringify(data.user));
                } else {
                    localStorage.removeItem(ADMIN_TOKEN_KEY);
                    localStorage.removeItem(ADMIN_USER_KEY);
                }
                if ("TURBOPACK compile-time truthy", 1) {
                    window.dispatchEvent(new Event('auth-token-changed'));
                }
                return {
                    success: true
                };
            } catch (error) {
                console.error('Register error:', error);
                return {
                    success: false,
                    error: 'Ошибка подключения к серверу'
                };
            }
        }
    }["UserAuthProvider.useCallback[register]"], []);
    const updateProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[updateProfile]": async (data)=>{
            if (!token || !user) {
                return {
                    success: false,
                    error: 'Необходима авторизация'
                };
            }
            try {
                const response = await fetch(`${API_URL}/users/me`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`
                    },
                    body: JSON.stringify(data)
                });
                if (!response.ok) {
                    const error = await response.json().catch({
                        "UserAuthProvider.useCallback[updateProfile]": ()=>({})
                    }["UserAuthProvider.useCallback[updateProfile]"]);
                    return {
                        success: false,
                        error: error.message || 'Ошибка при обновлении профиля'
                    };
                }
                const updatedUser = await response.json();
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const { password: _password, ...userWithoutPassword } = updatedUser;
                setUser(userWithoutPassword);
                const isAdminToken = token && localStorage.getItem(ADMIN_TOKEN_KEY) === token;
                const userKey = isAdminToken ? ADMIN_USER_KEY : USER_DATA_KEY;
                localStorage.setItem(userKey, JSON.stringify(userWithoutPassword));
                if (isAdminToken) {
                    localStorage.setItem(USER_DATA_KEY, JSON.stringify(userWithoutPassword));
                }
                if ("TURBOPACK compile-time truthy", 1) {
                    window.dispatchEvent(new Event('auth-token-changed'));
                }
                return {
                    success: true
                };
            } catch (error) {
                console.error('Update profile error:', error);
                return {
                    success: false,
                    error: 'Ошибка подключения к серверу'
                };
            }
        }
    }["UserAuthProvider.useCallback[updateProfile]"], [
        token,
        user
    ]);
    const uploadAvatar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[uploadAvatar]": async (file)=>{
            if (!token || !user) {
                return {
                    success: false,
                    error: 'Необходима авторизация'
                };
            }
            try {
                const formData = new FormData();
                formData.append('file', file);
                const response = await fetch(`${API_URL}/users/me/avatar`, {
                    method: 'POST',
                    headers: {
                        Authorization: `Bearer ${token}`
                    },
                    body: formData
                });
                if (!response.ok) {
                    const error = await response.json().catch({
                        "UserAuthProvider.useCallback[uploadAvatar]": ()=>({})
                    }["UserAuthProvider.useCallback[uploadAvatar]"]);
                    return {
                        success: false,
                        error: error.message || 'Ошибка при загрузке аватарки'
                    };
                }
                const { user: updatedUser } = await response.json();
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const { password: _password, ...userWithoutPassword } = updatedUser;
                setUser(userWithoutPassword);
                const isAdminToken = token && localStorage.getItem(ADMIN_TOKEN_KEY) === token;
                const userKey = isAdminToken ? ADMIN_USER_KEY : USER_DATA_KEY;
                localStorage.setItem(userKey, JSON.stringify(userWithoutPassword));
                if (isAdminToken) {
                    localStorage.setItem(USER_DATA_KEY, JSON.stringify(userWithoutPassword));
                }
                if ("TURBOPACK compile-time truthy", 1) {
                    window.dispatchEvent(new Event('auth-token-changed'));
                }
                return {
                    success: true
                };
            } catch (error) {
                console.error('Upload avatar error:', error);
                return {
                    success: false,
                    error: 'Ошибка подключения к серверу'
                };
            }
        }
    }["UserAuthProvider.useCallback[uploadAvatar]"], [
        token,
        user
    ]);
    const getAuthHeaders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "UserAuthProvider.useCallback[getAuthHeaders]": ()=>{
            if (token) {
                return {
                    Authorization: `Bearer ${token}`
                };
            }
            return {};
        }
    }["UserAuthProvider.useCallback[getAuthHeaders]"], [
        token
    ]);
    const value = {
        user,
        token,
        isLoading,
        isAuthenticated: !!token && !!user,
        login,
        register,
        logout,
        refreshUser,
        updateProfile,
        uploadAvatar,
        getAuthHeaders
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UserAuthContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/features/auth/context/UserAuthContext.tsx",
        lineNumber: 470,
        columnNumber: 10
    }, this);
}
_s(UserAuthProvider, "WHddEhw6Zjeokt8m2sAr9FxKq2o=");
_c = UserAuthProvider;
function useUserAuth() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(UserAuthContext);
    if (context === undefined) {
        throw new Error('useUserAuth must be used within a UserAuthProvider');
    }
    return context;
}
_s1(useUserAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "UserAuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/forms.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "submitCallbackForm",
    ()=>submitCallbackForm,
    "submitMeasurementForm",
    ()=>submitMeasurementForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
async function submitMeasurementForm(data) {
    const res = await fetch(`${API_URL}/forms/measurement`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        const message = err?.message || (Array.isArray(err?.message) ? err.message.join(', ') : null) || 'Не удалось отправить заявку';
        throw new Error(message);
    }
}
async function submitCallbackForm(data) {
    const res = await fetch(`${API_URL}/forms/callback`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        const message = err?.message || (Array.isArray(err?.message) ? err.message.join(', ') : null) || 'Не удалось отправить заявку';
        throw new Error(message);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/context/FormContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FormProvider",
    ()=>FormProvider,
    "useFormContext",
    ()=>useFormContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$forms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/forms.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const FormContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const FormProvider = ({ children })=>{
    _s();
    const [measurementModalOpen, setMeasurementModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [callbackModalOpen, setCallbackModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [directorMessageModalOpen, setDirectorMessageModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [formSubmission, setFormSubmission] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        loading: false,
        success: false,
        error: null
    });
    const resetFormSubmission = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FormProvider.useCallback[resetFormSubmission]": ()=>{
            setFormSubmission({
                loading: false,
                success: false,
                error: null
            });
        }
    }["FormProvider.useCallback[resetFormSubmission]"], []);
    const handleMeasurementSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FormProvider.useCallback[handleMeasurementSubmit]": async (data)=>{
            setFormSubmission({
                loading: true,
                success: false,
                error: null
            });
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$forms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["submitMeasurementForm"])({
                    name: data.name,
                    phone: data.phone,
                    email: data.email,
                    address: data.address,
                    preferredDate: data.preferredDate,
                    preferredTime: data.preferredTime,
                    productType: data.productType,
                    comments: data.comments
                });
                setFormSubmission({
                    loading: false,
                    success: true,
                    error: null
                });
            } catch (error) {
                setFormSubmission({
                    loading: false,
                    success: false,
                    error: error instanceof Error ? error.message : 'Произошла ошибка при отправке формы'
                });
            }
        }
    }["FormProvider.useCallback[handleMeasurementSubmit]"], []);
    const handleCallbackSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FormProvider.useCallback[handleCallbackSubmit]": async (data)=>{
            setFormSubmission({
                loading: true,
                success: false,
                error: null
            });
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$forms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["submitCallbackForm"])({
                    name: data.name,
                    phone: data.phone,
                    email: data.email,
                    preferredTime: data.preferredTime,
                    comment: data.comment
                });
                setFormSubmission({
                    loading: false,
                    success: true,
                    error: null
                });
            } catch (error) {
                setFormSubmission({
                    loading: false,
                    success: false,
                    error: error instanceof Error ? error.message : 'Произошла ошибка при отправке формы'
                });
            }
        }
    }["FormProvider.useCallback[handleCallbackSubmit]"], []);
    const handleDirectorMessageSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FormProvider.useCallback[handleDirectorMessageSubmit]": async (_data)=>{
            setFormSubmission({
                loading: true,
                success: false,
                error: null
            });
            try {
                // TODO: Заменить на реальный API вызов
                await new Promise({
                    "FormProvider.useCallback[handleDirectorMessageSubmit]": (resolve)=>setTimeout(resolve, 1000)
                }["FormProvider.useCallback[handleDirectorMessageSubmit]"]);
                setFormSubmission({
                    loading: false,
                    success: true,
                    error: null
                });
            } catch (error) {
                setFormSubmission({
                    loading: false,
                    success: false,
                    error: error instanceof Error ? error.message : 'Произошла ошибка при отправке формы'
                });
            }
        }
    }["FormProvider.useCallback[handleDirectorMessageSubmit]"], []);
    const handleCloseMeasurement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FormProvider.useCallback[handleCloseMeasurement]": ()=>{
            setMeasurementModalOpen(false);
            setTimeout({
                "FormProvider.useCallback[handleCloseMeasurement]": ()=>{
                    resetFormSubmission();
                }
            }["FormProvider.useCallback[handleCloseMeasurement]"], 300);
        }
    }["FormProvider.useCallback[handleCloseMeasurement]"], [
        resetFormSubmission
    ]);
    const handleCloseCallback = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FormProvider.useCallback[handleCloseCallback]": ()=>{
            setCallbackModalOpen(false);
            setTimeout({
                "FormProvider.useCallback[handleCloseCallback]": ()=>{
                    resetFormSubmission();
                }
            }["FormProvider.useCallback[handleCloseCallback]"], 300);
        }
    }["FormProvider.useCallback[handleCloseCallback]"], [
        resetFormSubmission
    ]);
    const handleCloseDirectorMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FormProvider.useCallback[handleCloseDirectorMessage]": ()=>{
            setDirectorMessageModalOpen(false);
            setTimeout({
                "FormProvider.useCallback[handleCloseDirectorMessage]": ()=>{
                    resetFormSubmission();
                }
            }["FormProvider.useCallback[handleCloseDirectorMessage]"], 300);
        }
    }["FormProvider.useCallback[handleCloseDirectorMessage]"], [
        resetFormSubmission
    ]);
    const measurementModal = {
        isOpen: measurementModalOpen,
        open: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
            "FormProvider.useCallback": ()=>{
                resetFormSubmission();
                setMeasurementModalOpen(true);
            }
        }["FormProvider.useCallback"], [
            resetFormSubmission
        ]),
        close: handleCloseMeasurement
    };
    const callbackModal = {
        isOpen: callbackModalOpen,
        open: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
            "FormProvider.useCallback": ()=>{
                resetFormSubmission();
                setCallbackModalOpen(true);
            }
        }["FormProvider.useCallback"], [
            resetFormSubmission
        ]),
        close: handleCloseCallback
    };
    const directorMessageModal = {
        isOpen: directorMessageModalOpen,
        open: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
            "FormProvider.useCallback": ()=>{
                resetFormSubmission();
                setDirectorMessageModalOpen(true);
            }
        }["FormProvider.useCallback"], [
            resetFormSubmission
        ]),
        close: handleCloseDirectorMessage
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FormContext.Provider, {
        value: {
            measurementModal,
            callbackModal,
            directorMessageModal,
            formSubmission,
            handleMeasurementSubmit,
            handleCallbackSubmit,
            handleDirectorMessageSubmit,
            handleCloseMeasurement,
            handleCloseCallback,
            handleCloseDirectorMessage
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/features/forms/context/FormContext.tsx",
        lineNumber: 160,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(FormProvider, "8mvc3jMP6g3ZSc7VBvyilawWM0E=");
_c = FormProvider;
const useFormContext = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(FormContext);
    if (!context) {
        throw new Error('useFormContext must be used within FormProvider');
    }
    return context;
};
_s1(useFormContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "FormProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/ui/Button/Button.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "base": "Button-module__fANS6W__base",
  "content": "Button-module__fANS6W__content",
  "disabled": "Button-module__fANS6W__disabled",
  "glow": "Button-module__fANS6W__glow",
  "lg": "Button-module__fANS6W__lg",
  "link": "Button-module__fANS6W__link",
  "md": "Button-module__fANS6W__md",
  "menu": "Button-module__fANS6W__menu",
  "outline": "Button-module__fANS6W__outline",
  "primary": "Button-module__fANS6W__primary",
  "secondary": "Button-module__fANS6W__secondary",
  "sm": "Button-module__fANS6W__sm",
});
}),
"[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.module.css [app-client] (css module)");
;
;
const Button = ({ children, onClick, variant = 'outline', size = 'md', className = '', type = 'button', disabled = false, style, 'data-action-button': dataActionButton })=>{
    const variantClass = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][variant] || '';
    const sizeClass = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][size] || '';
    const disabledClass = disabled ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].disabled : '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: type,
        onClick: onClick,
        disabled: disabled,
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].base} ${variantClass} ${sizeClass} ${disabledClass} ${className}`,
        style: style,
        "data-action-button": dataActionButton,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                children: children
            }, void 0, false, {
                fileName: "[project]/src/shared/ui/Button/Button.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].glow
            }, void 0, false, {
                fileName: "[project]/src/shared/ui/Button/Button.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/shared/ui/Button/Button.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/ActionButtons/ActionButton.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "button": "ActionButton-module__gOHhfq__button",
  "callback": "ActionButton-module__gOHhfq__callback",
  "disabled": "ActionButton-module__gOHhfq__disabled",
  "glow": "ActionButton-module__gOHhfq__glow",
  "measurement": "ActionButton-module__gOHhfq__measurement",
  "mobile": "ActionButton-module__gOHhfq__mobile",
  "mobileButtons": "ActionButton-module__gOHhfq__mobileButtons",
  "outline": "ActionButton-module__gOHhfq__outline",
});
}),
"[project]/src/features/forms/ui/ActionButtons/ActionButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActionButton",
    ()=>ActionButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/ActionButtons/ActionButton.module.css [app-client] (css module)");
;
;
;
const ActionButton = ({ variant, onClick, className = '', mobile = false })=>{
    const buttonText = {
        measurement: 'Записаться на замер',
        callback: 'Заказать звонок'
    }[variant];
    const buttonClass = `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][variant]} ${mobile ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobile : ''} ${className}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
        variant: "outline",
        onClick: onClick,
        className: buttonClass,
        "data-action-button": variant,
        children: buttonText
    }, void 0, false, {
        fileName: "[project]/src/features/forms/ui/ActionButtons/ActionButton.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = ActionButton;
var _c;
__turbopack_context__.k.register(_c, "ActionButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/ActionButtons/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/ActionButtons/ActionButton.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/ui/Modal/Modal.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "backdrop": "Modal-module__mNSHoW__backdrop",
  "center": "Modal-module__mNSHoW__center",
  "closeButton": "Modal-module__mNSHoW__closeButton",
  "closeIcon": "Modal-module__mNSHoW__closeIcon",
  "container": "Modal-module__mNSHoW__container",
  "content": "Modal-module__mNSHoW__content",
  "dialog": "Modal-module__mNSHoW__dialog",
  "header": "Modal-module__mNSHoW__header",
  "headerWithTitle": "Modal-module__mNSHoW__headerWithTitle",
  "headerWithoutTitle": "Modal-module__mNSHoW__headerWithoutTitle",
  "panel": "Modal-module__mNSHoW__panel",
  "sizeLg": "Modal-module__mNSHoW__sizeLg",
  "sizeMd": "Modal-module__mNSHoW__sizeMd",
  "sizeSm": "Modal-module__mNSHoW__sizeSm",
  "sizeXl": "Modal-module__mNSHoW__sizeXl",
  "title": "Modal-module__mNSHoW__title",
});
}),
"[project]/src/shared/ui/Modal/Modal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Modal",
    ()=>Modal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$dialog$2f$dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/dialog/dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js [app-client] (ecmascript) <export default as XMarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Modal/Modal.module.css [app-client] (css module)");
;
;
;
;
const Modal = ({ isOpen, onClose, children, title, size = 'md', showCloseButton = true })=>{
    const sizeClasses = {
        sm: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sizeSm,
        md: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sizeMd,
        lg: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sizeLg,
        xl: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sizeXl
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$dialog$2f$dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        as: "div",
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dialog,
        open: isOpen,
        onClose: onClose,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backdrop
            }, void 0, false, {
                fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].center,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$dialog$2f$dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"].Panel, {
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].panel} ${sizeClasses[size]}`,
                        children: [
                            (title || showCloseButton) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header} ${title ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerWithTitle : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerWithoutTitle}`,
                                children: [
                                    title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$dialog$2f$dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"].Title, {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                                        children: title
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                                        lineNumber: 44,
                                        columnNumber: 27
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    showCloseButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].closeButton,
                                        onClick: onClose,
                                        "aria-label": "Закрыть модальное окно",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].closeIcon
                                        }, void 0, false, {
                                            fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                                            lineNumber: 53,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                                        lineNumber: 47,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                                lineNumber: 41,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                                children: children
                            }, void 0, false, {
                                fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                                lineNumber: 59,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                        lineNumber: 39,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/shared/ui/Modal/Modal.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Modal;
var _c;
__turbopack_context__.k.register(_c, "Modal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/ui/Modal/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Modal/Modal.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/CallbackForm/CallbackForm.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "CallbackForm-module__mDpL8G__actions",
  "fieldContainer": "CallbackForm-module__mDpL8G__fieldContainer",
  "form": "CallbackForm-module__mDpL8G__form",
  "grid": "CallbackForm-module__mDpL8G__grid",
  "info": "CallbackForm-module__mDpL8G__info",
  "infoContent": "CallbackForm-module__mDpL8G__infoContent",
  "infoIcon": "CallbackForm-module__mDpL8G__infoIcon",
  "infoSubtext": "CallbackForm-module__mDpL8G__infoSubtext",
  "infoSvg": "CallbackForm-module__mDpL8G__infoSvg",
  "infoText": "CallbackForm-module__mDpL8G__infoText",
  "input": "CallbackForm-module__mDpL8G__input",
  "label": "CallbackForm-module__mDpL8G__label",
  "select": "CallbackForm-module__mDpL8G__select",
  "textarea": "CallbackForm-module__mDpL8G__textarea",
});
}),
"[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CallbackForm",
    ()=>CallbackForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/CallbackForm/CallbackForm.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const CallbackForm = ({ onSubmit, onCancel, loading = false })=>{
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        phone: '',
        email: '',
        preferredTime: '',
        comment: ''
    });
    const handleSubmit = (e)=>{
        e.preventDefault();
        onSubmit(formData);
    };
    const handleChange = (e)=>{
        setFormData((prev)=>({
                ...prev,
                [e.target.name]: e.target.value
            }));
    };
    const timeSlots = [
        'В любое время',
        'Утром (09:00-12:00)',
        'Днем (12:00-15:00)',
        'Вечером (15:00-18:00)',
        'После 18:00'
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit,
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].form,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: "Имя *"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                lineNumber: 50,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                name: "name",
                                required: true,
                                value: formData.name,
                                onChange: handleChange,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                                placeholder: "Ваше имя"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                lineNumber: 51,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: "Телефон *"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "tel",
                                name: "phone",
                                required: true,
                                value: formData.phone,
                                onChange: handleChange,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                                placeholder: "+7 (900) 123-45-67"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                lineNumber: 64,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Email"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "email",
                        name: "email",
                        value: formData.email || '',
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                        placeholder: "your@email.com"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Удобное время для звонка *"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 89,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        name: "preferredTime",
                        required: true,
                        value: formData.preferredTime,
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].select,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "Выберите время"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            timeSlots.map((time)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: time,
                                    children: time
                                }, time, false, {
                                    fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                    lineNumber: 99,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                lineNumber: 88,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Комментарий"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        name: "comment",
                        rows: 3,
                        value: formData.comment || '',
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].textarea,
                        placeholder: "Тема разговора, интересующие товары..."
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].info,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoContent,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoIcon,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoSvg,
                                fill: "currentColor",
                                viewBox: "0 0 20 20",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    fillRule: "evenodd",
                                    d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                                    clipRule: "evenodd"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                    lineNumber: 122,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                lineNumber: 121,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                            lineNumber: 120,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoText,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            children: "Мы перезвоним вам в течение 15 минут"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        " в выбранное время."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoSubtext,
                                    children: "Ответим на все вопросы и поможем с выбором!"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                                    lineNumber: 133,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                            lineNumber: 129,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                    lineNumber: 119,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                lineNumber: 118,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actions,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "button",
                        variant: "outline",
                        onClick: onCancel,
                        disabled: loading,
                        children: "Отмена"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 139,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "submit",
                        variant: "primary",
                        disabled: loading,
                        children: loading ? 'Отправка...' : 'Заказать звонок'
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                        lineNumber: 142,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
                lineNumber: 138,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CallbackForm, "qUnF3XIdFG8GsheWKZ5+YAmoQW0=");
_c = CallbackForm;
var _c;
__turbopack_context__.k.register(_c, "CallbackForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/CallbackForm/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "DirectorMessageForm-module__MAaAtW__actions",
  "fileHint": "DirectorMessageForm-module__MAaAtW__fileHint",
  "fileInput": "DirectorMessageForm-module__MAaAtW__fileInput",
  "form": "DirectorMessageForm-module__MAaAtW__form",
  "grid": "DirectorMessageForm-module__MAaAtW__grid",
  "info": "DirectorMessageForm-module__MAaAtW__info",
  "infoContent": "DirectorMessageForm-module__MAaAtW__infoContent",
  "infoIcon": "DirectorMessageForm-module__MAaAtW__infoIcon",
  "infoSubtext": "DirectorMessageForm-module__MAaAtW__infoSubtext",
  "infoSvg": "DirectorMessageForm-module__MAaAtW__infoSvg",
  "infoText": "DirectorMessageForm-module__MAaAtW__infoText",
  "input": "DirectorMessageForm-module__MAaAtW__input",
  "label": "DirectorMessageForm-module__MAaAtW__label",
  "select": "DirectorMessageForm-module__MAaAtW__select",
  "textarea": "DirectorMessageForm-module__MAaAtW__textarea",
});
}),
"[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DirectorMessageForm",
    ()=>DirectorMessageForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const DirectorMessageForm = ({ onSubmit, onCancel, loading = false })=>{
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
    });
    const handleSubmit = (e)=>{
        e.preventDefault();
        onSubmit(formData);
    };
    const handleChange = (e)=>{
        setFormData((prev)=>({
                ...prev,
                [e.target.name]: e.target.value
            }));
    };
    const handleFileChange = (e)=>{
        const file = e.target.files?.[0];
        setFormData((prev)=>({
                ...prev,
                attachment: file
            }));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit,
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].form,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: "Ваше имя *"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 55,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                name: "name",
                                required: true,
                                value: formData.name,
                                onChange: handleChange,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                                placeholder: "Иванов Иван"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 56,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: "Email *"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 68,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "email",
                                name: "email",
                                required: true,
                                value: formData.email,
                                onChange: handleChange,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                                placeholder: "your@email.com"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 69,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 67,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Телефон для связи"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "tel",
                        name: "phone",
                        value: formData.phone,
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                        placeholder: "+7 (900) 123-45-67"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 83,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Тема письма *"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        name: "subject",
                        required: true,
                        value: formData.subject,
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].select,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "Выберите тему"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 102,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "complaint",
                                children: "Жалоба"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 103,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "suggestion",
                                children: "Предложение"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 104,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "cooperation",
                                children: "Сотрудничество"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 105,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "question",
                                children: "Вопрос"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 106,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "other",
                                children: "Другое"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 107,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Сообщение *"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 112,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        name: "message",
                        rows: 6,
                        required: true,
                        value: formData.message,
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].textarea,
                        placeholder: "Опишите вашу ситуацию, вопрос или предложение подробно..."
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 113,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Прикрепить файл (опционально)"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 125,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "file",
                        name: "attachment",
                        onChange: handleFileChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fileInput,
                        accept: ".pdf,.doc,.docx,.jpg,.jpeg,.png"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fileHint,
                        children: "Поддерживаемые форматы: PDF, Word, JPG, PNG (макс. 10MB)"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 133,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                lineNumber: 124,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].info,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoContent,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoIcon,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoSvg,
                                fill: "currentColor",
                                viewBox: "0 0 20 20",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    fillRule: "evenodd",
                                    d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z",
                                    clipRule: "evenodd"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                    lineNumber: 140,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                lineNumber: 139,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoText,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: "Письмо будет отправлено непосредственно директору компании"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                        lineNumber: 149,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                    lineNumber: 148,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoSubtext,
                                    children: "Мы гарантируем конфиденциальность и ответ в течение 24 часов"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                                    lineNumber: 151,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                            lineNumber: 147,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                    lineNumber: 137,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                lineNumber: 136,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actions,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "button",
                        variant: "outline",
                        onClick: onCancel,
                        disabled: loading,
                        children: "Отмена"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 159,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "submit",
                        variant: "primary",
                        disabled: loading,
                        children: loading ? 'Отправка...' : 'Отправить письмо'
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                        lineNumber: 162,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
                lineNumber: 158,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(DirectorMessageForm, "rwbEfqMrTHN4cLumcI0DdNfsjPA=");
_c = DirectorMessageForm;
var _c;
__turbopack_context__.k.register(_c, "DirectorMessageForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/DirectorMessageForm/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "MeasurementForm-module__ew9DKa__actions",
  "form": "MeasurementForm-module__ew9DKa__form",
  "grid": "MeasurementForm-module__ew9DKa__grid",
  "info": "MeasurementForm-module__ew9DKa__info",
  "infoContent": "MeasurementForm-module__ew9DKa__infoContent",
  "infoIcon": "MeasurementForm-module__ew9DKa__infoIcon",
  "infoList": "MeasurementForm-module__ew9DKa__infoList",
  "infoSvg": "MeasurementForm-module__ew9DKa__infoSvg",
  "infoText": "MeasurementForm-module__ew9DKa__infoText",
  "input": "MeasurementForm-module__ew9DKa__input",
  "label": "MeasurementForm-module__ew9DKa__label",
  "select": "MeasurementForm-module__ew9DKa__select",
  "textarea": "MeasurementForm-module__ew9DKa__textarea",
});
}),
"[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MeasurementForm",
    ()=>MeasurementForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const MeasurementForm = ({ onSubmit, onCancel, loading = false })=>{
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        phone: '',
        email: '',
        address: '',
        preferredDate: '',
        preferredTime: '',
        productType: '',
        comments: ''
    });
    const handleSubmit = (e)=>{
        e.preventDefault();
        onSubmit(formData);
    };
    const handleChange = (e)=>{
        setFormData((prev)=>({
                ...prev,
                [e.target.name]: e.target.value
            }));
    };
    const getAvailableDates = ()=>{
        const dates = [];
        const today = new Date();
        for(let i = 1; i <= 7; i++){
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            if (date.getDay() !== 0 && date.getDay() !== 6) {
                dates.push(date.toISOString().split('T')[0]);
            }
        }
        return dates;
    };
    const timeSlots = [
        '09:00-11:00',
        '11:00-13:00',
        '13:00-15:00',
        '15:00-17:00',
        '17:00-19:00'
    ];
    const productTypes = [
        'Межкомнатные двери',
        'Входные двери',
        'Окна',
        'Потолки',
        'Жалюзи',
        'Мебель',
        'Не знаю, нужна консультация'
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit,
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].form,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: "Имя *"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 78,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                name: "name",
                                required: true,
                                value: formData.name,
                                onChange: handleChange,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                                placeholder: "Ваше имя"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: "Телефон *"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 91,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "tel",
                                name: "phone",
                                required: true,
                                value: formData.phone,
                                onChange: handleChange,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                                placeholder: "+7 (900) 123-45-67"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Email"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 105,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "email",
                        name: "email",
                        value: formData.email,
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                        placeholder: "your@email.com"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Адрес объекта *"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        name: "address",
                        required: true,
                        value: formData.address,
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input,
                        placeholder: "Город, улица, дом, квартира"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 118,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                lineNumber: 116,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: "Предпочтительная дата *"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 131,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                name: "preferredDate",
                                required: true,
                                value: formData.preferredDate,
                                onChange: handleChange,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].select,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "Выберите дату"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                        lineNumber: 139,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    getAvailableDates().map((date)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: date,
                                            children: new Date(date).toLocaleDateString('ru-RU', {
                                                weekday: 'short',
                                                day: 'numeric',
                                                month: 'long'
                                            })
                                        }, date, false, {
                                            fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                            lineNumber: 141,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 132,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 130,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: "Временной интервал *"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 153,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                name: "preferredTime",
                                required: true,
                                value: formData.preferredTime,
                                onChange: handleChange,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].select,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "Выберите время"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                        lineNumber: 161,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    timeSlots.map((time)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: time,
                                            children: time
                                        }, time, false, {
                                            fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                            lineNumber: 163,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 154,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 152,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                lineNumber: 129,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Интересующий товар"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 172,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        name: "productType",
                        value: formData.productType,
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].select,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "Не выбрано"
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 179,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            productTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: type,
                                    children: type
                                }, type, false, {
                                    fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                    lineNumber: 181,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 173,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                lineNumber: 171,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fieldContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                        children: "Комментарий"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 189,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        name: "comments",
                        rows: 3,
                        value: formData.comments,
                        onChange: handleChange,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].textarea,
                        placeholder: "Дополнительная информация, особые пожелания..."
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 190,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                lineNumber: 188,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].info,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoContent,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoIcon,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoSvg,
                                fill: "currentColor",
                                viewBox: "0 0 20 20",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    fillRule: "evenodd",
                                    d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z",
                                    clipRule: "evenodd"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                    lineNumber: 204,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                lineNumber: 203,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                            lineNumber: 202,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoText,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            children: "Бесплатный замер"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                            lineNumber: 213,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        " включает:"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                    lineNumber: 212,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoList,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: "Выезд специалиста в удобное для вас время"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                            lineNumber: 216,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: "Профессиональные замеры и консультация"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                            lineNumber: 217,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: "Расчет точной стоимости работ"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                            lineNumber: 218,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                                    lineNumber: 215,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                            lineNumber: 211,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                    lineNumber: 201,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                lineNumber: 200,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actions,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "button",
                        variant: "outline",
                        onClick: onCancel,
                        disabled: loading,
                        children: "Отмена"
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 225,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "submit",
                        variant: "primary",
                        disabled: loading,
                        children: loading ? 'Отправка...' : 'Записаться на замер'
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                        lineNumber: 228,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
                lineNumber: 224,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(MeasurementForm, "Xl1wgX5sob2GpTayrvNMNZNOeKc=");
_c = MeasurementForm;
var _c;
__turbopack_context__.k.register(_c, "MeasurementForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/MeasurementForm/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "container": "SuccessMessage-module__3v2sea__container",
  "icon": "SuccessMessage-module__3v2sea__icon",
  "message": "SuccessMessage-module__3v2sea__message",
  "title": "SuccessMessage-module__3v2sea__title",
});
}),
"[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SuccessMessage",
    ()=>SuccessMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CheckCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/CheckCircleIcon.js [app-client] (ecmascript) <export default as CheckCircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.module.css [app-client] (css module)");
;
;
;
;
const SuccessMessage = ({ title, message, onClose })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CheckCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircleIcon$3e$__["CheckCircleIcon"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
            }, void 0, false, {
                fileName: "[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                children: title
            }, void 0, false, {
                fileName: "[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].message,
                children: message
            }, void 0, false, {
                fileName: "[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                onClick: onClose,
                variant: "primary",
                children: "Закрыть"
            }, void 0, false, {
                fileName: "[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = SuccessMessage;
var _c;
__turbopack_context__.k.register(_c, "SuccessMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/SuccessMessage/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/FormModals/FormModals.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "error": "FormModals-module__IGHN_q__error",
  "modal": "FormModals-module__IGHN_q__modal",
});
}),
"[project]/src/features/forms/ui/FormModals/FormModals.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FormModals",
    ()=>FormModals
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Modal/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Modal/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/context/FormContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/ui/CallbackForm/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/CallbackForm/CallbackForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/ui/DirectorMessageForm/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/DirectorMessageForm/DirectorMessageForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/ui/MeasurementForm/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/MeasurementForm/MeasurementForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/ui/SuccessMessage/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/SuccessMessage/SuccessMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$FormModals$2f$FormModals$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/FormModals/FormModals.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const FormModals = ()=>{
    _s();
    const { measurementModal, callbackModal, directorMessageModal, formSubmission, handleMeasurementSubmit, handleCallbackSubmit, handleDirectorMessageSubmit, handleCloseMeasurement, handleCloseCallback, handleCloseDirectorMessage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Modal"], {
                isOpen: measurementModal.isOpen,
                onClose: handleCloseMeasurement,
                title: "Запись на бесплатный замер",
                size: "lg",
                children: [
                    formSubmission.success ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SuccessMessage"], {
                        title: "Заявка принята!",
                        message: "Наш специалист свяжется с вами в ближайшее время",
                        onClose: handleCloseMeasurement
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 38,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$MeasurementForm$2f$MeasurementForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeasurementForm"], {
                        onSubmit: handleMeasurementSubmit,
                        onCancel: handleCloseMeasurement,
                        loading: formSubmission.loading
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    formSubmission.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$FormModals$2f$FormModals$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                        children: formSubmission.error
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 50,
                        columnNumber: 34
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Modal"], {
                isOpen: callbackModal.isOpen,
                onClose: handleCloseCallback,
                title: "Заказ обратного звонка",
                size: "md",
                children: [
                    formSubmission.success ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SuccessMessage"], {
                        title: "Заявка принята!",
                        message: "Мы перезвоним вам в течение 15 минут",
                        onClose: handleCloseCallback
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 61,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$CallbackForm$2f$CallbackForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CallbackForm"], {
                        onSubmit: handleCallbackSubmit,
                        onCancel: handleCloseCallback,
                        loading: formSubmission.loading
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 67,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    formSubmission.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$FormModals$2f$FormModals$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                        children: formSubmission.error
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 73,
                        columnNumber: 34
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Modal$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Modal"], {
                isOpen: directorMessageModal.isOpen,
                onClose: handleCloseDirectorMessage,
                title: "Письмо директору",
                size: "lg",
                children: [
                    formSubmission.success ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$SuccessMessage$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SuccessMessage"], {
                        title: "Письмо отправлено!",
                        message: "Директор получит ваше сообщение и ответит в течение 24 часов",
                        onClose: handleCloseDirectorMessage
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 84,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$DirectorMessageForm$2f$DirectorMessageForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DirectorMessageForm"], {
                        onSubmit: handleDirectorMessageSubmit,
                        onCancel: handleCloseDirectorMessage,
                        loading: formSubmission.loading
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 90,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    formSubmission.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$FormModals$2f$FormModals$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                        children: formSubmission.error
                    }, void 0, false, {
                        fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                        lineNumber: 96,
                        columnNumber: 34
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/forms/ui/FormModals/FormModals.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(FormModals, "zR4sq8ECN6Z4jFkCN7lWaaKECPA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"]
    ];
});
_c = FormModals;
var _c;
__turbopack_context__.k.register(_c, "FormModals");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/ui/FormModals/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$FormModals$2f$FormModals$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/FormModals/FormModals.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/forms/index.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/context/FormContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/ui/ActionButtons/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$FormModals$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/ui/FormModals/index.ts [app-client] (ecmascript) <locals>");
'use client';
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ApprovedOrderGuardProvider",
    ()=>ApprovedOrderGuardProvider,
    "useApprovedOrderGuard",
    ()=>useApprovedOrderGuard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/user-orders.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const ApprovedOrderGuardContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const WARNING_TEXT = 'Завершите оформление заказа. При изменении состава заказа производится полное переоформление заказа. При этом все незавершённые заказы будут отменены! Продолжить?';
function ApprovedOrderGuardProvider({ children }) {
    _s();
    const [userOrders, setUserOrders] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pending, setPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [cancelInProgress, setCancelInProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const refreshOrders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ApprovedOrderGuardProvider.useCallback[refreshOrders]": async ()=>{
            try {
                const orders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserOrders"])();
                setUserOrders(orders);
            } catch  {
                setUserOrders([]);
            }
        }
    }["ApprovedOrderGuardProvider.useCallback[refreshOrders]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ApprovedOrderGuardProvider.useEffect": ()=>{
            refreshOrders();
        }
    }["ApprovedOrderGuardProvider.useEffect"], [
        refreshOrders
    ]);
    const approvedOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ApprovedOrderGuardProvider.useMemo[approvedOrder]": ()=>{
            if (!userOrders?.length) return null;
            const approved = userOrders.find({
                "ApprovedOrderGuardProvider.useMemo[approvedOrder].approved": (o)=>o.status === 'APPROVED' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApprovalRemainingMs"])(o.approvedAt ?? null, o.approvalValidMinutes) > 0
            }["ApprovedOrderGuardProvider.useMemo[approvedOrder].approved"]);
            return approved ?? null;
        }
    }["ApprovedOrderGuardProvider.useMemo[approvedOrder]"], [
        userOrders
    ]);
    const hasApprovedOrder = !!approvedOrder;
    const isCartItemInApprovedOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ApprovedOrderGuardProvider.useCallback[isCartItemInApprovedOrder]": (item)=>{
            if (!approvedOrder?.items?.length) return false;
            const productId = item.product?.id ?? item.component?.product?.id ?? item.productId;
            if (!productId) return false;
            const qty = Math.round(Number(item.quantity));
            const size = item.size ?? null;
            const opening = item.openingSide ?? null;
            return approvedOrder.items.some({
                "ApprovedOrderGuardProvider.useCallback[isCartItemInApprovedOrder]": (oi)=>oi.productId === productId && oi.quantity === qty && (oi.size ?? null) === size && (oi.openingSide ?? null) === opening
            }["ApprovedOrderGuardProvider.useCallback[isCartItemInApprovedOrder]"]);
        }
    }["ApprovedOrderGuardProvider.useCallback[isCartItemInApprovedOrder]"], [
        approvedOrder
    ]);
    const confirmBeforeCartChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ApprovedOrderGuardProvider.useCallback[confirmBeforeCartChange]": async (action, needConfirm)=>{
            if (!needConfirm || !approvedOrder) {
                await action();
                return true;
            }
            return new Promise({
                "ApprovedOrderGuardProvider.useCallback[confirmBeforeCartChange]": (resolve)=>{
                    setPending({
                        action,
                        orderId: approvedOrder.id,
                        resolve
                    });
                }
            }["ApprovedOrderGuardProvider.useCallback[confirmBeforeCartChange]"]);
        }
    }["ApprovedOrderGuardProvider.useCallback[confirmBeforeCartChange]"], [
        approvedOrder
    ]);
    const handleConfirm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ApprovedOrderGuardProvider.useCallback[handleConfirm]": async ()=>{
            if (!pending) return;
            setCancelInProgress(true);
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cancelOrderByCustomer"])(pending.orderId);
                await refreshOrders();
                await pending.action();
                pending.resolve(true);
            } catch (err) {
                pending.resolve(false);
                if (err instanceof Error) alert(err.message);
            } finally{
                setPending(null);
                setCancelInProgress(false);
            }
        }
    }["ApprovedOrderGuardProvider.useCallback[handleConfirm]"], [
        pending,
        refreshOrders
    ]);
    const handleCancel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ApprovedOrderGuardProvider.useCallback[handleCancel]": ()=>{
            if (pending) {
                pending.resolve(false);
                setPending(null);
            }
        }
    }["ApprovedOrderGuardProvider.useCallback[handleCancel]"], [
        pending
    ]);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ApprovedOrderGuardProvider.useMemo[value]": ()=>({
                hasApprovedOrder,
                approvedOrder,
                isCartItemInApprovedOrder,
                confirmBeforeCartChange,
                refreshOrders
            })
    }["ApprovedOrderGuardProvider.useMemo[value]"], [
        hasApprovedOrder,
        approvedOrder,
        isCartItemInApprovedOrder,
        confirmBeforeCartChange,
        refreshOrders
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ApprovedOrderGuardContext.Provider, {
        value: value,
        children: [
            children,
            pending && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "approved-order-guard-overlay",
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": "approved-order-guard-title",
                style: {
                    position: 'fixed',
                    inset: 0,
                    background: 'rgba(0,0,0,0.5)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    zIndex: 9999
                },
                onClick: (e)=>{
                    if (e.target === e.currentTarget) handleCancel();
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        background: 'var(--color-bg, #fff)',
                        borderRadius: 12,
                        padding: '1.25rem 1.5rem',
                        maxWidth: 420,
                        width: '90%',
                        boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)'
                    },
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            id: "approved-order-guard-title",
                            style: {
                                margin: '0 0 0.75rem 0',
                                fontSize: '1.125rem',
                                fontWeight: 600
                            },
                            children: "Изменение состава заказа"
                        }, void 0, false, {
                            fileName: "[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx",
                            lineNumber: 174,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                margin: '0 0 1rem 0',
                                fontSize: '0.9375rem',
                                color: '#374151'
                            },
                            children: WARNING_TEXT
                        }, void 0, false, {
                            fileName: "[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx",
                            lineNumber: 180,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                display: 'flex',
                                gap: '0.5rem',
                                justifyContent: 'flex-end'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: handleCancel,
                                    disabled: cancelInProgress,
                                    style: {
                                        padding: '0.5rem 1rem',
                                        background: '#f3f4f6',
                                        color: '#374151',
                                        border: 'none',
                                        borderRadius: 6,
                                        cursor: cancelInProgress ? 'not-allowed' : 'pointer',
                                        fontSize: '0.875rem'
                                    },
                                    children: "Нет"
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx",
                                    lineNumber: 184,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: handleConfirm,
                                    disabled: cancelInProgress,
                                    style: {
                                        padding: '0.5rem 1rem',
                                        background: '#d90652',
                                        color: '#fff',
                                        border: 'none',
                                        borderRadius: 6,
                                        cursor: cancelInProgress ? 'not-allowed' : 'pointer',
                                        fontSize: '0.875rem',
                                        fontWeight: 500
                                    },
                                    children: cancelInProgress ? 'Отмена заказа…' : 'Да'
                                }, void 0, false, {
                                    fileName: "[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx",
                                    lineNumber: 200,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx",
                            lineNumber: 183,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx",
                    lineNumber: 163,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx",
                lineNumber: 145,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
}
_s(ApprovedOrderGuardProvider, "AiRl946d56PzU2RGQcibl4e5wvs=");
_c = ApprovedOrderGuardProvider;
function useApprovedOrderGuard() {
    _s1();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ApprovedOrderGuardContext);
    if (ctx === undefined) {
        throw new Error('useApprovedOrderGuard must be used within ApprovedOrderGuardProvider');
    }
    return ctx;
}
_s1(useApprovedOrderGuard, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
__turbopack_context__.k.register(_c, "ApprovedOrderGuardProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/site-public.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSitePublicConfig",
    ()=>getSitePublicConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
async function getSitePublicConfig() {
    const res = await fetch(`${API_URL}/site-public/config`);
    if (!res.ok) throw new Error('Не удалось загрузить конфигурацию');
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/contexts/SitePublicConfigContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SitePublicConfigProvider",
    ()=>SitePublicConfigProvider,
    "useAdminLinkVisible",
    ()=>useAdminLinkVisible,
    "useSitePublicConfig",
    ()=>useSitePublicConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$site$2d$public$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/site-public.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
'use client';
;
;
const defaultValue = {
    rolesShowAdminLink: [],
    isLoading: true,
    error: null
};
const SitePublicConfigContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(defaultValue);
function SitePublicConfigProvider({ children }) {
    _s();
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultValue);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SitePublicConfigProvider.useEffect": ()=>{
            let cancelled = false;
            setState({
                "SitePublicConfigProvider.useEffect": (s)=>({
                        ...s,
                        isLoading: true,
                        error: null
                    })
            }["SitePublicConfigProvider.useEffect"]);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$site$2d$public$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSitePublicConfig"])().then({
                "SitePublicConfigProvider.useEffect": (data)=>{
                    if (!cancelled) {
                        setState({
                            rolesShowAdminLink: data.rolesShowAdminLink ?? [],
                            isLoading: false,
                            error: null
                        });
                    }
                }
            }["SitePublicConfigProvider.useEffect"]).catch({
                "SitePublicConfigProvider.useEffect": (err)=>{
                    if (!cancelled) {
                        setState({
                            rolesShowAdminLink: [],
                            isLoading: false,
                            error: err instanceof Error ? err : new Error(String(err))
                        });
                    }
                }
            }["SitePublicConfigProvider.useEffect"]);
            return ({
                "SitePublicConfigProvider.useEffect": ()=>{
                    cancelled = true;
                }
            })["SitePublicConfigProvider.useEffect"];
        }
    }["SitePublicConfigProvider.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SitePublicConfigContext.Provider, {
        value: state,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/shared/lib/contexts/SitePublicConfigContext.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_s(SitePublicConfigProvider, "TFlfEnMvFddJ5+eBFiEx+z8Lup0=");
_c = SitePublicConfigProvider;
function useSitePublicConfig() {
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(SitePublicConfigContext);
}
_s1(useSitePublicConfig, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
function useAdminLinkVisible() {
    _s2();
    const { rolesShowAdminLink } = useSitePublicConfig();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useAdminLinkVisible.useCallback": (userRole)=>{
            if (!userRole) return false;
            if (rolesShowAdminLink.length === 0) return false;
            return rolesShowAdminLink.includes(userRole);
        }
    }["useAdminLinkVisible.useCallback"], [
        rolesShowAdminLink
    ]);
}
_s2(useAdminLinkVisible, "o5XyaBFoXYp0efHDfYCi98cGAao=", false, function() {
    return [
        useSitePublicConfig
    ];
});
var _c;
__turbopack_context__.k.register(_c, "SitePublicConfigProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/background/Background/Background.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "background": "Background-module__Edy08a__background",
});
}),
"[project]/src/widgets/background/Background/Background.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Background",
    ()=>Background
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$background$2f$Background$2f$Background$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/background/Background/Background.module.css [app-client] (css module)");
'use client';
;
;
const Background = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$background$2f$Background$2f$Background$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].background,
        "aria-hidden": true
    }, void 0, false, {
        fileName: "[project]/src/widgets/background/Background/Background.tsx",
        lineNumber: 12,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Background;
var _c;
__turbopack_context__.k.register(_c, "Background");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/background/Background/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$background$2f$Background$2f$Background$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/background/Background/Background.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/background/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$background$2f$Background$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/background/Background/index.ts [app-client] (ecmascript) <locals>");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/chat-support/context/ChatSupportOpenContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChatSupportOpenProvider",
    ()=>ChatSupportOpenProvider,
    "useChatSupportOpen",
    ()=>useChatSupportOpen
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const ChatSupportOpenContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function ChatSupportOpenProvider({ children }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openChat = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSupportOpenProvider.useCallback[openChat]": ()=>setOpen(true)
    }["ChatSupportOpenProvider.useCallback[openChat]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ChatSupportOpenContext.Provider, {
        value: {
            open,
            setOpen,
            openChat
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/widgets/chat-support/context/ChatSupportOpenContext.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_s(ChatSupportOpenProvider, "YUC97PzH8XziRnS94Xlj6IkMOsU=");
_c = ChatSupportOpenProvider;
function useChatSupportOpen() {
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ChatSupportOpenContext);
}
_s1(useChatSupportOpen, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "ChatSupportOpenProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/auth/context/AuthContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const TOKEN_KEY = 'admin_token';
const USER_KEY = 'admin_user';
const USER_TOKEN_KEY = 'user_token';
const USER_DATA_KEY = 'user_data';
const ADMIN_ROLES = [
    'SUPER_ADMIN',
    'ADMIN',
    'CONTENT_MANAGER',
    'MODERATOR',
    'SUPPORT',
    'PARTNER',
    'BRIGADIER',
    'LEAD_SPECIALIST_FURNITURE',
    'LEAD_SPECIALIST_WINDOWS_DOORS',
    'SURVEYOR',
    'DRIVER',
    'INSTALLER'
];
function AuthProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [token, setToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[logout]": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.removeItem(TOKEN_KEY);
                localStorage.removeItem(USER_KEY);
                localStorage.removeItem(USER_TOKEN_KEY);
                localStorage.removeItem(USER_DATA_KEY);
                window.dispatchEvent(new Event('auth-token-changed'));
            }
            setToken(null);
            setUser(null);
        }
    }["AuthProvider.useCallback[logout]"], []);
    // Load auth state from localStorage on mount: admin_token, fallback на user_token (вход в ЛК даёт доступ в админку)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            let savedToken = localStorage.getItem(TOKEN_KEY);
            let savedUser = localStorage.getItem(USER_KEY);
            if (!savedToken || !savedUser) {
                savedToken = localStorage.getItem(USER_TOKEN_KEY);
                savedUser = localStorage.getItem(USER_DATA_KEY);
                if (savedToken && savedUser) {
                    try {
                        const parsed = JSON.parse(savedUser);
                        if (ADMIN_ROLES.includes(parsed.role)) {
                            localStorage.setItem(TOKEN_KEY, savedToken);
                            localStorage.setItem(USER_KEY, savedUser);
                        } else {
                            savedToken = null;
                            savedUser = null;
                        }
                    } catch  {
                        savedToken = null;
                        savedUser = null;
                    }
                }
            }
            if (savedToken && savedUser) {
                try {
                    const parsedUser = JSON.parse(savedUser);
                    setToken(savedToken);
                    setUser(parsedUser);
                    verifyToken(savedToken).then({
                        "AuthProvider.useEffect": (isValid)=>{
                            if (!isValid) {
                                logout();
                            }
                        }
                    }["AuthProvider.useEffect"]);
                } catch  {
                    logout();
                }
            }
            setIsLoading(false);
        }
    }["AuthProvider.useEffect"], [
        logout
    ]);
    const verifyToken = async (tokenToVerify)=>{
        try {
            const response = await fetch(`${API_URL}/auth/profile`, {
                headers: {
                    Authorization: `Bearer ${tokenToVerify}`
                }
            });
            return response.ok;
        } catch  {
            return false;
        }
    };
    const login = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[login]": async (email, password)=>{
            try {
                const response = await fetch(`${API_URL}/auth/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email,
                        password
                    })
                });
                if (!response.ok) {
                    const error = await response.json().catch({
                        "AuthProvider.useCallback[login]": ()=>({})
                    }["AuthProvider.useCallback[login]"]);
                    return {
                        success: false,
                        error: error.message || 'Неверный email или пароль'
                    };
                }
                const data = await response.json();
                const allowedRoles = [
                    'SUPER_ADMIN',
                    'ADMIN',
                    'CONTENT_MANAGER',
                    'MODERATOR',
                    'SUPPORT',
                    'PARTNER',
                    'BRIGADIER',
                    'LEAD_SPECIALIST_FURNITURE',
                    'LEAD_SPECIALIST_WINDOWS_DOORS',
                    'SURVEYOR',
                    'DRIVER',
                    'INSTALLER'
                ];
                if (!allowedRoles.includes(data.user.role)) {
                    return {
                        success: false,
                        error: 'У вас нет доступа к административной панели'
                    };
                }
                // Save to state and localStorage — один вход даёт доступ и в ЛК, и в админку
                setToken(data.access_token);
                setUser(data.user);
                localStorage.setItem(TOKEN_KEY, data.access_token);
                localStorage.setItem(USER_KEY, JSON.stringify(data.user));
                localStorage.setItem('user_token', data.access_token);
                localStorage.setItem('user_data', JSON.stringify(data.user));
                if ("TURBOPACK compile-time truthy", 1) {
                    window.dispatchEvent(new Event('auth-token-changed'));
                }
                return {
                    success: true
                };
            } catch (error) {
                console.error('Login error:', error);
                return {
                    success: false,
                    error: 'Ошибка подключения к серверу'
                };
            }
        }
    }["AuthProvider.useCallback[login]"], []);
    const refreshUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[refreshUser]": async ()=>{
            const savedToken = localStorage.getItem(TOKEN_KEY) || localStorage.getItem(USER_TOKEN_KEY);
            if (!savedToken) return;
            try {
                const response = await fetch(`${API_URL}/auth/profile`, {
                    headers: {
                        Authorization: `Bearer ${savedToken}`
                    }
                });
                if (response.ok) {
                    const userData = await response.json();
                    setUser(userData);
                    localStorage.setItem(USER_KEY, JSON.stringify(userData));
                    localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData));
                }
            } catch  {
            // ignore
            }
        }
    }["AuthProvider.useCallback[refreshUser]"], []);
    const getAuthHeaders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[getAuthHeaders]": ()=>{
            if (token) {
                return {
                    Authorization: `Bearer ${token}`
                };
            }
            return {};
        }
    }["AuthProvider.useCallback[getAuthHeaders]"], [
        token
    ]);
    // Синхронизация при обновлении профиля (публичка или другая вкладка)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            const handleUserUpdate = {
                "AuthProvider.useEffect.handleUserUpdate": ()=>{
                    const savedToken = localStorage.getItem(TOKEN_KEY) || localStorage.getItem(USER_TOKEN_KEY);
                    const savedUser = localStorage.getItem(USER_KEY) || localStorage.getItem(USER_DATA_KEY);
                    if (savedUser && savedToken) {
                        try {
                            const parsed = JSON.parse(savedUser);
                            if (ADMIN_ROLES.includes(parsed.role)) {
                                setUser(parsed);
                                setToken(savedToken);
                            } else {
                                setUser(null);
                                setToken(null);
                            }
                        } catch  {
                            setUser(null);
                            setToken(null);
                        }
                    } else {
                        setUser(null);
                        setToken(null);
                    }
                }
            }["AuthProvider.useEffect.handleUserUpdate"];
            const handleStorage = {
                "AuthProvider.useEffect.handleStorage": (e)=>{
                    if (e.key === USER_KEY || e.key === USER_DATA_KEY || e.key === TOKEN_KEY || e.key === USER_TOKEN_KEY) {
                        handleUserUpdate();
                    }
                }
            }["AuthProvider.useEffect.handleStorage"];
            window.addEventListener('auth-token-changed', handleUserUpdate);
            window.addEventListener('storage', handleStorage);
            return ({
                "AuthProvider.useEffect": ()=>{
                    window.removeEventListener('auth-token-changed', handleUserUpdate);
                    window.removeEventListener('storage', handleStorage);
                }
            })["AuthProvider.useEffect"];
        }
    }["AuthProvider.useEffect"], []);
    const value = {
        user,
        token,
        isLoading,
        isAuthenticated: !!token && !!user,
        isAdmin: [
            'SUPER_ADMIN',
            'ADMIN',
            'CONTENT_MANAGER',
            'MODERATOR',
            'SUPPORT',
            'PARTNER',
            'BRIGADIER',
            'LEAD_SPECIALIST_FURNITURE',
            'LEAD_SPECIALIST_WINDOWS_DOORS',
            'SURVEYOR',
            'DRIVER',
            'INSTALLER'
        ].includes(user?.role ?? ''),
        login,
        logout,
        refreshUser,
        getAuthHeaders
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/features/auth/context/AuthContext.tsx",
        lineNumber: 291,
        columnNumber: 10
    }, this);
}
_s(AuthProvider, "UbluTFdGTxQ4EVbKY/jP/GtYmR8=");
_c = AuthProvider;
function useAuth() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/auth/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/context/UserAuthContext.tsx [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/user-notifications.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkNewSupportReplies",
    ()=>checkNewSupportReplies,
    "getUserNotificationHistory",
    ()=>getUserNotificationHistory,
    "getUserNotificationSettings",
    ()=>getUserNotificationSettings,
    "updateUserNotificationSettings",
    ()=>updateUserNotificationSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function getUserAuthHeaders() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const token = localStorage.getItem('user_token') || localStorage.getItem('admin_token');
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
async function getUserNotificationSettings() {
    const res = await fetch(`${API_URL}/users/me/notification-settings`, {
        headers: getUserAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить настройки');
    return res.json();
}
async function updateUserNotificationSettings(data) {
    const res = await fetch(`${API_URL}/users/me/notification-settings`, {
        method: 'PATCH',
        headers: getUserAuthHeaders(),
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        const message = err?.message || (Array.isArray(err?.message) ? err.message.join(', ') : null) || 'Не удалось сохранить настройки';
        throw new Error(message);
    }
    return res.json();
}
async function getUserNotificationHistory(params) {
    const searchParams = new URLSearchParams();
    if (params?.page != null) searchParams.set('page', String(params.page));
    if (params?.limit != null) searchParams.set('limit', String(params.limit));
    const query = searchParams.toString();
    const url = `${API_URL}/users/me/notifications${query ? `?${query}` : ''}`;
    const res = await fetch(url, {
        headers: getUserAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить историю уведомлений');
    return res.json();
}
async function checkNewSupportReplies(since) {
    const params = new URLSearchParams({
        since
    });
    const res = await fetch(`${API_URL}/support/conversations/check-new-replies?${params}`, {
        headers: getUserAuthHeaders()
    });
    if (!res.ok) return {
        conversationIds: []
    };
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "ChatSupportWidget-module__AofmTq__active",
  "backBtn": "ChatSupportWidget-module__AofmTq__backBtn",
  "closeBtn": "ChatSupportWidget-module__AofmTq__closeBtn",
  "conversationItem": "ChatSupportWidget-module__AofmTq__conversationItem",
  "conversationList": "ChatSupportWidget-module__AofmTq__conversationList",
  "empty": "ChatSupportWidget-module__AofmTq__empty",
  "fab": "ChatSupportWidget-module__AofmTq__fab",
  "fabIcon": "ChatSupportWidget-module__AofmTq__fabIcon",
  "header": "ChatSupportWidget-module__AofmTq__header",
  "inputField": "ChatSupportWidget-module__AofmTq__inputField",
  "inputRow": "ChatSupportWidget-module__AofmTq__inputRow",
  "lastMessage": "ChatSupportWidget-module__AofmTq__lastMessage",
  "loading": "ChatSupportWidget-module__AofmTq__loading",
  "message": "ChatSupportWidget-module__AofmTq__message",
  "messageMeta": "ChatSupportWidget-module__AofmTq__messageMeta",
  "messagesArea": "ChatSupportWidget-module__AofmTq__messagesArea",
  "messagesList": "ChatSupportWidget-module__AofmTq__messagesList",
  "mine": "ChatSupportWidget-module__AofmTq__mine",
  "notifyRow": "ChatSupportWidget-module__AofmTq__notifyRow",
  "panel": "ChatSupportWidget-module__AofmTq__panel",
  "startNew": "ChatSupportWidget-module__AofmTq__startNew",
  "theirs": "ChatSupportWidget-module__AofmTq__theirs",
});
}),
"[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChatSupportWidget",
    ()=>ChatSupportWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChatBubbleLeftRightIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChatBubbleLeftRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ChatBubbleLeftRightIcon.js [app-client] (ecmascript) <export default as ChatBubbleLeftRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/auth/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/context/UserAuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$notifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/user-notifications.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/context/ChatSupportOpenContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const POLL_INTERVAL_MS = 60_000;
const STORAGE_KEY_PREFIX = 'support_chat_last_check_';
function ChatSupportWidget() {
    _s();
    const { isAuthenticated, getAuthHeaders, user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserAuth"])();
    const chatContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatSupportOpen"])();
    const [localOpen, setLocalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const open = chatContext ? chatContext.open : localOpen;
    const setOpen = chatContext ? chatContext.setOpen : setLocalOpen;
    const [conversations, setConversations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentConversation, setCurrentConversation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loadingMessages, setLoadingMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [sending, setSending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [notifyOnSupportReply, setNotifyOnSupportReply] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [savingNotify, setSavingNotify] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const pollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fetchConversations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSupportWidget.useCallback[fetchConversations]": async ()=>{
            if (!isAuthenticated) return;
            setLoading(true);
            try {
                const res = await fetch(`${API_URL}/support/conversations`, {
                    headers: getAuthHeaders()
                });
                if (res.ok) {
                    const data = await res.json();
                    setConversations(Array.isArray(data) ? data : []);
                }
            } catch (e) {
                console.error(e);
            } finally{
                setLoading(false);
            }
        }
    }["ChatSupportWidget.useCallback[fetchConversations]"], [
        isAuthenticated,
        getAuthHeaders
    ]);
    const fetchMessages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSupportWidget.useCallback[fetchMessages]": async (conversationId)=>{
            setLoadingMessages(true);
            try {
                const res = await fetch(`${API_URL}/support/conversations/${conversationId}/messages`, {
                    headers: getAuthHeaders()
                });
                if (res.ok) {
                    const data = await res.json();
                    setMessages(Array.isArray(data) ? data : []);
                }
            } catch (e) {
                console.error(e);
            } finally{
                setLoadingMessages(false);
            }
        }
    }["ChatSupportWidget.useCallback[fetchMessages]"], [
        getAuthHeaders
    ]);
    const loadNotificationSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSupportWidget.useCallback[loadNotificationSettings]": async ()=>{
            if (!isAuthenticated || !user) return;
            try {
                const s = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$notifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserNotificationSettings"])();
                setNotifyOnSupportReply(s.notifyOnSupportChatReply);
            } catch  {
                setNotifyOnSupportReply(true);
            }
        }
    }["ChatSupportWidget.useCallback[loadNotificationSettings]"], [
        isAuthenticated,
        user
    ]);
    const handleNotifyToggle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSupportWidget.useCallback[handleNotifyToggle]": async (checked)=>{
            setNotifyOnSupportReply(checked);
            setSavingNotify(true);
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$notifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateUserNotificationSettings"])({
                    notifyOnSupportChatReply: checked
                });
                if (checked && ("TURBOPACK compile-time value", "object") !== 'undefined' && 'Notification' in window) {
                    if (Notification.permission === 'default') {
                        await Notification.requestPermission();
                    }
                }
            } catch (e) {
                console.error(e);
                setNotifyOnSupportReply(!checked);
            } finally{
                setSavingNotify(false);
            }
        }
    }["ChatSupportWidget.useCallback[handleNotifyToggle]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSupportWidget.useEffect": ()=>{
            if (isAuthenticated && user) {
                loadNotificationSettings();
            }
        }
    }["ChatSupportWidget.useEffect"], [
        isAuthenticated,
        user,
        loadNotificationSettings
    ]);
    const pollForNewReplies = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatSupportWidget.useCallback[pollForNewReplies]": async ()=>{
            if (!user?.id || !notifyOnSupportReply || ("TURBOPACK compile-time value", "object") === 'undefined') return;
            const key = STORAGE_KEY_PREFIX + user.id;
            const lastCheck = localStorage.getItem(key);
            if (!lastCheck) {
                localStorage.setItem(key, new Date().toISOString());
                return;
            }
            try {
                const { conversationIds } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$notifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkNewSupportReplies"])(lastCheck);
                localStorage.setItem(key, new Date().toISOString());
                if (conversationIds.length > 0 && 'Notification' in window) {
                    if (Notification.permission === 'granted') {
                        new Notification('Чат поддержки', {
                            body: conversationIds.length === 1 ? 'Вам ответили в чате поддержки' : `Новые ответы в ${conversationIds.length} диалогах`,
                            icon: '/favicon.svg'
                        });
                    }
                }
            } catch  {
            // ignore
            }
        }
    }["ChatSupportWidget.useCallback[pollForNewReplies]"], [
        user?.id,
        notifyOnSupportReply
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSupportWidget.useEffect": ()=>{
            if (!isAuthenticated || !user || !notifyOnSupportReply) return;
            pollForNewReplies();
            pollRef.current = setInterval(pollForNewReplies, POLL_INTERVAL_MS);
            return ({
                "ChatSupportWidget.useEffect": ()=>{
                    if (pollRef.current) {
                        clearInterval(pollRef.current);
                        pollRef.current = null;
                    }
                }
            })["ChatSupportWidget.useEffect"];
        }
    }["ChatSupportWidget.useEffect"], [
        isAuthenticated,
        user,
        notifyOnSupportReply,
        pollForNewReplies
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSupportWidget.useEffect": ()=>{
            if (open && currentConversation?.id && user?.id && ("TURBOPACK compile-time value", "object") !== 'undefined') {
                localStorage.setItem(STORAGE_KEY_PREFIX + user.id, new Date().toISOString());
            }
        }
    }["ChatSupportWidget.useEffect"], [
        open,
        currentConversation?.id,
        user?.id
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSupportWidget.useEffect": ()=>{
            if (open && isAuthenticated) {
                fetchConversations();
            }
        }
    }["ChatSupportWidget.useEffect"], [
        open,
        isAuthenticated,
        fetchConversations
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatSupportWidget.useEffect": ()=>{
            if (currentConversation?.id) {
                fetchMessages(currentConversation.id);
            } else {
                setMessages([]);
            }
        }
    }["ChatSupportWidget.useEffect"], [
        currentConversation?.id,
        fetchMessages
    ]);
    const startConversation = async ()=>{
        try {
            const res = await fetch(`${API_URL}/support/conversations`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    ...getAuthHeaders()
                }
            });
            if (res.ok) {
                const conv = await res.json();
                setConversations((prev)=>[
                        conv,
                        ...prev
                    ]);
                setCurrentConversation(conv);
            }
        } catch (e) {
            console.error(e);
        }
    };
    const sendMessage = async ()=>{
        const text = input.trim();
        if (!text || !currentConversation || sending) return;
        setSending(true);
        setInput('');
        try {
            const res = await fetch(`${API_URL}/support/conversations/${currentConversation.id}/messages`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    ...getAuthHeaders()
                },
                body: JSON.stringify({
                    content: text
                })
            });
            if (res.ok) {
                const msg = await res.json();
                setMessages((prev)=>[
                        ...prev,
                        msg
                    ]);
            } else {
                setInput(text);
            }
        } catch (e) {
            setInput(text);
            console.error(e);
        } finally{
            setSending(false);
        }
    };
    const formatDate = (s)=>{
        const d = new Date(s);
        const now = new Date();
        if (d.toDateString() === now.toDateString()) {
            return d.toLocaleTimeString('ru-RU', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }
        return d.toLocaleDateString('ru-RU', {
            day: '2-digit',
            month: '2-digit'
        }) + ' ' + d.toLocaleTimeString('ru-RU', {
            hour: '2-digit',
            minute: '2-digit'
        });
    };
    if (!isAuthenticated || !user) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fab,
                onClick: ()=>setOpen((o)=>!o),
                "aria-label": "Чат поддержки",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChatBubbleLeftRightIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChatBubbleLeftRightIcon$3e$__["ChatBubbleLeftRightIcon"], {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fabIcon
                }, void 0, false, {
                    fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                    lineNumber: 262,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                lineNumber: 256,
                columnNumber: 7
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].panel,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                        children: [
                            currentConversation ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backBtn,
                                        onClick: ()=>setCurrentConversation(null),
                                        children: "← Назад"
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                        lineNumber: 269,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Чат с поддержкой"
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                        lineNumber: 276,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Чат поддержки"
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                lineNumber: 279,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].closeBtn,
                                onClick: ()=>setOpen(false),
                                children: "×"
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                lineNumber: 281,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                        lineNumber: 266,
                        columnNumber: 11
                    }, this),
                    !currentConversation ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading,
                            children: "Загрузка диалогов..."
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                            lineNumber: 288,
                            columnNumber: 17
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].notifyRow,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            id: "notifySupportReply",
                                            checked: notifyOnSupportReply,
                                            onChange: (e)=>handleNotifyToggle(e.target.checked),
                                            disabled: savingNotify
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                            lineNumber: 292,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            htmlFor: "notifySupportReply",
                                            children: "Уведомлять при ответе в чате"
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                            lineNumber: 299,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                    lineNumber: 291,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].startNew,
                                    onClick: startConversation,
                                    children: "Начать новый диалог"
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                    lineNumber: 301,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].conversationList,
                                    children: conversations.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].conversationItem,
                                            onClick: ()=>setCurrentConversation(c),
                                            children: [
                                                "Диалог #",
                                                c.id.slice(-6),
                                                c.messages?.[0] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].lastMessage,
                                                    children: c.messages[0].content
                                                }, void 0, false, {
                                                    fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                                    lineNumber: 314,
                                                    columnNumber: 27
                                                }, this)
                                            ]
                                        }, c.id, true, {
                                            fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                            lineNumber: 306,
                                            columnNumber: 23
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                    lineNumber: 304,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true)
                    }, void 0, false) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messagesArea,
                        children: [
                            loadingMessages ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading,
                                children: "Загрузка сообщений..."
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                lineNumber: 325,
                                columnNumber: 17
                            }, this) : messages.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
                                children: "Напишите сообщение — специалист поддержки ответит вам."
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                lineNumber: 327,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messagesList,
                                children: messages.map((m)=>{
                                    const isMine = m.senderId === user.id;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].message} ${isMine ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mine : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].theirs}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: m.content
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                                lineNumber: 339,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messageMeta,
                                                children: [
                                                    !isMine && m.sender.firstName && `${m.sender.firstName} · `,
                                                    formatDate(m.createdAt)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                                lineNumber: 340,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, m.id, true, {
                                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                        lineNumber: 335,
                                        columnNumber: 23
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                lineNumber: 331,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].notifyRow,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "checkbox",
                                        id: "notifySupportReplyInChat",
                                        checked: notifyOnSupportReply,
                                        onChange: (e)=>handleNotifyToggle(e.target.checked),
                                        disabled: savingNotify
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                        lineNumber: 350,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "notifySupportReplyInChat",
                                        children: "Уведомлять при ответе"
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                        lineNumber: 357,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                lineNumber: 349,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputRow,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                        placeholder: "Введите сообщение...",
                                        value: input,
                                        onChange: (e)=>setInput(e.target.value),
                                        onKeyDown: (e)=>{
                                            if (e.key === 'Enter' && !e.shiftKey) {
                                                e.preventDefault();
                                                sendMessage();
                                            }
                                        },
                                        rows: 2,
                                        "aria-label": "Сообщение"
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                        lineNumber: 360,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: sendMessage,
                                        disabled: sending || !input.trim(),
                                        children: "Отправить"
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                        lineNumber: 374,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                                lineNumber: 359,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                        lineNumber: 323,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx",
                lineNumber: 265,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(ChatSupportWidget, "HUDpKUW56fmrVlP1qBNv7Xinooo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatSupportOpen"]
    ];
});
_c = ChatSupportWidget;
var _c;
__turbopack_context__.k.register(_c, "ChatSupportWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/chat-support/ChatSupportWidget/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/chat-support/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/context/ChatSupportOpenContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/ChatSupportWidget/index.ts [app-client] (ecmascript) <locals>");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/Footer/Footer.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "footer": "Footer-module__T_nkIq__footer",
});
}),
"[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "bottom": "FooterBottom-module__ht1_Gq__bottom",
  "container": "FooterBottom-module__ht1_Gq__container",
  "content": "FooterBottom-module__ht1_Gq__content",
  "copyright": "FooterBottom-module__ht1_Gq__copyright",
  "developer": "FooterBottom-module__ht1_Gq__developer",
});
}),
"[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FooterBottom",
    ()=>FooterBottom
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$FooterBottom$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.module.css [app-client] (css module)");
;
;
const FooterBottom = ({ copyrightCompanyName, developer, email })=>{
    const currentYear = new Date().getFullYear();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$FooterBottom$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].bottom,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$FooterBottom$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$FooterBottom$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$FooterBottom$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].copyright,
                    children: [
                        currentYear,
                        " «",
                        copyrightCompanyName,
                        "»"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.tsx",
                    lineNumber: 22,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.tsx",
                lineNumber: 21,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = FooterBottom;
var _c;
__turbopack_context__.k.register(_c, "FooterBottom");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/Footer/FooterBottom/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$FooterBottom$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/sanitize.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Утилиты для защиты от XSS (межсайтового скриптинга).
 * sanitizeHtml использует dompurify только на клиенте; на сервере — лёгкий fallback
 * (избегает isomorphic-dompurify/jsdom, вызывающего ENOENT в Next.js Turbopack).
 */ /** Разрешённые теги для контента статей блога (rich text) */ __turbopack_context__.s([
    "escapeHtmlAndPreserveNewlines",
    ()=>escapeHtmlAndPreserveNewlines,
    "getSafeHref",
    ()=>getSafeHref,
    "sanitizeHtml",
    ()=>sanitizeHtml,
    "stripHtmlToText",
    ()=>stripHtmlToText
]);
const ALLOWED_BLOG_TAGS = [
    'p',
    'br',
    'strong',
    'b',
    'em',
    'i',
    'u',
    's',
    'a',
    'ul',
    'ol',
    'li',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6',
    'blockquote',
    'pre',
    'code',
    'img',
    'figure',
    'figcaption',
    'hr',
    'span',
    'div'
];
/** Разрешённые атрибуты для ссылок и изображений */ const ALLOWED_ATTR = [
    'href',
    'src',
    'alt',
    'title',
    'class'
];
/**
 * Лёгкая санитизация на сервере (без jsdom, без ReDoS).
 * Удаляет script/iframe/object целиком и атрибуты on*.
 */ function sanitizeHtmlServer(html) {
    const tags = [
        'script',
        'iframe',
        'object',
        'embed'
    ];
    let out = html;
    for (const tag of tags){
        for(;;){
            const lower = out.toLowerCase();
            const i = lower.indexOf(`<${tag}`);
            if (i === -1) break;
            const endTag = `</${tag}>`;
            const endIdx = lower.indexOf(endTag, i);
            const end = endIdx === -1 ? out.indexOf('>', i) + 1 : endIdx + endTag.length;
            if (end <= 0) break;
            out = out.slice(0, i) + out.slice(end);
        }
    }
    // Удаляем on* атрибуты
    out = out.replace(/\s+on\w+\s*=\s*["'][^"']*["']/gi, '');
    out = out.replace(/\s+on\w+\s*=\s*[^\s>]+/gi, '');
    return out;
}
function sanitizeHtml(html) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    // Клиент: dompurify (только в браузере)
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const DOMPurify = __turbopack_context__.r("[project]/node_modules/dompurify/dist/purify.cjs.js [app-client] (ecmascript)");
    return DOMPurify.sanitize(html, {
        ALLOWED_TAGS: ALLOWED_BLOG_TAGS,
        ALLOWED_ATTR: ALLOWED_ATTR
    });
}
function escapeHtmlAndPreserveNewlines(text) {
    const escaped = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;');
    return escaped.replace(/\n/g, '<br />');
}
/** Опасные протоколы в href, приводящие к XSS */ const UNSAFE_HREF_PROTOCOLS = /^(javascript|data|vbscript|file):/i;
function getSafeHref(href, fallback = '#') {
    if (href == null || typeof href !== 'string') return fallback;
    const trimmed = href.trim();
    if (!trimmed) return fallback;
    if (trimmed.startsWith('/') || trimmed.startsWith('#')) return trimmed;
    if (UNSAFE_HREF_PROTOCOLS.test(trimmed)) return fallback;
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://') || trimmed.startsWith('mailto:') || trimmed.startsWith('tel:')) {
        return trimmed;
    }
    return fallback;
}
/**
 * Удаляет HTML-теги без ReDoS (безопасная замена /<[^>]*>/g).
 * Использует индексный поиск вместо regex для избежания катастрофического backtracking.
 */ function stripHtmlTags(s) {
    let result = '';
    let i = 0;
    while(i < s.length){
        const lt = s.indexOf('<', i);
        if (lt === -1) {
            result += s.slice(i);
            break;
        }
        result += s.slice(i, lt) + ' ';
        const gt = s.indexOf('>', lt + 1);
        i = gt === -1 ? s.length : gt + 1;
    }
    return result;
}
function stripHtmlToText(html) {
    return stripHtmlTags(html).replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/\s+/g, ' ').trim();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/ui/Logo/Logo.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "bounce": "Logo-module__9m0YzG__bounce",
  "color1": "Logo-module__9m0YzG__color1",
  "color2": "Logo-module__9m0YzG__color2",
  "color3": "Logo-module__9m0YzG__color3",
  "color4": "Logo-module__9m0YzG__color4",
  "color5": "Logo-module__9m0YzG__color5",
  "colorPulse1": "Logo-module__9m0YzG__colorPulse1",
  "colorPulse2": "Logo-module__9m0YzG__colorPulse2",
  "colorPulse3": "Logo-module__9m0YzG__colorPulse3",
  "colorPulse4": "Logo-module__9m0YzG__colorPulse4",
  "colorPulse4Dark": "Logo-module__9m0YzG__colorPulse4Dark",
  "colorPulse5": "Logo-module__9m0YzG__colorPulse5",
  "colorPulse5Dark": "Logo-module__9m0YzG__colorPulse5Dark",
  "logo": "Logo-module__9m0YzG__logo",
  "logoLink": "Logo-module__9m0YzG__logoLink",
});
}),
"[project]/src/shared/ui/Logo/Logo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Logo",
    ()=>Logo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Logo/Logo.module.css [app-client] (css module)");
;
;
;
const Logo = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: "/",
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoLink,
        "aria-label": "На главную",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logo,
            viewBox: "0 0 847.15 237.78",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            preserveAspectRatio: "xMidYMid meet",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M194.48 88.67 111.63 5.82C108.46 2.6 104.24.86 99.71.86S90.97 2.6 87.79 5.82L4.96 88.67C1.74 91.84 0 96.06 0 100.59v120.33c0 9.26 7.57 16.87 16.87 16.87h165.69c9.31 0 16.87-7.61 16.87-16.87V100.59c0-4.52-1.74-8.74-4.96-11.92Zm-2 132.24c0 5.44-4.44 9.92-9.91 9.92H16.87c-5.48 0-9.91-4.48-9.91-9.92V100.58c0-2.61 1.04-5.17 2.87-7l82.88-82.84c3.74-3.78 10.26-3.74 14 0l82.84 82.84c1.91 1.87 2.91 4.35 2.91 7v120.33Z",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color5
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    width: "50.4",
                    height: "49.13",
                    x: "44.58",
                    y: "91.91",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color3,
                    rx: "12.18",
                    ry: "12.18"
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    width: "50.4",
                    height: "49.13",
                    x: "104.45",
                    y: "91.91",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color1,
                    rx: "12.18",
                    ry: "12.18"
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    width: "50.4",
                    height: "49.13",
                    x: "44.58",
                    y: "149.92",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color2,
                    rx: "12.18",
                    ry: "12.18"
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    width: "50.4",
                    height: "49.13",
                    x: "104.45",
                    y: "149.92",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color5,
                    rx: "12.18",
                    ry: "12.18"
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 48,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    width: "29.29",
                    height: "28.55",
                    x: "230.93",
                    y: "16.68",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color3,
                    rx: "5.22",
                    ry: "5.22"
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 57,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    width: "29.29",
                    height: "28.55",
                    x: "230.93",
                    y: "92.46",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color1,
                    rx: "5.22",
                    ry: "5.22"
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    width: "29.29",
                    height: "28.55",
                    x: "232.75",
                    y: "181.81",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color2,
                    rx: "5.22",
                    ry: "5.22"
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 75,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M322.98 10.33h-18.59v50.73h-10.33V10.33h-18.51V.87h47.43zm51.03 41.36v9.37h-42.06V.87h40.94v9.37h-30.53v15.65h27.08v9.2h-27.08v16.6zm55.66-40.84c-1.91-3.21-4.66-5.68-8.29-7.4-3.58-1.72-7.82-2.56-12.66-2.56h-23.09v60.19h10.43V43.72h12.66c4.84 0 9.08-.88 12.66-2.61 3.63-1.72 6.38-4.19 8.29-7.45 1.96-3.21 2.89-7.03 2.89-11.36s-.93-8.24-2.89-11.45m-11.13 20.3c-2.33 2.05-5.77 3.07-10.33 3.07h-12.15V10.33h12.15c4.56 0 8.01 1.02 10.33 3.07 2.37 2.09 3.54 5.03 3.54 8.89s-1.16 6.75-3.54 8.84Zm67.97-20.3c-1.96-3.21-4.7-5.68-8.33-7.4-3.58-1.72-7.82-2.56-12.66-2.56h-23.09v60.19h10.43V43.72h12.66c4.84 0 9.08-.88 12.66-2.61 3.63-1.72 6.38-4.19 8.33-7.45 1.91-3.21 2.89-7.03 2.89-11.36s-.98-8.24-2.89-11.45m-11.17 20.3c-2.33 2.05-5.77 3.07-10.33 3.07h-12.15V10.33h12.15c4.56 0 8.01 1.02 10.33 3.07 2.37 2.09 3.54 5.03 3.54 8.89s-1.16 6.75-3.54 8.84ZM499.3.87h10.26V43.6L539.68.87h9.7v60.19h-10.26V18.41L509 61.06h-9.7zm106.48 9.46h-18.59v50.73h-10.33V10.33h-18.51V.87h47.43zm60.42 4.71c-2.65-4.7-6.24-8.38-10.85-11.03-4.56-2.65-9.73-4-15.46-4s-10.85 1.35-15.46 4-8.19 6.38-10.8 11.08c-2.65 4.75-3.96 10.01-3.96 15.87s1.3 11.13 3.96 15.87c2.61 4.75 6.19 8.43 10.8 11.08s9.73 4 15.46 4 10.89-1.35 15.46-4c4.61-2.65 8.19-6.33 10.85-11.03 2.61-4.7 3.91-10.01 3.91-15.92s-1.3-11.22-3.91-15.92m-9.17 26.81c-1.68 3.21-4.05 5.77-7.03 7.54-2.98 1.82-6.38 2.75-10.1 2.75s-7.08-.93-10.1-2.75c-2.98-1.77-5.31-4.33-7.03-7.54-1.72-3.26-2.56-6.89-2.56-10.89s.84-7.63 2.56-10.89c1.72-3.21 4.05-5.73 7.03-7.54 3.03-1.82 6.38-2.7 10.1-2.7s7.12.88 10.1 2.7 5.35 4.33 7.03 7.54c1.72 3.26 2.61 6.89 2.61 10.89s-.88 7.63-2.61 10.89m68.66-31c-1.91-3.21-4.66-5.68-8.29-7.4-3.58-1.72-7.82-2.56-12.71-2.56h-23.04v60.19h10.38V43.72h12.66c4.89 0 9.12-.88 12.71-2.61 3.63-1.72 6.38-4.19 8.29-7.45 1.91-3.21 2.89-7.03 2.89-11.36s-.98-8.24-2.89-11.45m-11.13 20.3c-2.37 2.05-5.77 3.07-10.33 3.07h-12.2V10.33h12.2c4.56 0 7.96 1.02 10.33 3.07 2.33 2.09 3.54 5.03 3.54 8.89s-1.21 6.75-3.54 8.84ZM738.53.87h10.25V43.6L778.9.87h9.7v60.19h-10.26V18.41l-30.12 42.65h-9.69zm85.3.01c-4.75 0-8.89.84-12.38 2.61-3.54 1.77-6.28 4.28-8.19 7.59-1.91 3.35-2.89 7.31-2.89 11.87 0 4.8 1.07 8.85 3.17 12.2 2.09 3.35 5.12 5.77 9.03 7.36l-12.01 18.57h10.94l10.43-16.81h14.99v16.81h10.24V.88h-23.32Zm13.08 34.31h-13.13c-4.19 0-7.36-1.07-9.54-3.26-2.19-2.14-3.31-5.17-3.31-9.12s1.16-7.17 3.4-9.31c2.28-2.09 5.54-3.17 9.82-3.17h12.76zm-561.35 92.62V85.67h7.7v29.92l22.64-29.92h7.28v42.14h-7.7V97.95l-22.64 29.86zm87.1-42.14h7.83v42.14h-7.83v-18.06h-21.79v18.06h-7.82V85.67h7.82v17.4h21.79zm58.27 0v6.62h-13.97v35.52h-7.76V92.29h-13.91v-6.62zm22.63 35.58h23.77v6.56h-31.6V85.67h30.76v6.56h-22.93v10.96h20.34v6.44h-20.34zm71.03-31.58c-3.21-2.67-7.59-4-13.12-4h-17.34v42.13h7.82v-12.17h9.52c5.53 0 9.9-1.33 13.12-4.03 3.21-2.69 4.82-6.34 4.82-10.95s-1.61-8.32-4.82-10.98m-5.72 17.19c-1.77 1.44-4.35 2.16-7.76 2.16h-9.15V92.29h9.15c3.41 0 5.99.73 7.76 2.16 1.77 1.44 2.65 3.52 2.65 6.2s-.88 4.76-2.65 6.2Zm57.09-3.52c-2.71-2.26-6.59-3.4-11.64-3.4h-11.68V85.67h-7.71v42.13h18.12c5.39 0 9.56-1.23 12.53-3.71 2.97-2.47 4.46-6.02 4.46-10.68s-1.36-7.81-4.07-10.08Zm-6.22 16.35c-1.65 1.4-4 2.1-7.04 2.1h-10.05V105.9h10.05c6.34 0 9.51 2.56 9.51 7.65 0 2.69-.82 4.74-2.47 6.14m34.18 1.56h23.78v6.56h-31.6V85.67h30.76v6.56h-22.94v10.96h20.35v6.44h-20.35zm71.03-31.58c-3.2-2.67-7.58-4-13.12-4h-17.34v42.13h7.82v-12.17h9.52c5.54 0 9.91-1.33 13.12-4.03 3.21-2.69 4.82-6.34 4.82-10.95s-1.61-8.32-4.82-10.98m-5.71 17.19q-2.67 2.16-7.77 2.16h-9.15V92.29h9.15c3.41 0 5.99.73 7.77 2.16 1.76 1.44 2.65 3.52 2.65 6.2s-.89 4.76-2.65 6.2Zm55.61-21.19h7.83v42.14h-7.83v-18.06h-21.79v18.06h-7.82V85.67h7.82v17.4h21.79zm58.78 17.67c-2.71-2.26-6.59-3.4-11.65-3.4h-11.67V85.67h-7.71v42.13h18.12c5.38 0 9.55-1.23 12.52-3.71 2.97-2.47 4.46-6.02 4.46-10.68s-1.35-7.81-4.06-10.08Zm-6.22 16.35c-1.66 1.4-4 2.1-7.05 2.1h-10.04V105.9h10.04c6.35 0 9.52 2.56 9.52 7.65 0 2.69-.83 4.74-2.47 6.14m16.36-34.02h7.71v42.14h-7.71zm23.48 0h9.03l9.93 14.08 9.93-14.08h9.15l-14.14 20.23 15.29 21.91h-9.27l-10.96-15.35-10.89 15.35h-9.03l15.23-21.61zm-473.59 85.88c-2.53-4.21-6.19-7.49-10.91-9.77-4.8-2.23-10.4-3.37-16.76-3.37h-30.44v79.37h13.73v-22.9H306c6.36 0 11.96-1.14 16.76-3.37 4.72-2.27 8.38-5.6 10.91-9.81 2.53-4.29 3.83-9.26 3.83-15.03s-1.31-10.86-3.83-15.12Zm-14.65 26.78c-3.16 2.74-7.66 4.08-13.64 4.08h-16.08v-31.54h16.08c5.98 0 10.48 1.35 13.64 4.13 3.07 2.69 4.59 6.57 4.59 11.66s-1.52 8.97-4.59 11.66Zm86.89 27.1v12.35h-55.44v-79.35h53.96v12.36h-40.23v20.63h35.7v12.13h-35.7v21.88zm110.37-67v79.35h-94.95v-79.35h13.52v66.88h27.25v-66.88h13.52v66.88h27.14v-66.88zm76.25 67v12.35h-55.45v-79.35h53.97v12.36H550.8v20.63h35.7v12.13h-35.7v21.88zm81-67v79.35H659.8v-34.01h-38.23v34.01h-13.74v-79.35h13.74v32.76h38.23v-32.76zm20.81 0h13.52v56.34l39.7-56.34h12.79v79.35h-13.52v-56.22l-39.71 56.22h-12.78zm86.81 0h13.52v56.34l39.71-56.34h12.78v79.35h-13.52v-56.22l-39.71 56.22h-12.78z",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color4
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 84,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    width: "11.39",
                    height: "31.27",
                    x: "808.45",
                    y: "133.14",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].color4,
                    rx: ".51",
                    ry: ".51",
                    transform: "rotate(-90 814.145 148.775)"
                }, void 0, false, {
                    fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
                    lineNumber: 88,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
            lineNumber: 10,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/shared/ui/Logo/Logo.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Logo;
var _c;
__turbopack_context__.k.register(_c, "Logo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/ui/Logo/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Logo/Logo.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "contactInfo": "ContactSection-module__EUuwbG__contactInfo",
  "directorButton": "ContactSection-module__EUuwbG__directorButton",
  "phone": "ContactSection-module__EUuwbG__phone",
  "section": "ContactSection-module__EUuwbG__section",
  "social": "ContactSection-module__EUuwbG__social",
  "socialIcon": "ContactSection-module__EUuwbG__socialIcon",
  "socialLink": "ContactSection-module__EUuwbG__socialLink",
  "socialText": "ContactSection-module__EUuwbG__socialText",
  "subtitle": "ContactSection-module__EUuwbG__subtitle",
  "text": "ContactSection-module__EUuwbG__text",
  "title": "ContactSection-module__EUuwbG__title",
});
}),
"[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContactSection",
    ()=>ContactSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/index.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/context/FormContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/ActionButtons/ActionButton.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/sanitize.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const ContactSection = ({ companyInfo, socialLinks })=>{
    _s();
    const { directorMessageModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const handleDirectorMessage = ()=>{
        directorMessageModal.open();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                children: "Контакты"
            }, void 0, false, {
                fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactInfo,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].phone,
                        children: companyInfo.phone
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                        children: "Режим работы"
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                        lineNumber: 31,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].text,
                        children: companyInfo.workingHours.weekdays
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                        lineNumber: 32,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].text,
                        children: companyInfo.workingHours.saturday
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].text,
                        children: companyInfo.workingHours.sunday
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        variant: "outline",
                        onClick: handleDirectorMessage,
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].callback} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].directorButton}`,
                        "data-action-button": "callback",
                        children: "Письмо директору"
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].social,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].socialText,
                        children: "Мы в соцсетях:"
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(socialLinks.vk.href),
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].socialLink,
                        "aria-label": socialLinks.vk.ariaLabel,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: socialLinks.vk.icon,
                            alt: "VK",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].socialIcon,
                            loading: "lazy"
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ContactSection, "iX82YgKi3+pBdyVQLjKp4XmTMwQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"]
    ];
});
_c = ContactSection;
var _c;
__turbopack_context__.k.register(_c, "ContactSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/Footer/FooterSections/ContactSection/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/Footer/FooterSections/FooterSections.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "container": "FooterSections-module__QQhMma__container",
  "grid": "FooterSections-module__QQhMma__grid",
  "link": "FooterSections-module__QQhMma__link",
  "list": "FooterSections-module__QQhMma__list",
  "logoColumn": "FooterSections-module__QQhMma__logoColumn",
  "section": "FooterSections-module__QQhMma__section",
  "sectionTitle": "FooterSections-module__QQhMma__sectionTitle",
  "sections": "FooterSections-module__QQhMma__sections",
});
}),
"[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FooterSections",
    ()=>FooterSections
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/sanitize.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Logo/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Logo/Logo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterSections/ContactSection/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterSections/ContactSection/ContactSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterSections/FooterSections.module.css [app-client] (css module)");
;
;
;
;
;
function LinkSection({ title, links }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle,
                children: title
            }, void 0, false, {
                fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].list,
                children: links.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(link.href),
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link,
                            children: link.name
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                            lineNumber: 37,
                            columnNumber: 13
                        }, this)
                    }, link.id, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_c = LinkSection;
const FooterSections = ({ sections, companyInfo, socialLinks })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sections,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoColumn,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logo"], {}, void 0, false, {
                            fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                            lineNumber: 57,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                        lineNumber: 56,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    sections.map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinkSection, {
                            title: section.title,
                            links: section.links
                        }, section.id || `section-${section.title}`, false, {
                            fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                            lineNumber: 60,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$ContactSection$2f$ContactSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContactSection"], {
                        companyInfo: companyInfo,
                        socialLinks: socialLinks
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                        lineNumber: 66,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
                lineNumber: 55,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
            lineNumber: 54,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = FooterSections;
var _c, _c1;
__turbopack_context__.k.register(_c, "LinkSection");
__turbopack_context__.k.register(_c1, "FooterSections");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/Footer/FooterSections/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/Footer/Footer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Footer",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/Footer.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterBottom/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$FooterBottom$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterBottom/FooterBottom.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterSections/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/FooterSections/FooterSections.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const defaultData = {
    block: {
        workingHours: {
            weekdays: 'пн-пт: 11-19',
            saturday: 'сб: 12-16',
            sunday: 'вс: выходной'
        },
        phone: '8 (8152) 60-12-70',
        email: 'skvirya@mail.ru',
        developer: 'ИП Сквиря Р.В.',
        copyrightCompanyName: 'Территория интерьерных решений',
        socialLinks: {
            vk: {
                name: 'ВКонтакте',
                href: 'https://vk.com/pskpobeda',
                icon: '/images/icons-vk.png',
                ariaLabel: 'ВКонтакте'
            }
        }
    },
    sections: [
        {
            id: '',
            title: 'О нас',
            sortOrder: 0,
            links: [
                {
                    id: '1',
                    name: 'Контакты',
                    href: '/contacts',
                    sortOrder: 0
                },
                {
                    id: '2',
                    name: 'Наши работы',
                    href: '/portfolio',
                    sortOrder: 1
                },
                {
                    id: '3',
                    name: 'Вакансии',
                    href: '/careers',
                    sortOrder: 2
                }
            ]
        },
        {
            id: '',
            title: 'Каталог',
            sortOrder: 1,
            links: [
                {
                    id: '4',
                    name: 'Ремонт квартир',
                    href: '/repair',
                    sortOrder: 0
                },
                {
                    id: '5',
                    name: 'Двери',
                    href: '/doors',
                    sortOrder: 1
                },
                {
                    id: '6',
                    name: 'Окна',
                    href: '/windows',
                    sortOrder: 2
                },
                {
                    id: '7',
                    name: 'Потолки',
                    href: '/ceilings',
                    sortOrder: 3
                },
                {
                    id: '8',
                    name: 'Жалюзи',
                    href: '/blinds',
                    sortOrder: 4
                },
                {
                    id: '9',
                    name: 'Мебель',
                    href: '/furniture',
                    sortOrder: 5
                },
                {
                    id: '10',
                    name: 'Акции',
                    href: '/sales',
                    sortOrder: 6
                }
            ]
        }
    ]
};
const Footer = ()=>{
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Footer.useEffect": ()=>{
            let cancelled = false;
            const fetchData = {
                "Footer.useEffect.fetchData": async ()=>{
                    try {
                        const res = await fetch(`${API_URL}/home/footer`);
                        if (!cancelled && res.ok) {
                            const d = await res.json();
                            setData(d);
                        } else if (!cancelled) {
                            setData(defaultData);
                        }
                    } catch  {
                        if (!cancelled) setData(defaultData);
                    }
                }
            }["Footer.useEffect.fetchData"];
            fetchData();
            return ({
                "Footer.useEffect": ()=>{
                    cancelled = true;
                }
            })["Footer.useEffect"];
        }
    }["Footer.useEffect"], []);
    const footerData = data ?? defaultData;
    const uniqueSections = footerData.sections.filter((section, index, arr)=>arr.findIndex((s)=>s.title === section.title) === index);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footer,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterSections$2f$FooterSections$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FooterSections"], {
                sections: uniqueSections,
                companyInfo: {
                    workingHours: footerData.block.workingHours,
                    phone: footerData.block.phone,
                    email: footerData.block.email,
                    developer: footerData.block.developer
                },
                socialLinks: footerData.block.socialLinks
            }, void 0, false, {
                fileName: "[project]/src/widgets/footer/Footer/Footer.tsx",
                lineNumber: 116,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$FooterBottom$2f$FooterBottom$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FooterBottom"], {
                copyrightCompanyName: footerData.block.copyrightCompanyName,
                developer: footerData.block.developer,
                email: footerData.block.email
            }, void 0, false, {
                fileName: "[project]/src/widgets/footer/Footer/Footer.tsx",
                lineNumber: 126,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/footer/Footer/Footer.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Footer, "fQZRxy/+nAZ7NLS1X4dVhrlp8Go=");
_c = Footer;
var _c;
__turbopack_context__.k.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/Footer/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/Footer.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/footer/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/index.ts [app-client] (ecmascript) <locals>");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/ActionButtons/ActionButtons.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "button": "ActionButtons-module__66a7Ha__button",
  "desktopButtons": "ActionButtons-module__66a7Ha__desktopButtons",
  "menuButton": "ActionButtons-module__66a7Ha__menuButton",
  "menuIcon": "ActionButtons-module__66a7Ha__menuIcon",
  "mobileButtons": "ActionButtons-module__66a7Ha__mobileButtons",
  "mobileMenuButton": "ActionButtons-module__66a7Ha__mobileMenuButton",
  "phone": "ActionButtons-module__66a7Ha__phone",
  "phoneBlock": "ActionButtons-module__66a7Ha__phoneBlock",
  "phoneLabel": "ActionButtons-module__66a7Ha__phoneLabel",
});
}),
"[project]/src/widgets/header/ActionButtons/ActionButtons.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActionButtons",
    ()=>ActionButtons
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Bars3Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bars3Icon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Bars3Icon.js [app-client] (ecmascript) <export default as Bars3Icon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/index.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/ActionButtons/ActionButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/context/FormContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/header/ActionButtons/ActionButtons.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const ActionButtons = ({ onMobileMenuOpen, mobile = false })=>{
    _s();
    const { measurementModal, callbackModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const phoneBlock = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].phoneBlock,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].phoneLabel,
                children: "Наш телефон"
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "tel:+78152601270",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].phone,
                children: "8-(8152)-60-12-70"
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
    if (mobile) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileButtons,
            children: [
                phoneBlock,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionButton"], {
                    variant: "callback",
                    onClick: callbackModal.open,
                    mobile: true
                }, void 0, false, {
                    fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionButton"], {
                    variant: "measurement",
                    onClick: measurementModal.open,
                    mobile: true
                }, void 0, false, {
                    fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
            lineNumber: 34,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].desktopButtons,
                children: [
                    phoneBlock,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionButton"], {
                        variant: "callback",
                        onClick: callbackModal.open
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionButton"], {
                        variant: "measurement",
                        onClick: measurementModal.open
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileMenuButton,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuButton,
                    onClick: onMobileMenuOpen,
                    "aria-label": "Открыть меню",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Bars3Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bars3Icon$3e$__["Bars3Icon"], {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuIcon
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                        lineNumber: 57,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/ActionButtons/ActionButtons.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(ActionButtons, "mBPU4MeoR4nIjqHXL4kXDw664Fk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"]
    ];
});
_c = ActionButtons;
var _c;
__turbopack_context__.k.register(_c, "ActionButtons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/ActionButtons/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/ActionButtons/ActionButtons.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/hooks/useDropdown.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDropdown",
    ()=>useDropdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const CLOSE_DELAY_MS = 150; // Задержка перед закрытием для плавного перехода
const useDropdown = ()=>{
    _s();
    const [activeDropdown, setActiveDropdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const closeTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isOverNavItemRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const isOverDropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // Очистка таймера закрытия
    const clearCloseTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDropdown.useCallback[clearCloseTimeout]": ()=>{
            if (closeTimeoutRef.current) {
                clearTimeout(closeTimeoutRef.current);
                closeTimeoutRef.current = null;
            }
        }
    }["useDropdown.useCallback[clearCloseTimeout]"], []);
    // Проверка, нужно ли закрывать меню
    const shouldClose = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDropdown.useCallback[shouldClose]": ()=>{
            return !isOverNavItemRef.current && !isOverDropdownRef.current;
        }
    }["useDropdown.useCallback[shouldClose]"], []);
    const scheduleClose = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDropdown.useCallback[scheduleClose]": ()=>{
            clearCloseTimeout();
            closeTimeoutRef.current = setTimeout({
                "useDropdown.useCallback[scheduleClose]": ()=>{
                    if (shouldClose()) {
                        setActiveDropdown(null);
                    }
                }
            }["useDropdown.useCallback[scheduleClose]"], CLOSE_DELAY_MS);
        }
    }["useDropdown.useCallback[scheduleClose]"], [
        clearCloseTimeout,
        shouldClose
    ]);
    const openDropdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDropdown.useCallback[openDropdown]": (name)=>{
            clearCloseTimeout();
            isOverNavItemRef.current = true;
            setActiveDropdown(name);
        }
    }["useDropdown.useCallback[openDropdown]"], [
        clearCloseTimeout
    ]);
    const closeDropdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDropdown.useCallback[closeDropdown]": ()=>{
            // Курсор ушёл с кнопки навигации
            isOverNavItemRef.current = false;
            scheduleClose();
        }
    }["useDropdown.useCallback[closeDropdown]"], [
        scheduleClose
    ]);
    const handleDropdownMouseEnter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDropdown.useCallback[handleDropdownMouseEnter]": ()=>{
            // Курсор над dropdown — отменяем закрытие
            isOverDropdownRef.current = true;
            clearCloseTimeout();
        }
    }["useDropdown.useCallback[handleDropdownMouseEnter]"], [
        clearCloseTimeout
    ]);
    const handleDropdownMouseLeave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDropdown.useCallback[handleDropdownMouseLeave]": ()=>{
            // Курсор ушёл с dropdown — планируем закрытие
            isOverDropdownRef.current = false;
            scheduleClose();
        }
    }["useDropdown.useCallback[handleDropdownMouseLeave]"], [
        scheduleClose
    ]);
    return {
        activeDropdown,
        openDropdown,
        closeDropdown,
        handleDropdownMouseEnter,
        handleDropdownMouseLeave
    };
};
_s(useDropdown, "h+HfIGSZfBk5+hP67tL9ggPyNUE=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/hooks/useDynamicCategories.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDynamicCategories",
    ()=>useDynamicCategories
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function useDynamicCategories() {
    _s();
    const [categories, setCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [navigationCategories, setNavigationCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchCategories = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDynamicCategories.useCallback[fetchCategories]": async ()=>{
            try {
                setLoading(true);
                const response = await fetch(`${API_URL}/categories`);
                if (!response.ok) {
                    throw new Error('Failed to fetch categories');
                }
                const data = await response.json();
                setCategories(data);
                // Преобразуем в формат навигации
                const navCategories = data.map({
                    "useDynamicCategories.useCallback[fetchCategories].navCategories": (root)=>({
                            name: root.name,
                            slug: root.slug,
                            href: `/catalog/products/${root.slug}`,
                            productCount: root._count?.products || 0,
                            icon: root.icon,
                            image: root.image,
                            hasSubmenu: (root.children?.length || 0) > 0,
                            submenu: (root.children || []).map({
                                "useDynamicCategories.useCallback[fetchCategories].navCategories": (child)=>{
                                    return {
                                        name: child.name,
                                        slug: child.slug,
                                        // Используем полный slug подкатегории для URL
                                        href: `/catalog/products/${root.slug}/${child.slug}`,
                                        productCount: child._count?.products || 0,
                                        icon: child.icon,
                                        image: child.image
                                    };
                                }
                            }["useDynamicCategories.useCallback[fetchCategories].navCategories"])
                        })
                }["useDynamicCategories.useCallback[fetchCategories].navCategories"]);
                setNavigationCategories(navCategories);
                setError(null);
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Unknown error');
            } finally{
                setLoading(false);
            }
        }
    }["useDynamicCategories.useCallback[fetchCategories]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDynamicCategories.useEffect": ()=>{
            fetchCategories();
        }
    }["useDynamicCategories.useEffect"], [
        fetchCategories
    ]);
    return {
        categories,
        navigationCategories,
        loading,
        error,
        refetch: fetchCategories
    };
}
_s(useDynamicCategories, "W5ersVG72wna7kMptgRW8FM0eik=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/hooks/useDynamicServiceCategories.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDynamicServiceCategories",
    ()=>useDynamicServiceCategories
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function useDynamicServiceCategories() {
    _s();
    const [serviceCategories, setServiceCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const fetchServiceCategories = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDynamicServiceCategories.useCallback[fetchServiceCategories]": async ()=>{
            try {
                const res = await fetch(`${API_URL}/service-catalog`);
                if (!res.ok) return;
                const data = await res.json();
                const categories = data?.categories ?? [];
                setServiceCategories(categories.map({
                    "useDynamicServiceCategories.useCallback[fetchServiceCategories]": (cat)=>({
                            id: cat.id,
                            name: cat.name,
                            slug: cat.slug,
                            href: `/catalog/services/${cat.slug}`,
                            icon: cat.icon ?? null,
                            image: cat.image ?? null
                        })
                }["useDynamicServiceCategories.useCallback[fetchServiceCategories]"]));
            } catch  {
                setServiceCategories([]);
            }
        }
    }["useDynamicServiceCategories.useCallback[fetchServiceCategories]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDynamicServiceCategories.useEffect": ()=>{
            fetchServiceCategories();
        }
    }["useDynamicServiceCategories.useEffect"], [
        fetchServiceCategories
    ]);
    return {
        serviceCategories,
        refetch: fetchServiceCategories
    };
}
_s(useDynamicServiceCategories, "P4rqJiSDA9rMtfVQcYleA+B882E=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/hooks/useNavigationItems.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$NavigationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/NavigationContext.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/hooks/useCompare.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CompareContext.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/hooks/useCart.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CartContext.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/api/catalog-settings.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCatalogSettings",
    ()=>getCatalogSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
async function getCatalogSettings() {
    const res = await fetch(`${API_URL}/catalog/settings`);
    if (!res.ok) throw new Error('Не удалось загрузить настройки каталога');
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/hooks/useMobileCatalogColumns.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMobileCatalogColumns",
    ()=>useMobileCatalogColumns
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/context/UserAuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$catalog$2d$settings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/catalog-settings.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$notifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/user-notifications.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function useMobileCatalogColumns() {
    _s();
    const [columns, setColumns] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const { isAuthenticated } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserAuth"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMobileCatalogColumns.useEffect": ()=>{
            let cancelled = false;
            async function resolve() {
                try {
                    const [catalogSettings, userSettings] = await Promise.all([
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$catalog$2d$settings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCatalogSettings"])(),
                        isAuthenticated ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$notifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserNotificationSettings"])().catch({
                            "useMobileCatalogColumns.useEffect.resolve": ()=>null
                        }["useMobileCatalogColumns.useEffect.resolve"]) : null
                    ]);
                    if (cancelled) return;
                    const defaultCols = catalogSettings?.defaultMobileCatalogColumns ?? 1;
                    const userCols = userSettings?.mobileCatalogColumns;
                    const effective = userCols != null ? userCols : defaultCols;
                    setColumns(effective);
                } catch  {
                    if (!cancelled) setColumns(1);
                }
            }
            resolve();
            return ({
                "useMobileCatalogColumns.useEffect": ()=>{
                    cancelled = true;
                }
            })["useMobileCatalogColumns.useEffect"];
        }
    }["useMobileCatalogColumns.useEffect"], [
        isAuthenticated
    ]);
    return columns;
}
_s(useMobileCatalogColumns, "mpxPDWIxjIULe1IFnuSAV5E3IJU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserAuth"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDropdown$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useDropdown.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useDynamicCategories.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicServiceCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useDynamicServiceCategories.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useNavigationItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useNavigationItems.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/WishlistContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useCompare$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useCompare.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useCart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useCart.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useMobileCatalogColumns$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useMobileCatalogColumns.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "categoryIcon": "NavigationItem-module___wVJsa__categoryIcon",
  "categoryImage": "NavigationItem-module___wVJsa__categoryImage",
  "chevron": "NavigationItem-module___wVJsa__chevron",
  "chevronActive": "NavigationItem-module___wVJsa__chevronActive",
  "disabled": "NavigationItem-module___wVJsa__disabled",
  "dropdown": "NavigationItem-module___wVJsa__dropdown",
  "dropdownCenter": "NavigationItem-module___wVJsa__dropdownCenter",
  "dropdownContent": "NavigationItem-module___wVJsa__dropdownContent",
  "dropdownGrid": "NavigationItem-module___wVJsa__dropdownGrid",
  "dropdownItem": "NavigationItem-module___wVJsa__dropdownItem",
  "dropdownItemIcon": "NavigationItem-module___wVJsa__dropdownItemIcon",
  "dropdownItemIconWrapper": "NavigationItem-module___wVJsa__dropdownItemIconWrapper",
  "dropdownItemText": "NavigationItem-module___wVJsa__dropdownItemText",
  "dropdownItemTextBold": "NavigationItem-module___wVJsa__dropdownItemTextBold",
  "dropdownRight": "NavigationItem-module___wVJsa__dropdownRight",
  "dropdownSection": "NavigationItem-module___wVJsa__dropdownSection",
  "dropdownSectionInner": "NavigationItem-module___wVJsa__dropdownSectionInner",
  "navButton": "NavigationItem-module___wVJsa__navButton",
  "navButtonCurrentLine": "NavigationItem-module___wVJsa__navButtonCurrentLine",
  "navButtonWrap": "NavigationItem-module___wVJsa__navButtonWrap",
  "navItem": "NavigationItem-module___wVJsa__navItem",
  "navText": "NavigationItem-module___wVJsa__navText",
  "submenu": "NavigationItem-module___wVJsa__submenu",
  "submenuItem": "NavigationItem-module___wVJsa__submenuItem",
  "submenuItemIcon": "NavigationItem-module___wVJsa__submenuItemIcon",
  "submenuItemImage": "NavigationItem-module___wVJsa__submenuItemImage",
});
}),
"[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NavigationItem",
    ()=>NavigationItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BoltIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BoltIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BoltIcon.js [app-client] (ecmascript) <export default as BoltIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BuildingOfficeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BuildingOfficeIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BuildingOfficeIcon.js [app-client] (ecmascript) <export default as BuildingOfficeIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CubeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CubeIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/CubeIcon.js [app-client] (ecmascript) <export default as CubeIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CubeTransparentIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CubeTransparentIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/CubeTransparentIcon.js [app-client] (ecmascript) <export default as CubeTransparentIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$DocumentTextIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DocumentTextIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/DocumentTextIcon.js [app-client] (ecmascript) <export default as DocumentTextIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$HomeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HomeIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/HomeIcon.js [app-client] (ecmascript) <export default as HomeIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$LightBulbIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LightBulbIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/LightBulbIcon.js [app-client] (ecmascript) <export default as LightBulbIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MoonIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoonIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MoonIcon.js [app-client] (ecmascript) <export default as MoonIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PaintBrushIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PaintBrushIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/PaintBrushIcon.js [app-client] (ecmascript) <export default as PaintBrushIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$RectangleStackIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RectangleStackIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/RectangleStackIcon.js [app-client] (ecmascript) <export default as RectangleStackIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Square3Stack3DIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Square3Stack3DIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Square3Stack3DIcon.js [app-client] (ecmascript) <export default as Square3Stack3DIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Squares2X2Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Squares2X2Icon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Squares2X2Icon.js [app-client] (ecmascript) <export default as Squares2X2Icon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TableCellsIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCellsIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/TableCellsIcon.js [app-client] (ecmascript) <export default as TableCellsIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TagIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TagIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/TagIcon.js [app-client] (ecmascript) <export default as TagIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ViewColumnsIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ViewColumnsIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ViewColumnsIcon.js [app-client] (ecmascript) <export default as ViewColumnsIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$WrenchScrewdriverIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__WrenchScrewdriverIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/WrenchScrewdriverIcon.js [app-client] (ecmascript) <export default as WrenchScrewdriverIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$constants$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/constants/navigation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/sanitize.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
// Маппинг имен иконок на компоненты
const iconMap = {
    RectangleStack: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$RectangleStackIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RectangleStackIcon$3e$__["RectangleStackIcon"],
    WrenchScrewdriver: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$WrenchScrewdriverIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__WrenchScrewdriverIcon$3e$__["WrenchScrewdriverIcon"],
    Squares2X2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Squares2X2Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Squares2X2Icon$3e$__["Squares2X2Icon"],
    ViewColumns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ViewColumnsIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ViewColumnsIcon$3e$__["ViewColumnsIcon"],
    Cube: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CubeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CubeIcon$3e$__["CubeIcon"],
    Home: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$HomeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HomeIcon$3e$__["HomeIcon"],
    TableCells: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TableCellsIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableCellsIcon$3e$__["TableCellsIcon"],
    Moon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MoonIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoonIcon$3e$__["MoonIcon"],
    CubeTransparent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CubeTransparentIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CubeTransparentIcon$3e$__["CubeTransparentIcon"],
    LightBulb: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$LightBulbIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LightBulbIcon$3e$__["LightBulbIcon"],
    PaintBrush: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PaintBrushIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PaintBrushIcon$3e$__["PaintBrushIcon"],
    Bolt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BoltIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BoltIcon$3e$__["BoltIcon"],
    Square3Stack3D: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Square3Stack3DIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Square3Stack3DIcon$3e$__["Square3Stack3DIcon"],
    Tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TagIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TagIcon$3e$__["TagIcon"],
    DocumentText: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$DocumentTextIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DocumentTextIcon$3e$__["DocumentTextIcon"],
    BuildingOffice: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BuildingOfficeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BuildingOfficeIcon$3e$__["BuildingOfficeIcon"]
};
const NavigationItem = ({ item, isActive, onMouseEnter, onMouseLeave, onDropdownMouseEnter, onDropdownMouseLeave, onClick, dynamicCategories, dynamicServiceCategories })=>{
    _s();
    const hasDropdown = item.hasDropdown;
    // Приоритет: данные из API (dropdownItems), затем для "Каталог" — динамические категории, иначе константы
    const apiDropdownItems = item.dropdownItems && item.dropdownItems.length > 0 ? item.dropdownItems : null;
    const menuData = hasDropdown && !apiDropdownItems ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$constants$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dropdownMenus"][item.name] : null;
    // Для "Каталог" используем динамические категории если нет данных из API
    const useDynamicMenu = !apiDropdownItems && item.name === 'Каталог' && dynamicCategories && dynamicCategories.length > 0;
    // Для "Каталог услуг" всегда используем категории из админки каталога услуг (игнорируем dropdownItems из меню навигации)
    const useDynamicServiceMenu = item.name === 'Каталог услуг' && dynamicServiceCategories && dynamicServiceCategories.length > 0;
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const navItemRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const dropdownRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const [alignment, setAlignment] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState('left');
    // Текущая страница: подчёркивание снизу (по URL), не путать с isActive = открыто выпадающее меню
    const isCurrentPage = pathname === item.href || item.href && item.href !== '/' && pathname.startsWith(item.href);
    // Определяем тип выравнивания для выпадающего меню
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "NavigationItem.useEffect": ()=>{
            if (isActive) {
                // Для "Блог" и "Фото" - всегда выравнивание по правому краю
                if (item.name === 'Блог' || item.name === 'Фото') {
                    setAlignment('right');
                } else if (item.name === 'Акции') {
                    if (navItemRef.current && dropdownRef.current) {
                        const updatePosition = {
                            "NavigationItem.useEffect.updatePosition": ()=>{
                                if (!navItemRef.current || !dropdownRef.current) return;
                                const navItemRect = navItemRef.current.getBoundingClientRect();
                                const dropdownWidth = dropdownRef.current.offsetWidth;
                                const viewportWidth = window.innerWidth;
                                const navItemCenter = navItemRect.left + navItemRect.width / 2;
                                const dropdownHalfWidth = dropdownWidth / 2;
                                // Проверяем, не выйдет ли центрированное меню за границы
                                const leftBound = navItemCenter - dropdownHalfWidth;
                                const rightBound = navItemCenter + dropdownHalfWidth;
                                const minMargin = 16; // 1rem = 16px
                                if (leftBound >= minMargin && rightBound <= viewportWidth - minMargin) {
                                    setAlignment('center');
                                } else {
                                    // Если центрирование выходит за границы, используем динамическое определение
                                    const spaceOnRight = viewportWidth - navItemRect.left;
                                    if (spaceOnRight < dropdownWidth) {
                                        setAlignment('right');
                                    } else {
                                        setAlignment('left');
                                    }
                                }
                            }
                        }["NavigationItem.useEffect.updatePosition"];
                        const timeoutId = setTimeout(updatePosition, 0);
                        window.addEventListener('resize', updatePosition);
                        return ({
                            "NavigationItem.useEffect": ()=>{
                                clearTimeout(timeoutId);
                                window.removeEventListener('resize', updatePosition);
                            }
                        })["NavigationItem.useEffect"];
                    } else {
                        setAlignment('center');
                    }
                } else if (navItemRef.current && dropdownRef.current) {
                    const updatePosition = {
                        "NavigationItem.useEffect.updatePosition": ()=>{
                            if (!navItemRef.current || !dropdownRef.current) return;
                            const navItemRect = navItemRef.current.getBoundingClientRect();
                            const dropdownWidth = dropdownRef.current.offsetWidth;
                            const viewportWidth = window.innerWidth;
                            const spaceOnRight = viewportWidth - navItemRect.left;
                            // Если справа недостаточно места, выравниваем по правому краю
                            if (spaceOnRight < dropdownWidth) {
                                const rightAlignedLeft = navItemRect.right - dropdownWidth;
                                const minMargin = 16; // 1rem = 16px
                                if (rightAlignedLeft >= minMargin) {
                                    setAlignment('right');
                                } else {
                                    setAlignment('right');
                                }
                            } else {
                                setAlignment('left');
                            }
                        }
                    }["NavigationItem.useEffect.updatePosition"];
                    // Небольшая задержка для корректного расчета размеров после рендера
                    const timeoutId = setTimeout(updatePosition, 0);
                    window.addEventListener('resize', updatePosition);
                    return ({
                        "NavigationItem.useEffect": ()=>{
                            clearTimeout(timeoutId);
                            window.removeEventListener('resize', updatePosition);
                        }
                    })["NavigationItem.useEffect"];
                } else {
                    setAlignment('left');
                }
            } else {
                setAlignment('left');
            }
        }
    }["NavigationItem.useEffect"], [
        isActive,
        item.name
    ]);
    const handleClick = ()=>{
        // Всегда переходим по ссылке, если она есть
        if (item.href) {
            window.location.href = item.href;
        }
        // Дополнительно вызываем колбэк
        if (onClick) {
            onClick(item.name);
        }
    };
    const handleDropdownItemClick = (itemName)=>{
        // Вызываем колбэк для дополнительной логики (например, закрытие меню)
        if (onClick) {
            onClick(itemName);
        }
    // Переход выполняется стандартным поведением ссылки <a href="...">
    };
    // Функция для получения иконки по имени
    const getIcon = (iconName)=>{
        if (!iconName) {
            return null;
        }
        // Если это путь к изображению
        if (iconName.startsWith('/') || iconName.startsWith('http')) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: iconName,
                alt: "",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemIcon,
                onError: (e)=>{
                    const target = e.target;
                    target.style.display = 'none';
                }
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                lineNumber: 223,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
        // Если это имя иконки из маппинга
        const IconComponent = iconMap[iconName];
        if (IconComponent) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconComponent, {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemIcon
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                lineNumber: 238,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        }
        return null;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: navItemRef,
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navItem,
        onMouseEnter: onMouseEnter,
        onMouseLeave: onMouseLeave,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navButtonWrap,
                children: [
                    isCurrentPage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navButtonCurrentLine,
                        "aria-hidden": true
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                        lineNumber: 252,
                        columnNumber: 27
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        variant: "link",
                        size: "sm",
                        onClick: handleClick,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navButton,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navText,
                            children: item.name
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                            lineNumber: 254,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                        lineNumber: 253,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                lineNumber: 251,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            hasDropdown && isActive && (apiDropdownItems || useDynamicMenu || useDynamicServiceMenu || menuData) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: dropdownRef,
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdown} ${alignment === 'right' ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownRight : alignment === 'center' ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownCenter : ''}`,
                onMouseEnter: onDropdownMouseEnter,
                onMouseLeave: onDropdownMouseLeave,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownContent,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownGrid,
                        children: [
                            apiDropdownItems && !useDynamicServiceMenu && apiDropdownItems.map((dropdownItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownSection,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownSectionInner,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(dropdownItem.href),
                                                onClick: ()=>handleDropdownItemClick(dropdownItem.name),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItem,
                                                children: [
                                                    dropdownItem.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemIconWrapper,
                                                        children: getIcon(dropdownItem.icon)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 287,
                                                        columnNumber: 29
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemText} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemTextBold}`,
                                                        children: dropdownItem.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 291,
                                                        columnNumber: 27
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                lineNumber: 281,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            dropdownItem.submenu && dropdownItem.submenu.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submenu,
                                                children: dropdownItem.submenu.map((subItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(subItem.href),
                                                        onClick: ()=>handleDropdownItemClick(subItem.name),
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submenuItem,
                                                        children: subItem.name
                                                    }, subItem.id, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 300,
                                                        columnNumber: 31
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                lineNumber: 298,
                                                columnNumber: 27
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                        lineNumber: 280,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, dropdownItem.id, false, {
                                    fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                    lineNumber: 279,
                                    columnNumber: 21
                                }, ("TURBOPACK compile-time value", void 0))),
                            useDynamicServiceMenu && dynamicServiceCategories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownSection,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownSectionInner,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(cat.href),
                                            onClick: ()=>handleDropdownItemClick(cat.name),
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItem,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemIconWrapper,
                                                    children: cat.image ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: cat.image,
                                                        alt: "",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryImage
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 327,
                                                        columnNumber: 31
                                                    }, ("TURBOPACK compile-time value", void 0)) : cat.icon ? getIcon(cat.icon) : null
                                                }, void 0, false, {
                                                    fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                    lineNumber: 325,
                                                    columnNumber: 27
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemText} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemTextBold}`,
                                                    children: cat.name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                    lineNumber: 332,
                                                    columnNumber: 27
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                            lineNumber: 320,
                                            columnNumber: 25
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                        lineNumber: 319,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, cat.id, false, {
                                    fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                    lineNumber: 318,
                                    columnNumber: 21
                                }, ("TURBOPACK compile-time value", void 0))),
                            useDynamicMenu && dynamicCategories.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownSection,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownSectionInner,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(category.href),
                                                onClick: ()=>handleDropdownItemClick(category.name),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItem,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemIconWrapper,
                                                        children: category.image ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                            src: category.image,
                                                            alt: "",
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryImage
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                            lineNumber: 354,
                                                            columnNumber: 31
                                                        }, ("TURBOPACK compile-time value", void 0)) : category.icon ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryIcon,
                                                            children: category.icon
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                            lineNumber: 356,
                                                            columnNumber: 31
                                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$RectangleStackIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RectangleStackIcon$3e$__["RectangleStackIcon"], {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemIcon
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                            lineNumber: 358,
                                                            columnNumber: 31
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 352,
                                                        columnNumber: 27
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemText} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemTextBold}`,
                                                        children: category.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 361,
                                                        columnNumber: 27
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                lineNumber: 347,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            category.hasSubmenu && category.submenu.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submenu,
                                                children: category.submenu.map((subItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(subItem.href),
                                                        onClick: ()=>handleDropdownItemClick(subItem.name),
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submenuItem,
                                                        children: [
                                                            subItem.image ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                src: subItem.image,
                                                                alt: "",
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submenuItemImage
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                                lineNumber: 377,
                                                                columnNumber: 35
                                                            }, ("TURBOPACK compile-time value", void 0)) : subItem.icon ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submenuItemIcon,
                                                                children: subItem.icon
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                                lineNumber: 383,
                                                                columnNumber: 35
                                                            }, ("TURBOPACK compile-time value", void 0)) : null,
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: subItem.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                                lineNumber: 385,
                                                                columnNumber: 33
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, subItem.slug, true, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 370,
                                                        columnNumber: 31
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                lineNumber: 368,
                                                columnNumber: 27
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                        lineNumber: 346,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, category.slug, false, {
                                    fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                    lineNumber: 345,
                                    columnNumber: 21
                                }, ("TURBOPACK compile-time value", void 0))),
                            !useDynamicMenu && !useDynamicServiceMenu && menuData && menuData.items.map((dropdownItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownSection,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownSectionInner,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(dropdownItem.href),
                                                onClick: ()=>handleDropdownItemClick(dropdownItem.name),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItem,
                                                children: [
                                                    dropdownItem.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemIconWrapper,
                                                        children: getIcon(dropdownItem.icon)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 407,
                                                        columnNumber: 29
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemText} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItemTextBold}`,
                                                        children: dropdownItem.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 411,
                                                        columnNumber: 27
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                lineNumber: 401,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            dropdownItem.hasSubmenu && dropdownItem.submenu && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submenu,
                                                children: dropdownItem.submenu.map((subItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(subItem.href),
                                                        onClick: ()=>handleDropdownItemClick(subItem.name),
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submenuItem,
                                                        children: subItem.name
                                                    }, subItem.href, false, {
                                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                        lineNumber: 420,
                                                        columnNumber: 31
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                                lineNumber: 418,
                                                columnNumber: 27
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                        lineNumber: 400,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, dropdownItem.href, false, {
                                    fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                                    lineNumber: 399,
                                    columnNumber: 21
                                }, ("TURBOPACK compile-time value", void 0)))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                        lineNumber: 274,
                        columnNumber: 15
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                    lineNumber: 273,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
                lineNumber: 261,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx",
        lineNumber: 245,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(NavigationItem, "o2wz/wbxqTOkhrBMTxlLPK5OacY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = NavigationItem;
var _c;
__turbopack_context__.k.register(_c, "NavigationItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Navigation/NavigationItem/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "container": "DesktopNavigation-module__UOyYpa__container",
  "desktopNavigation": "DesktopNavigation-module__UOyYpa__desktopNavigation",
  "navContainer": "DesktopNavigation-module__UOyYpa__navContainer",
  "separator": "DesktopNavigation-module__UOyYpa__separator",
});
}),
"[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DesktopNavigation",
    ()=>DesktopNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDropdown$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useDropdown.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useDynamicCategories.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicServiceCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useDynamicServiceCategories.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$NavigationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/NavigationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/NavigationItem/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/NavigationItem/NavigationItem.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$DesktopNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const DesktopNavigation = ({ onNavigationClick })=>{
    _s();
    const { activeDropdown, openDropdown, closeDropdown, handleDropdownMouseEnter, handleDropdownMouseLeave } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDropdown$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDropdown"])();
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const navigationItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$NavigationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNavigationItems"])();
    const { navigationCategories } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDynamicCategories"])();
    const { serviceCategories } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicServiceCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDynamicServiceCategories"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$DesktopNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].desktopNavigation,
        ref: dropdownRef,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$DesktopNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$DesktopNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navContainer,
                children: navigationItems.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                        children: [
                            index > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$DesktopNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].separator,
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx",
                                lineNumber: 40,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$NavigationItem$2f$NavigationItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationItem"], {
                                item: item,
                                isActive: activeDropdown === item.name,
                                onMouseEnter: ()=>item.hasDropdown && openDropdown(item.name),
                                onMouseLeave: closeDropdown,
                                onDropdownMouseEnter: handleDropdownMouseEnter,
                                onDropdownMouseLeave: handleDropdownMouseLeave,
                                onClick: onNavigationClick,
                                dynamicCategories: navigationCategories,
                                dynamicServiceCategories: serviceCategories
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx",
                                lineNumber: 41,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, item.name, true, {
                        fileName: "[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx",
                        lineNumber: 39,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx",
                lineNumber: 37,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx",
            lineNumber: 36,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(DesktopNavigation, "Sh/KkSLNUx7uFVZhc/+Z7W0v3WM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDropdown$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDropdown"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$NavigationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNavigationItems"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDynamicCategories"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicServiceCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDynamicServiceCategories"]
    ];
});
_c = DesktopNavigation;
var _c;
__turbopack_context__.k.register(_c, "DesktopNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Navigation/DesktopNavigation/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$DesktopNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "backButton": "MobileNavigation-module__IXNpbG__backButton",
  "backIcon": "MobileNavigation-module__IXNpbG__backIcon",
  "button": "MobileNavigation-module__IXNpbG__button",
  "menuContent": "MobileNavigation-module__IXNpbG__menuContent",
  "menuFooter": "MobileNavigation-module__IXNpbG__menuFooter",
  "menuFooterButtons": "MobileNavigation-module__IXNpbG__menuFooterButtons",
  "menuItemField": "MobileNavigation-module__IXNpbG__menuItemField",
  "menuItemFieldArrow": "MobileNavigation-module__IXNpbG__menuItemFieldArrow",
  "menuItemsList": "MobileNavigation-module__IXNpbG__menuItemsList",
  "mobileMenu": "MobileNavigation-module__IXNpbG__mobileMenu",
  "mobileMenuOpen": "MobileNavigation-module__IXNpbG__mobileMenuOpen",
  "overlay": "MobileNavigation-module__IXNpbG__overlay",
  "subMenu": "MobileNavigation-module__IXNpbG__subMenu",
  "subMenuItem": "MobileNavigation-module__IXNpbG__subMenuItem",
  "subMenuItemIcon": "MobileNavigation-module__IXNpbG__subMenuItemIcon",
  "subMenuItemImage": "MobileNavigation-module__IXNpbG__subMenuItemImage",
  "subMenuSection": "MobileNavigation-module__IXNpbG__subMenuSection",
  "subSubMenu": "MobileNavigation-module__IXNpbG__subSubMenu",
  "subSubMenuItem": "MobileNavigation-module__IXNpbG__subSubMenuItem",
  "subSubMenuItemIcon": "MobileNavigation-module__IXNpbG__subSubMenuItemIcon",
  "subSubMenuItemImage": "MobileNavigation-module__IXNpbG__subSubMenuItemImage",
});
}),
"[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MobileNavigation",
    ()=>MobileNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChevronLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeftIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ChevronLeftIcon.js [app-client] (ecmascript) <export default as ChevronLeftIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/index.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/ActionButtons/ActionButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/context/FormContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$constants$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/constants/navigation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useDynamicCategories.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicServiceCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/useDynamicServiceCategories.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$NavigationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/NavigationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/sanitize.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const MobileNavigation = ({ onNavigationClick, mobileMenuOpen, setMobileMenuOpen })=>{
    _s();
    const [currentMenu, setCurrentMenu] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState('main');
    const [activeMenuItem, setActiveMenuItem] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const navigationItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$NavigationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNavigationItems"])();
    const { navigationCategories } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDynamicCategories"])();
    const { serviceCategories } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicServiceCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDynamicServiceCategories"])();
    const { measurementModal, callbackModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const menuButtons = navigationItems.map((item)=>({
            name: item.name,
            hasDropdown: !!item.hasDropdown,
            href: item.href
        }));
    const handleCloseMenu = ()=>{
        if (setMobileMenuOpen) {
            setMobileMenuOpen(false);
            setTimeout(()=>{
                setCurrentMenu('main');
                setActiveMenuItem(null);
            }, 200);
        }
    };
    const handleMenuItemClick = (itemName, hasDropdown, href)=>{
        if (hasDropdown) {
            setActiveMenuItem(itemName);
            setCurrentMenu('submenu');
            if (onNavigationClick) onNavigationClick(itemName);
        } else if (href) {
            router.push(href);
            handleCloseMenu();
        }
    };
    const handleBackToMainMenu = ()=>{
        setCurrentMenu('main');
        setActiveMenuItem(null);
    };
    const handleSubMenuItemClick = (itemName)=>{
        if (onNavigationClick) onNavigationClick(itemName);
        handleCloseMenu();
    };
    const getActiveSubmenu = ()=>{
        if (!activeMenuItem) return null;
        if (activeMenuItem === 'Каталог' && navigationCategories.length > 0) {
            return {
                category: 'products',
                items: navigationCategories.map((cat)=>({
                        name: cat.name,
                        href: cat.href,
                        productType: cat.slug,
                        icon: cat.icon,
                        image: cat.image,
                        hasSubmenu: cat.hasSubmenu,
                        submenu: cat.submenu.map((sub)=>({
                                name: sub.name,
                                href: sub.href,
                                productType: sub.slug,
                                icon: sub.icon,
                                image: sub.image
                            }))
                    }))
            };
        }
        if (activeMenuItem === 'Каталог услуг') {
            return {
                category: 'services',
                items: serviceCategories.map((cat)=>({
                        name: cat.name,
                        href: cat.href,
                        productType: cat.slug,
                        icon: cat.icon
                    }))
            };
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$constants$2f$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dropdownMenus"][activeMenuItem];
    };
    const activeSubmenu = getActiveSubmenu();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileMenu} ${mobileMenuOpen ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileMenuOpen : ''}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuContent,
                        children: currentMenu === 'main' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuItemsList,
                            children: menuButtons.map((button)=>button.hasDropdown ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>handleMenuItemClick(button.name, button.hasDropdown, button.href),
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuItemField,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: button.name
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                            lineNumber: 143,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuItemFieldArrow,
                                            "aria-hidden": true,
                                            children: "›"
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                            lineNumber: 144,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, button.name, true, {
                                    fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                    lineNumber: 135,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(button.href, '#'),
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuItemField,
                                    onClick: handleCloseMenu,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: button.name
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                        lineNumber: 155,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, button.name, false, {
                                    fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                    lineNumber: 149,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                            lineNumber: 132,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subMenu,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleBackToMainMenu,
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backButton,
                                    type: "button",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChevronLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeftIcon$3e$__["ChevronLeftIcon"], {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backIcon
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                            lineNumber: 163,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        "Назад"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                    lineNumber: 162,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                activeSubmenu && activeSubmenu.items.map((subItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$sanitize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeHref"])(subItem.href),
                                        onClick: ()=>handleSubMenuItemClick(subItem.name),
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subMenuItem,
                                        children: [
                                            subItem.image ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: subItem.image,
                                                alt: "",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subMenuItemImage
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                                lineNumber: 175,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)) : subItem.icon ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subMenuItemIcon,
                                                children: subItem.icon
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                                lineNumber: 177,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)) : null,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: subItem.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                                lineNumber: 179,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, subItem.href, true, {
                                        fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                        lineNumber: 168,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                            lineNumber: 161,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                        lineNumber: 130,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuFooter,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuFooterButtons,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionButton"], {
                                    variant: "measurement",
                                    onClick: measurementModal.open
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                    lineNumber: 188,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$ActionButtons$2f$ActionButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionButton"], {
                                    variant: "callback",
                                    onClick: callbackModal.open
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                                    lineNumber: 189,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                            lineNumber: 187,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                        lineNumber: 186,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                lineNumber: 129,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            mobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].overlay,
                onClick: handleCloseMenu,
                onKeyDown: (e)=>e.key === 'Escape' && handleCloseMenu(),
                role: "button",
                tabIndex: -1,
                "aria-label": "Закрыть меню"
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx",
                lineNumber: 195,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(MobileNavigation, "PZUAC5gsgBF492zeu55+1R861a8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$NavigationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNavigationItems"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDynamicCategories"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$useDynamicServiceCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDynamicServiceCategories"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"]
    ];
});
_c = MobileNavigation;
var _c;
__turbopack_context__.k.register(_c, "MobileNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Navigation/MobileNavigation/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Navigation/Navigation.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "navigation": "Navigation-module__9_xN8G__navigation",
});
}),
"[project]/src/widgets/header/Navigation/Navigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Navigation",
    ()=>Navigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/DesktopNavigation/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$DesktopNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/DesktopNavigation/DesktopNavigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/MobileNavigation/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/MobileNavigation/MobileNavigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$Navigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/Navigation.module.css [app-client] (css module)");
'use client';
;
;
;
;
const Navigation = ({ onNavigationClick, mobileMenuOpen, setMobileMenuOpen })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$Navigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navigation,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$DesktopNavigation$2f$DesktopNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DesktopNavigation"], {
                onNavigationClick: onNavigationClick
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Navigation/Navigation.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$MobileNavigation$2f$MobileNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MobileNavigation"], {
                onNavigationClick: onNavigationClick,
                mobileMenuOpen: mobileMenuOpen,
                setMobileMenuOpen: setMobileMenuOpen
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Navigation/Navigation.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/header/Navigation/Navigation.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Navigation;
var _c;
__turbopack_context__.k.register(_c, "Navigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Navigation/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$Navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/Navigation.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/avatar.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Формирует полный URL аватарки для отображения.
 * Аватар хранится как путь вида /uploads/avatars/avatar-xxx.jpg.
 * Если путь относительный (без ведущего /), он будет скорректирован.
 */ __turbopack_context__.s([
    "getAvatarUrl",
    ()=>getAvatarUrl,
    "getInitials",
    ()=>getInitials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
function getAvatarUrl(avatar) {
    if (!avatar || typeof avatar !== 'string') return null;
    const trimmed = avatar.trim();
    if (!trimmed) return null;
    // Data URLs (base64) возвращаем как есть — без добавления домена
    if (trimmed.startsWith('data:')) return trimmed;
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) return trimmed;
    const apiUrl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const base = apiUrl.replace(/\/api\/v1\/?$/, '').replace(/\/$/, '');
    const path = trimmed.startsWith('/') ? trimmed : `/${trimmed}`;
    return `${base}${path}`;
}
function getInitials(firstName, lastName, email) {
    if (firstName && lastName) return `${firstName[0]}${lastName[0]}`.toUpperCase();
    if (firstName) return firstName.slice(0, 2).toUpperCase();
    if (email) return email.slice(0, 2).toUpperCase();
    return '?';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/TopBar/TopBar.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "badge": "TopBar-module__88jO_G__badge",
  "container": "TopBar-module__88jO_G__container",
  "icon": "TopBar-module__88jO_G__icon",
  "iconCompare": "TopBar-module__88jO_G__iconCompare",
  "iconWrapper": "TopBar-module__88jO_G__iconWrapper",
  "mobileIcon": "TopBar-module__88jO_G__mobileIcon",
  "mobileUtilityButton": "TopBar-module__88jO_G__mobileUtilityButton",
  "profileAvatar": "TopBar-module__88jO_G__profileAvatar",
  "profileInitials": "TopBar-module__88jO_G__profileInitials",
  "profileName": "TopBar-module__88jO_G__profileName",
  "searchForm": "TopBar-module__88jO_G__searchForm",
  "searchIcon": "TopBar-module__88jO_G__searchIcon",
  "searchInput": "TopBar-module__88jO_G__searchInput",
  "searchSubmit": "TopBar-module__88jO_G__searchSubmit",
  "topBar": "TopBar-module__88jO_G__topBar",
  "utilities": "TopBar-module__88jO_G__utilities",
  "utilityButton": "TopBar-module__88jO_G__utilityButton",
  "utilityText": "TopBar-module__88jO_G__utilityText",
  "utilityTextMobile": "TopBar-module__88jO_G__utilityTextMobile",
});
}),
"[project]/src/widgets/header/TopBar/TopBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TopBar",
    ()=>TopBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Cog6ToothIcon.js [app-client] (ecmascript) <export default as Cog6ToothIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$HeartIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HeartIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/HeartIcon.js [app-client] (ecmascript) <export default as HeartIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MoonIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoonIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MoonIcon.js [app-client] (ecmascript) <export default as MoonIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ShoppingCartIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCartIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ShoppingCartIcon.js [app-client] (ecmascript) <export default as ShoppingCartIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$SunIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SunIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/SunIcon.js [app-client] (ecmascript) <export default as SunIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$UserIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/UserIcon.js [app-client] (ecmascript) <export default as UserIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/context/UserAuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/theme/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/theme/lib/useTheme.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$avatar$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/avatar.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$SitePublicConfigContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/SitePublicConfigContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CompareContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/WishlistContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/header/TopBar/TopBar.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const TopBar = ()=>{
    _s();
    const { isDarkTheme, toggleTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [avatarLoadError, setAvatarLoadError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { isAuthenticated, user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserAuth"])();
    const { rolesShowAdminLink } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$SitePublicConfigContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSitePublicConfig"])();
    const isAdmin = !!user?.role && rolesShowAdminLink.length > 0 && rolesShowAdminLink.includes(user.role);
    const { count: wishlistCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"])();
    const { count: compareCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompare"])();
    const { count: cartCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TopBar.useEffect": ()=>{
            setAvatarLoadError(false);
        }
    }["TopBar.useEffect"], [
        user?.avatar
    ]);
    const handleSearchSubmit = (e)=>{
        e.preventDefault();
        const q = searchQuery.trim();
        if (q) {
            router.push(`/catalog/products?search=${encodeURIComponent(q)}`);
        } else {
            router.push('/catalog/products');
        }
    };
    const handleCompareClick = ()=>{
        router.push('/compare');
    };
    const handleProfileClick = ()=>{
        if (isAuthenticated) {
            router.push('/profile');
        } else {
            router.push('/login');
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].topBar,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilities,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchForm,
                        onSubmit: handleSearchSubmit,
                        role: "search",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "search",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchInput,
                                placeholder: "Поиск...",
                                "aria-label": "Поиск",
                                value: searchQuery,
                                onChange: (e)=>setSearchQuery(e.target.value)
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 72,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchSubmit,
                                "aria-label": "Искать",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchIcon
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                    lineNumber: 81,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 80,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                        lineNumber: 71,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleCompareClick,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityButton,
                        type: "button",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconWrapper,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconCompare}`,
                                        "aria-hidden": true,
                                        children: "⚖"
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                        lineNumber: 87,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    compareCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badge,
                                        children: compareCount > 99 ? '99+' : compareCount
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                        lineNumber: 91,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 86,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityText
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 94,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                        lineNumber: 85,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>router.push('/favorites'),
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityButton,
                        type: "button",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconWrapper,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$HeartIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HeartIcon$3e$__["HeartIcon"], {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                        lineNumber: 104,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    wishlistCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badge,
                                        children: wishlistCount > 99 ? '99+' : wishlistCount
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                        lineNumber: 106,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 103,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityText
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 109,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                        lineNumber: 98,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>router.push('/cart'),
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityButton,
                        type: "button",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconWrapper,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ShoppingCartIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCartIcon$3e$__["ShoppingCartIcon"], {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                        lineNumber: 119,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    cartCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badge,
                                        children: cartCount > 99 ? '99+' : cartCount
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                        lineNumber: 121,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 118,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityText
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 124,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                        lineNumber: 113,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    isAdmin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/admin",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityButton,
                        title: "Перейти в админку",
                        "aria-label": "Админка",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__["Cog6ToothIcon"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 135,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityText
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                lineNumber: 136,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                        lineNumber: 129,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleProfileClick,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityButton,
                        type: "button",
                        children: isAuthenticated && user ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                user.avatar && !avatarLoadError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$avatar$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAvatarUrl"])(user.avatar) ?? '',
                                    alt: "",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].profileAvatar,
                                    onError: ()=>setAvatarLoadError(true)
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                    lineNumber: 145,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].profileInitials,
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$avatar$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(user.firstName, user.lastName, user.email)
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                    lineNumber: 152,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].profileName,
                                    children: user.firstName || user.lastName ? [
                                        user.firstName,
                                        user.lastName
                                    ].filter(Boolean).join(' ') : user.email
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                    lineNumber: 156,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$UserIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserIcon$3e$__["UserIcon"], {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                    lineNumber: 164,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityText
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                                    lineNumber: 165,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                        lineNumber: 141,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: toggleTheme,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].utilityButton,
                        type: "button",
                        children: isDarkTheme ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$SunIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SunIcon$3e$__["SunIcon"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                            lineNumber: 173,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MoonIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoonIcon$3e$__["MoonIcon"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
                        }, void 0, false, {
                            fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                            lineNumber: 175,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
                lineNumber: 69,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
            lineNumber: 67,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/header/TopBar/TopBar.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(TopBar, "9LQQP0F1VYGeW0KjU2Nglkosu1k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$SitePublicConfigContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSitePublicConfig"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompare"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"]
    ];
});
_c = TopBar;
var _c;
__turbopack_context__.k.register(_c, "TopBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/TopBar/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/TopBar/TopBar.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Header/Header.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "container": "Header-module__Rjibtq__container",
  "header": "Header-module__Rjibtq__header",
  "logoSection": "Header-module__Rjibtq__logoSection",
  "mainHeader": "Header-module__Rjibtq__mainHeader",
  "mobileHeader": "Header-module__Rjibtq__mobileHeader",
  "mobileHeaderIcon": "Header-module__Rjibtq__mobileHeaderIcon",
  "mobileHeaderIconBurger": "Header-module__Rjibtq__mobileHeaderIconBurger",
  "mobileHeaderIconSvg": "Header-module__Rjibtq__mobileHeaderIconSvg",
  "mobileHeaderRow": "Header-module__Rjibtq__mobileHeaderRow",
  "mobileSearchForm": "Header-module__Rjibtq__mobileSearchForm",
  "mobileSearchIcon": "Header-module__Rjibtq__mobileSearchIcon",
  "mobileSearchInput": "Header-module__Rjibtq__mobileSearchInput",
  "mobileSearchSubmit": "Header-module__Rjibtq__mobileSearchSubmit",
});
}),
"[project]/src/widgets/header/Header/Header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Header",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Bars3Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bars3Icon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Bars3Icon.js [app-client] (ecmascript) <export default as Bars3Icon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChatBubbleLeftRightIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChatBubbleLeftRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ChatBubbleLeftRightIcon.js [app-client] (ecmascript) <export default as ChatBubbleLeftRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MoonIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoonIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MoonIcon.js [app-client] (ecmascript) <export default as MoonIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PhoneIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PhoneIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/PhoneIcon.js [app-client] (ecmascript) <export default as PhoneIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$SunIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SunIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/SunIcon.js [app-client] (ecmascript) <export default as SunIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/theme/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/theme/lib/useTheme.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/ui/Logo/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/Logo/Logo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/context/ChatSupportOpenContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/header/ActionButtons/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/ActionButtons/ActionButtons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$Navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Navigation/Navigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/header/TopBar/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/TopBar/TopBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Header/Header.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const PHONE_LINK = 'tel:+78152601270';
const Header = ({ onNavigationClick })=>{
    _s();
    const [mobileMenuOpen, setMobileMenuOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [mobileSearchQuery, setMobileSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isMounted, setIsMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const chatSupport = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatSupportOpen"])();
    const { isDarkTheme, toggleTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            setIsMounted(true);
        }
    }["Header.useEffect"], []);
    const handleMobileSearchSubmit = (e)=>{
        e.preventDefault();
        const q = mobileSearchQuery.trim();
        if (q) {
            router.push(`/catalog/products?search=${encodeURIComponent(q)}`);
        } else {
            router.push('/catalog/products');
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$TopBar$2f$TopBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TopBar"], {}, void 0, false, {
                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mainHeader,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoSection,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logo"], {}, void 0, false, {
                                    fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                    lineNumber: 61,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$ActionButtons$2f$ActionButtons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionButtons"], {
                                    onMobileMenuOpen: ()=>setMobileMenuOpen(!mobileMenuOpen)
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                    lineNumber: 62,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        isMounted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeader,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderRow,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$Logo$2f$Logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logo"], {}, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                            lineNumber: 69,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: PHONE_LINK,
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIcon,
                                            "aria-label": "Позвонить",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PhoneIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PhoneIcon$3e$__["PhoneIcon"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIconSvg
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                                lineNumber: 71,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                            lineNumber: 70,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIcon,
                                            onClick: ()=>chatSupport?.openChat(),
                                            "aria-label": "Чат поддержки",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChatBubbleLeftRightIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChatBubbleLeftRightIcon$3e$__["ChatBubbleLeftRightIcon"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIconSvg
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                                lineNumber: 79,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                            lineNumber: 73,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIcon,
                                            onClick: toggleTheme,
                                            "aria-label": isDarkTheme ? 'Включить светлую тему' : 'Включить тёмную тему',
                                            children: isDarkTheme ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$SunIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SunIcon$3e$__["SunIcon"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIconSvg
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                                lineNumber: 88,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MoonIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoonIcon$3e$__["MoonIcon"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIconSvg
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                                lineNumber: 90,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                            lineNumber: 81,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIcon} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIconBurger}`,
                                            onClick: ()=>setMobileMenuOpen((prev)=>!prev),
                                            "aria-label": "Открыть меню",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Bars3Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bars3Icon$3e$__["Bars3Icon"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeaderIconSvg
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                                lineNumber: 99,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                            lineNumber: 93,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                    lineNumber: 68,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileSearchForm,
                                    onSubmit: handleMobileSearchSubmit,
                                    role: "search",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "search",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileSearchInput,
                                            placeholder: "Поиск...",
                                            "aria-label": "Поиск",
                                            value: mobileSearchQuery,
                                            onChange: (e)=>setMobileSearchQuery(e.target.value)
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                            lineNumber: 107,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "submit",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileSearchSubmit,
                                            "aria-label": "Искать",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileSearchIcon
                                            }, void 0, false, {
                                                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                                lineNumber: 116,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                            lineNumber: 115,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/widgets/header/Header/Header.tsx",
                                    lineNumber: 102,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/widgets/header/Header/Header.tsx",
                            lineNumber: 67,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/widgets/header/Header/Header.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Navigation$2f$Navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Navigation"], {
                onNavigationClick: onNavigationClick,
                mobileMenuOpen: mobileMenuOpen,
                setMobileMenuOpen: setMobileMenuOpen
            }, void 0, false, {
                fileName: "[project]/src/widgets/header/Header/Header.tsx",
                lineNumber: 124,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/widgets/header/Header/Header.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Header, "pjdMyRK0yCL9aYnKWtznXC5SHj4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChatSupportOpen"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/Header/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Header/Header.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/header/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/header/Header/index.ts [app-client] (ecmascript) <locals>");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "badge": "MobileBottomNav-module__z3TdUa__badge",
  "bottomNav": "MobileBottomNav-module__z3TdUa__bottomNav",
  "icon": "MobileBottomNav-module__z3TdUa__icon",
  "iconWrap": "MobileBottomNav-module__z3TdUa__iconWrap",
  "item": "MobileBottomNav-module__z3TdUa__item",
  "label": "MobileBottomNav-module__z3TdUa__label",
  "link": "MobileBottomNav-module__z3TdUa__link",
  "linkActive": "MobileBottomNav-module__z3TdUa__linkActive",
  "list": "MobileBottomNav-module__z3TdUa__list",
});
}),
"[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MobileBottomNav",
    ()=>MobileBottomNav
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Cog6ToothIcon.js [app-client] (ecmascript) <export default as Cog6ToothIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$HeartIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HeartIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/HeartIcon.js [app-client] (ecmascript) <export default as HeartIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$RectangleGroupIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RectangleGroupIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/RectangleGroupIcon.js [app-client] (ecmascript) <export default as RectangleGroupIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ShoppingCartIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCartIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ShoppingCartIcon.js [app-client] (ecmascript) <export default as ShoppingCartIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Squares2X2Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Squares2X2Icon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Squares2X2Icon.js [app-client] (ecmascript) <export default as Squares2X2Icon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$UserIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/UserIcon.js [app-client] (ecmascript) <export default as UserIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/context/UserAuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$SitePublicConfigContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/SitePublicConfigContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CompareContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/WishlistContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const navItems = [
    {
        href: '/catalog/products',
        label: 'Каталог',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$RectangleGroupIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RectangleGroupIcon$3e$__["RectangleGroupIcon"]
    },
    {
        href: '/compare',
        label: 'Сравнить',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Squares2X2Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Squares2X2Icon$3e$__["Squares2X2Icon"]
    },
    {
        href: '/cart',
        label: 'Корзина',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ShoppingCartIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCartIcon$3e$__["ShoppingCartIcon"]
    },
    {
        href: '/favorites',
        label: 'Избранное',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$HeartIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HeartIcon$3e$__["HeartIcon"]
    },
    {
        href: '/profile',
        label: 'Кабинет',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$UserIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserIcon$3e$__["UserIcon"],
        authHref: '/login'
    }
];
function MobileBottomNav() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { isAuthenticated, user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserAuth"])();
    const { rolesShowAdminLink } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$SitePublicConfigContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSitePublicConfig"])();
    const isAdmin = !!user?.role && rolesShowAdminLink.length > 0 && rolesShowAdminLink.includes(user.role);
    const { count: cartCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"])();
    const { count: compareCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompare"])();
    const { count: wishlistCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"])();
    const getCount = (href)=>{
        if (href === '/compare') return compareCount;
        if (href === '/cart') return cartCount;
        if (href === '/favorites') return wishlistCount;
        return 0;
    };
    const items = [
        ...navItems,
        ...isAdmin ? [
            {
                href: '/admin',
                label: 'Админка',
                Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__["Cog6ToothIcon"]
            }
        ] : []
    ];
    const path = pathname ?? '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].bottomNav,
        "aria-label": "Мобильная навигация",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].list,
            children: items.map(({ href, label, Icon, authHref })=>{
                const linkHref = authHref && !isAuthenticated ? authHref : href;
                const isActive = href === '/catalog/products' ? path.startsWith('/catalog') : path === href || path.startsWith(href + '/');
                const count = getCount(href);
                const showCount = count > 0;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].item,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: linkHref,
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link} ${isActive ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].linkActive : ''}`,
                        "aria-current": isActive ? 'page' : undefined,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconWrap,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx",
                                        lineNumber: 85,
                                        columnNumber: 19
                                    }, this),
                                    showCount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badge,
                                        children: count > 99 ? '99+' : count
                                    }, void 0, false, {
                                        fileName: "[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx",
                                        lineNumber: 86,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx",
                                lineNumber: 84,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                children: label
                            }, void 0, false, {
                                fileName: "[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx",
                                lineNumber: 88,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx",
                        lineNumber: 79,
                        columnNumber: 15
                    }, this)
                }, href, false, {
                    fileName: "[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx",
                    lineNumber: 78,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx",
            lineNumber: 67,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, this);
}
_s(MobileBottomNav, "vcpyjy8xYv8Mti7+BQQtSMrZKts=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$SitePublicConfigContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSitePublicConfig"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CompareContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompare"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"]
    ];
});
_c = MobileBottomNav;
var _c;
__turbopack_context__.k.register(_c, "MobileBottomNav");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SiteLayout",
    ()=>SiteLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/context/UserAuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/forms/index.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$FormModals$2f$FormModals$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/ui/FormModals/FormModals.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/forms/context/FormContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/theme/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/theme/lib/useTheme.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$ApprovedOrderGuardContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$SitePublicConfigContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/SitePublicConfigContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$background$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/background/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$background$2f$Background$2f$Background$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/background/Background/Background.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/context/ChatSupportOpenContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/chat-support/ChatSupportWidget/ChatSupportWidget.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/footer/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/footer/Footer/Footer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/widgets/header/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/header/Header/Header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/site-layout/MobileBottomNav/MobileBottomNav.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const SiteLayout = ({ children })=>{
    _s();
    const { isDarkTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$context$2f$UserAuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserAuthProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$SitePublicConfigContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SitePublicConfigProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$ApprovedOrderGuardContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApprovedOrderGuardProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$context$2f$FormContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FormProvider"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$context$2f$ChatSupportOpenContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChatSupportOpenProvider"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "App",
                            "data-app-theme": isDarkTheme ? 'dark' : 'light',
                            suppressHydrationWarning: true,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$background$2f$Background$2f$Background$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Background"], {}, void 0, false, {
                                    fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                                    lineNumber: 35,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$header$2f$Header$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"], {}, void 0, false, {
                                    fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                                    lineNumber: 36,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mainContent",
                                    children: children
                                }, void 0, false, {
                                    fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                                    lineNumber: 38,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$footer$2f$Footer$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Footer"], {}, void 0, false, {
                                    fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                                    lineNumber: 40,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$site$2d$layout$2f$MobileBottomNav$2f$MobileBottomNav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MobileBottomNav"], {}, void 0, false, {
                                    fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                                    lineNumber: 41,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$chat$2d$support$2f$ChatSupportWidget$2f$ChatSupportWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChatSupportWidget"], {}, void 0, false, {
                                    fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                                    lineNumber: 42,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$forms$2f$ui$2f$FormModals$2f$FormModals$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FormModals"], {}, void 0, false, {
                                    fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                                    lineNumber: 43,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                            lineNumber: 30,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                        lineNumber: 29,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                    lineNumber: 28,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/widgets/site-layout/SiteLayout/SiteLayout.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SiteLayout, "MJyFrrwNU6J4YvIEEzrGGEAbkFk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$theme$2f$lib$2f$useTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = SiteLayout;
var _c;
__turbopack_context__.k.register(_c, "SiteLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_7abf8088._.js.map