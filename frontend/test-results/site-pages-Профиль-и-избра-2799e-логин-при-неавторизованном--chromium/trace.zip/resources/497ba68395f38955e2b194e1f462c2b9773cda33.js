(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7abf8088._.js",
  "static/chunks/node_modules_a0db3915._.js",
  "static/chunks/src_0fc269b7._.css"
],
    source: "dynamic"
});
