(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_4b0c7409._.js",
  "static/chunks/src_app_(site)_profile_page_module_889a3d27.css"
],
    source: "dynamic"
});
