(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6c135411._.js",
  "static/chunks/src_f16dd426._.js",
  "static/chunks/src_app_globals_91e4631d.css"
],
    source: "dynamic"
});
