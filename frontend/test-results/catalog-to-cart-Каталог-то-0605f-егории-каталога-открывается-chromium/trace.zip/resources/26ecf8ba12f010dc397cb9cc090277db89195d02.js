(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_views_catalog_ui_d6b4e515._.js",
  "static/chunks/node_modules_22d4279c._.js",
  "static/chunks/src_views_catalog_ui_54e27438._.css"
],
    source: "dynamic"
});
