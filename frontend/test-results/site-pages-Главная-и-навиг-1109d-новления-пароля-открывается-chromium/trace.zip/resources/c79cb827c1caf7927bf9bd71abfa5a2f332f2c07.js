(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(site)_login_page_module_d36fc762.css",
  "static/chunks/src_app_(site)_05e2790e._.js"
],
    source: "dynamic"
});
