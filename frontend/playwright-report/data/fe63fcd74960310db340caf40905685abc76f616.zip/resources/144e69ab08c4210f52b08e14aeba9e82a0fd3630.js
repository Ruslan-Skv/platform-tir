(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_24b8cce2._.js",
  "static/chunks/node_modules_8dc502cd._.js",
  "static/chunks/src_app_(site)_cart_page_module_598f1e46.css"
],
    source: "dynamic"
});
