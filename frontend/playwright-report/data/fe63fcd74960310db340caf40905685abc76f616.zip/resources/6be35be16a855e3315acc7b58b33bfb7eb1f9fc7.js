(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/shared/api/admin-orders.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteAdminOrder",
    ()=>deleteAdminOrder,
    "getAdminOrder",
    ()=>getAdminOrder,
    "getAdminOrders",
    ()=>getAdminOrders,
    "getDeliveryConfig",
    ()=>getDeliveryConfig,
    "getProductsForReplacement",
    ()=>getProductsForReplacement,
    "getServiceOrder",
    ()=>getServiceOrder,
    "getServiceOrders",
    ()=>getServiceOrders,
    "sendBackOrderToCustomer",
    ()=>sendBackOrderToCustomer,
    "sendOrderToCustomerEmail",
    ()=>sendOrderToCustomerEmail,
    "submitOrderFromCartForCustomer",
    ()=>submitOrderFromCartForCustomer,
    "updateAdminOrderCustomer",
    ()=>updateAdminOrderCustomer,
    "updateAdminOrderDelivery",
    ()=>updateAdminOrderDelivery,
    "updateAdminOrderItem",
    ()=>updateAdminOrderItem,
    "updateAdminOrderStatus",
    ()=>updateAdminOrderStatus,
    "updateDeliveryConfig",
    ()=>updateDeliveryConfig,
    "updateServiceOrderCustomer",
    ()=>updateServiceOrderCustomer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
function getAdminAuthHeaders() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const token = localStorage.getItem('admin_token') || localStorage.getItem('user_token');
    const headers = {
        'Content-Type': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}
async function getAdminOrders(page = 1, limit = 10, status, options) {
    const params = new URLSearchParams({
        page: String(page),
        limit: String(limit)
    });
    if (status) params.set('status', status);
    if (options?.orderNumber) params.set('orderNumber', options.orderNumber);
    if (options?.customer) params.set('customer', options.customer);
    if (options?.manager) params.set('manager', options.manager);
    if (options?.paymentStatus) params.set('paymentStatus', options.paymentStatus);
    if (options?.hasDelivery) params.set('hasDelivery', 'true');
    const res = await fetch(`${API_URL}/admin/orders?${params}`, {
        headers: getAdminAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить заказы');
    return res.json();
}
async function getAdminOrder(id) {
    const res = await fetch(`${API_URL}/admin/orders/${id}`, {
        headers: getAdminAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить заказ');
    return res.json();
}
async function deleteAdminOrder(id) {
    const res = await fetch(`${API_URL}/admin/orders/${id}`, {
        method: 'DELETE',
        headers: getAdminAuthHeaders()
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось удалить заказ');
    }
    return res.json();
}
async function updateAdminOrderStatus(id, status) {
    const res = await fetch(`${API_URL}/admin/orders/${id}/status`, {
        method: 'PATCH',
        headers: getAdminAuthHeaders(),
        body: JSON.stringify({
            status
        })
    });
    if (!res.ok) throw new Error('Не удалось обновить статус');
    return res.json();
}
async function updateAdminOrderItem(orderId, itemId, body) {
    const res = await fetch(`${API_URL}/admin/orders/${orderId}/items/${itemId}`, {
        method: 'PATCH',
        headers: getAdminAuthHeaders(),
        body: JSON.stringify(body)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось обновить пункт заказа');
    }
    return res.json();
}
async function submitOrderFromCartForCustomer(dto) {
    const res = await fetch(`${API_URL}/admin/orders/submit-from-cart-for-customer`, {
        method: 'POST',
        headers: getAdminAuthHeaders(),
        body: JSON.stringify(dto)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось оформить заказ');
    }
    return res.json();
}
async function sendOrderToCustomerEmail(orderId) {
    const res = await fetch(`${API_URL}/admin/orders/${orderId}/send-to-email`, {
        method: 'POST',
        headers: getAdminAuthHeaders()
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось отправить');
    }
    return res.json();
}
async function getServiceOrders(params) {
    const q = new URLSearchParams();
    if (params?.status) q.set('status', params.status);
    if (params?.page) q.set('page', String(params.page));
    if (params?.limit) q.set('limit', String(params.limit));
    const res = await fetch(`${API_URL}/admin/orders/service-orders?${q}`, {
        headers: getAdminAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить заказы на услуги');
    return res.json();
}
async function getServiceOrder(id) {
    const res = await fetch(`${API_URL}/admin/orders/service-order/${id}`, {
        headers: getAdminAuthHeaders()
    });
    if (!res.ok) throw new Error('Заказ на услуги не найден');
    return res.json();
}
async function updateServiceOrderCustomer(id, data) {
    const res = await fetch(`${API_URL}/admin/orders/service-order/${id}/customer`, {
        method: 'PATCH',
        headers: getAdminAuthHeaders(),
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось обновить данные покупателя');
    }
    return res.json();
}
async function updateAdminOrderCustomer(orderId, data) {
    const res = await fetch(`${API_URL}/admin/orders/${orderId}/customer`, {
        method: 'PATCH',
        headers: getAdminAuthHeaders(),
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось обновить покупателя');
    }
    return res.json();
}
async function sendBackOrderToCustomer(orderId, comment) {
    const res = await fetch(`${API_URL}/admin/orders/${orderId}/send-back`, {
        method: 'POST',
        headers: getAdminAuthHeaders(),
        body: JSON.stringify({
            comment: comment || undefined
        })
    });
    if (!res.ok) throw new Error('Не удалось отправить заказ на доработку');
    return res.json();
}
async function updateAdminOrderDelivery(orderId, data) {
    const res = await fetch(`${API_URL}/admin/orders/${orderId}/delivery`, {
        method: 'PATCH',
        headers: getAdminAuthHeaders(),
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({}));
        throw new Error(err.message ?? 'Не удалось обновить стоимость доставки');
    }
    return res.json();
}
async function getProductsForReplacement(search) {
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    params.set('limit', '80');
    const res = await fetch(`${API_URL}/admin/orders/products-for-replacement?${params}`, {
        headers: getAdminAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить список товаров');
    return res.json();
}
async function getDeliveryConfig() {
    const res = await fetch(`${API_URL}/admin/orders/delivery-config`, {
        headers: getAdminAuthHeaders()
    });
    if (!res.ok) throw new Error('Не удалось загрузить настройки доставки');
    return res.json();
}
async function updateDeliveryConfig(data) {
    const res = await fetch(`${API_URL}/admin/orders/delivery-config`, {
        method: 'PATCH',
        headers: getAdminAuthHeaders(),
        body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Не удалось сохранить настройки доставки');
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/(site)/cart/page.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "addToOrderButton": "page-module__TpnsUq__addToOrderButton",
  "approvalCountdown": "page-module__TpnsUq__approvalCountdown",
  "approvalCountdownTime": "page-module__TpnsUq__approvalCountdownTime",
  "cancelReviewLink": "page-module__TpnsUq__cancelReviewLink",
  "cancelReviewWrap": "page-module__TpnsUq__cancelReviewWrap",
  "cartActions": "page-module__TpnsUq__cartActions",
  "cartItem": "page-module__TpnsUq__cartItem",
  "cartItems": "page-module__TpnsUq__cartItems",
  "cartSection": "page-module__TpnsUq__cartSection",
  "cartSectionActions": "page-module__TpnsUq__cartSectionActions",
  "cartSectionDeliveryNote": "page-module__TpnsUq__cartSectionDeliveryNote",
  "cartSectionHint": "page-module__TpnsUq__cartSectionHint",
  "cartSectionItems": "page-module__TpnsUq__cartSectionItems",
  "cartSectionSummary": "page-module__TpnsUq__cartSectionSummary",
  "cartSectionSummaryLabel": "page-module__TpnsUq__cartSectionSummaryLabel",
  "cartSectionSummaryRow": "page-module__TpnsUq__cartSectionSummaryRow",
  "cartSectionSummaryRowTotal": "page-module__TpnsUq__cartSectionSummaryRowTotal",
  "cartSectionSummaryRows": "page-module__TpnsUq__cartSectionSummaryRows",
  "cartSectionTitle": "page-module__TpnsUq__cartSectionTitle",
  "cartSectionTotal": "page-module__TpnsUq__cartSectionTotal",
  "cartSectionTotalLabel": "page-module__TpnsUq__cartSectionTotalLabel",
  "checkoutButton": "page-module__TpnsUq__checkoutButton",
  "checkoutButtonContent": "page-module__TpnsUq__checkoutButtonContent",
  "checkoutHint": "page-module__TpnsUq__checkoutHint",
  "checkoutHintPink": "page-module__TpnsUq__checkoutHintPink",
  "clearButton": "page-module__TpnsUq__clearButton",
  "confirmModalActions": "page-module__TpnsUq__confirmModalActions",
  "confirmModalButtonPrimary": "page-module__TpnsUq__confirmModalButtonPrimary",
  "confirmModalButtonSecondary": "page-module__TpnsUq__confirmModalButtonSecondary",
  "confirmModalContent": "page-module__TpnsUq__confirmModalContent",
  "confirmModalHint": "page-module__TpnsUq__confirmModalHint",
  "confirmModalOverlay": "page-module__TpnsUq__confirmModalOverlay",
  "confirmModalText": "page-module__TpnsUq__confirmModalText",
  "confirmModalTitle": "page-module__TpnsUq__confirmModalTitle",
  "container": "page-module__TpnsUq__container",
  "content": "page-module__TpnsUq__content",
  "continueShopping": "page-module__TpnsUq__continueShopping",
  "continueShoppingWrap": "page-module__TpnsUq__continueShoppingWrap",
  "deliveryBasketButton": "page-module__TpnsUq__deliveryBasketButton",
  "deliveryBasketButtonIcon": "page-module__TpnsUq__deliveryBasketButtonIcon",
  "deliveryCheckbox": "page-module__TpnsUq__deliveryCheckbox",
  "deliveryCheckboxHint": "page-module__TpnsUq__deliveryCheckboxHint",
  "deliveryCheckboxLabel": "page-module__TpnsUq__deliveryCheckboxLabel",
  "deliveryCheckboxWrap": "page-module__TpnsUq__deliveryCheckboxWrap",
  "deliveryCompactCostBreakdown": "page-module__TpnsUq__deliveryCompactCostBreakdown",
  "deliveryCompactCostLine": "page-module__TpnsUq__deliveryCompactCostLine",
  "deliveryCompactCostTotal": "page-module__TpnsUq__deliveryCompactCostTotal",
  "deliveryCompactDate": "page-module__TpnsUq__deliveryCompactDate",
  "deliveryCompactDetails": "page-module__TpnsUq__deliveryCompactDetails",
  "deliveryCompactIcon": "page-module__TpnsUq__deliveryCompactIcon",
  "deliveryCompactIconSvg": "page-module__TpnsUq__deliveryCompactIconSvg",
  "deliveryCompactInfo": "page-module__TpnsUq__deliveryCompactInfo",
  "deliveryCompactRow": "page-module__TpnsUq__deliveryCompactRow",
  "deliveryCompactTitle": "page-module__TpnsUq__deliveryCompactTitle",
  "deliveryCompactWrap": "page-module__TpnsUq__deliveryCompactWrap",
  "deliveryCostError": "page-module__TpnsUq__deliveryCostError",
  "deliveryCostLabel": "page-module__TpnsUq__deliveryCostLabel",
  "deliveryCostLine": "page-module__TpnsUq__deliveryCostLine",
  "deliveryCostLoading": "page-module__TpnsUq__deliveryCostLoading",
  "deliveryCostValue": "page-module__TpnsUq__deliveryCostValue",
  "deliveryEditedBadge": "page-module__TpnsUq__deliveryEditedBadge",
  "deliveryFormBlock": "page-module__TpnsUq__deliveryFormBlock",
  "deliveryFormCheckbox": "page-module__TpnsUq__deliveryFormCheckbox",
  "deliveryFormDateField": "page-module__TpnsUq__deliveryFormDateField",
  "deliveryFormField": "page-module__TpnsUq__deliveryFormField",
  "deliveryFormGrid": "page-module__TpnsUq__deliveryFormGrid",
  "deliveryFormLabel": "page-module__TpnsUq__deliveryFormLabel",
  "deliveryFormLift": "page-module__TpnsUq__deliveryFormLift",
  "deliveryFormMoversNote": "page-module__TpnsUq__deliveryFormMoversNote",
  "deliveryFormOtherCity": "page-module__TpnsUq__deliveryFormOtherCity",
  "deliveryFormPaymentNote": "page-module__TpnsUq__deliveryFormPaymentNote",
  "deliveryFormRadios": "page-module__TpnsUq__deliveryFormRadios",
  "deliveryFormTitle": "page-module__TpnsUq__deliveryFormTitle",
  "deliveryFormTitleRow": "page-module__TpnsUq__deliveryFormTitleRow",
  "deliveryFormTotal": "page-module__TpnsUq__deliveryFormTotal",
  "deliveryOption": "page-module__TpnsUq__deliveryOption",
  "deliveryOptions": "page-module__TpnsUq__deliveryOptions",
  "deliveryPayOnSiteBadge": "page-module__TpnsUq__deliveryPayOnSiteBadge",
  "deliveryPrice": "page-module__TpnsUq__deliveryPrice",
  "deliveryRadioLabel": "page-module__TpnsUq__deliveryRadioLabel",
  "deliverySection": "page-module__TpnsUq__deliverySection",
  "deliveryTitle": "page-module__TpnsUq__deliveryTitle",
  "doubleCheckIcon": "page-module__TpnsUq__doubleCheckIcon",
  "empty": "page-module__TpnsUq__empty",
  "error": "page-module__TpnsUq__error",
  "header": "page-module__TpnsUq__header",
  "image": "page-module__TpnsUq__image",
  "itemActionsColumn": "page-module__TpnsUq__itemActionsColumn",
  "itemCategory": "page-module__TpnsUq__itemCategory",
  "itemEditedBadge": "page-module__TpnsUq__itemEditedBadge",
  "itemEditedByAdmin": "page-module__TpnsUq__itemEditedByAdmin",
  "itemEditedNote": "page-module__TpnsUq__itemEditedNote",
  "itemEditedText": "page-module__TpnsUq__itemEditedText",
  "itemImage": "page-module__TpnsUq__itemImage",
  "itemInOrderBadge": "page-module__TpnsUq__itemInOrderBadge",
  "itemInfo": "page-module__TpnsUq__itemInfo",
  "itemManagerComment": "page-module__TpnsUq__itemManagerComment",
  "itemManagerCommentClose": "page-module__TpnsUq__itemManagerCommentClose",
  "itemManagerCommentCloseIcon": "page-module__TpnsUq__itemManagerCommentCloseIcon",
  "itemManagerCommentLabel": "page-module__TpnsUq__itemManagerCommentLabel",
  "itemManagerCommentText": "page-module__TpnsUq__itemManagerCommentText",
  "itemName": "page-module__TpnsUq__itemName",
  "itemOption": "page-module__TpnsUq__itemOption",
  "itemOptions": "page-module__TpnsUq__itemOptions",
  "itemOptionsRow": "page-module__TpnsUq__itemOptionsRow",
  "itemPrice": "page-module__TpnsUq__itemPrice",
  "itemQuantity": "page-module__TpnsUq__itemQuantity",
  "itemQuantityAndTotal": "page-module__TpnsUq__itemQuantityAndTotal",
  "link": "page-module__TpnsUq__link",
  "loading": "page-module__TpnsUq__loading",
  "outOfStockBadge": "page-module__TpnsUq__outOfStockBadge",
  "quantityButton": "page-module__TpnsUq__quantityButton",
  "quantityValue": "page-module__TpnsUq__quantityValue",
  "removeButton": "page-module__TpnsUq__removeButton",
  "removeButtonIcon": "page-module__TpnsUq__removeButtonIcon",
  "required": "page-module__TpnsUq__required",
  "returnedForCorrectionBanner": "page-module__TpnsUq__returnedForCorrectionBanner",
  "returnedForCorrectionComment": "page-module__TpnsUq__returnedForCorrectionComment",
  "returnedForCorrectionCommentLabel": "page-module__TpnsUq__returnedForCorrectionCommentLabel",
  "returnedForCorrectionCommentText": "page-module__TpnsUq__returnedForCorrectionCommentText",
  "returnedForCorrectionHint": "page-module__TpnsUq__returnedForCorrectionHint",
  "returnedForCorrectionTitle": "page-module__TpnsUq__returnedForCorrectionTitle",
  "reviewProgressCheck": "page-module__TpnsUq__reviewProgressCheck",
  "reviewProgressIcon": "page-module__TpnsUq__reviewProgressIcon",
  "reviewProgressIconSmall": "page-module__TpnsUq__reviewProgressIconSmall",
  "reviewProgressSpin": "page-module__TpnsUq__reviewProgressSpin",
  "reviewProgressSpinnerArc": "page-module__TpnsUq__reviewProgressSpinnerArc",
  "sendToEmailError": "page-module__TpnsUq__sendToEmailError",
  "sendToEmailField": "page-module__TpnsUq__sendToEmailField",
  "sendToEmailForm": "page-module__TpnsUq__sendToEmailForm",
  "sendToEmailInput": "page-module__TpnsUq__sendToEmailInput",
  "sendToEmailLabel": "page-module__TpnsUq__sendToEmailLabel",
  "sendToEmailLink": "page-module__TpnsUq__sendToEmailLink",
  "sendToEmailRow": "page-module__TpnsUq__sendToEmailRow",
  "serviceItemIcon": "page-module__TpnsUq__serviceItemIcon",
  "serviceItemLine": "page-module__TpnsUq__serviceItemLine",
  "serviceItemLines": "page-module__TpnsUq__serviceItemLines",
  "serviceItemLink": "page-module__TpnsUq__serviceItemLink",
  "serviceItemTotal": "page-module__TpnsUq__serviceItemTotal",
  "serviceItemsNote": "page-module__TpnsUq__serviceItemsNote",
  "serviceRoomList": "page-module__TpnsUq__serviceRoomList",
  "serviceRoomTitle": "page-module__TpnsUq__serviceRoomTitle",
  "subtitle": "page-module__TpnsUq__subtitle",
  "summary": "page-module__TpnsUq__summary",
  "summaryContent": "page-module__TpnsUq__summaryContent",
  "summaryDeliveryNotIncluded": "page-module__TpnsUq__summaryDeliveryNotIncluded",
  "summaryEditedBadge": "page-module__TpnsUq__summaryEditedBadge",
  "summaryPayOnSiteNote": "page-module__TpnsUq__summaryPayOnSiteNote",
  "summaryRow": "page-module__TpnsUq__summaryRow",
  "summaryTitle": "page-module__TpnsUq__summaryTitle",
  "title": "page-module__TpnsUq__title",
  "totalPrice": "page-module__TpnsUq__totalPrice",
});
}),
"[project]/src/app/(site)/cart/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CartPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/TrashIcon.js [app-client] (ecmascript) <export default as TrashIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TruckIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TruckIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/TruckIcon.js [app-client] (ecmascript) <export default as TruckIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js [app-client] (ecmascript) <export default as XMarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$admin$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/admin-orders.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/api/user-orders.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$ApprovedOrderGuardContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/ApprovedOrderGuardContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$hooks$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/shared/lib/hooks/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/contexts/CartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/app/(site)/cart/page.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
const RESTORED_SERVICE_ORDERS_KEY = 'restored_service_order_ids';
const getRestoredServiceOrderIds = ()=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = window.sessionStorage.getItem(RESTORED_SERVICE_ORDERS_KEY);
        const parsed = raw ? JSON.parse(raw) : [];
        return new Set(parsed);
    } catch  {
        return new Set();
    }
};
const markServiceOrderRestored = (orderId)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const current = getRestoredServiceOrderIds();
    current.add(orderId);
    window.sessionStorage.setItem(RESTORED_SERVICE_ORDERS_KEY, JSON.stringify(Array.from(current)));
};
function CartPage() {
    _s();
    const { cart, cartServiceItems, count, addServiceToCart, refreshCart, updateQuantity, updateCartItemQuantityById, updateComponentQuantity, removeFromCart, removeCartItemById, removeComponentFromCart, removeCartServiceItemById, getTotalPrice } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [updatingItems, setUpdatingItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [userOrders, setUserOrders] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [submitInProgress, setSubmitInProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [cancelInProgress, setCancelInProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [addToOrderInProgress, setAddToOrderInProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [, setTick] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const guard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$ApprovedOrderGuardContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApprovedOrderGuard"])();
    const [wantDelivery, setWantDelivery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deliveryForm, setDeliveryForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        street: '',
        city: '',
        distanceKm: '',
        deliveryType: 'TO_ENTRANCE',
        deliveryFloor: '',
        deliveryHasElevator: false,
        preferredDeliveryTime: ''
    });
    const [calculatedDelivery, setCalculatedDelivery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deliveryCalculationLoading, setDeliveryCalculationLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deliveryCalculationError, setDeliveryCalculationError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deliverySettlements, setDeliverySettlements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [deliveryPaymentMode, setDeliveryPaymentMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('WITH_ORDER');
    /** Id позиций корзины, для которых пользователь закрыл блок «Рекомендации менеджера». */ const [dismissedManagerCommentIds, setDismissedManagerCommentIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    /** Показать модалку подтверждения добавления новых товаров к проверенному заказу. */ const [showAddToApprovedModal, setShowAddToApprovedModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    /** Показать модалку объединения с заказом на проверке. */ const [showAddToPendingReviewModal, setShowAddToPendingReviewModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    /** Показать модалку «Отправить заказ на email клиенту» (для менеджеров). */ const [showSendToEmailModal, setShowSendToEmailModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [canSendToEmail, setCanSendToEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [sendToEmailCustomer, setSendToEmailCustomer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        customerEmail: '',
        customerFirstName: '',
        customerMiddleName: '',
        customerLastName: '',
        customerPhone: ''
    });
    const [sendToEmailInProgress, setSendToEmailInProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [sendToEmailMessage, setSendToEmailMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const restoringServiceOrdersRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            const id = setInterval({
                "CartPage.useEffect.id": ()=>setTick({
                        "CartPage.useEffect.id": (t)=>t + 1
                    }["CartPage.useEffect.id"])
            }["CartPage.useEffect.id"], 1000);
            return ({
                "CartPage.useEffect": ()=>clearInterval(id)
            })["CartPage.useEffect"];
        }
    }["CartPage.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canResendOrderToEmail"])().then(setCanSendToEmail).catch({
                "CartPage.useEffect": ()=>setCanSendToEmail(false)
            }["CartPage.useEffect"]);
        }
    }["CartPage.useEffect"], []);
    const openSendToEmailModal = ()=>{
        if (!approvedOrder) return;
        const email = approvedOrder.createdByManagerId && approvedOrder.customerEmail ? approvedOrder.customerEmail : approvedOrder.user?.email ?? approvedOrder.customerEmail ?? '';
        setSendToEmailCustomer({
            customerEmail: email,
            customerFirstName: approvedOrder.customerFirstName ?? approvedOrder.user?.firstName ?? '',
            customerMiddleName: approvedOrder.customerMiddleName ?? '',
            customerLastName: approvedOrder.customerLastName ?? approvedOrder.user?.lastName ?? '',
            customerPhone: approvedOrder.customerPhone ?? ''
        });
        setSendToEmailMessage(null);
        setShowSendToEmailModal(true);
    };
    const handleSendToEmailSubmit = async ()=>{
        if (!approvedOrder) return;
        const email = sendToEmailCustomer.customerEmail.trim();
        if (!email) {
            setSendToEmailMessage('Введите email покупателя');
            return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            setSendToEmailMessage('Некорректный email');
            return;
        }
        setSendToEmailInProgress(true);
        setSendToEmailMessage(null);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$admin$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateAdminOrderCustomer"])(approvedOrder.id, {
                customerEmail: email,
                customerFirstName: sendToEmailCustomer.customerFirstName.trim() || null,
                customerMiddleName: sendToEmailCustomer.customerMiddleName.trim() || null,
                customerLastName: sendToEmailCustomer.customerLastName.trim() || null,
                customerPhone: sendToEmailCustomer.customerPhone.trim() || null
            });
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$admin$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sendOrderToCustomerEmail"])(approvedOrder.id);
            if (result.sent) {
                setShowSendToEmailModal(false);
                const orders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserOrders"])();
                setUserOrders(orders);
            } else {
                setSendToEmailMessage(result.error ?? 'Не удалось отправить');
            }
        } catch (err) {
            setSendToEmailMessage(err instanceof Error ? err.message : 'Не удалось отправить');
        } finally{
            setSendToEmailInProgress(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDeliverySettlements"])().then({
                "CartPage.useEffect": (data)=>{
                    setDeliverySettlements(data.settlements ?? []);
                    setDeliveryPaymentMode(data.deliveryPaymentMode ?? 'WITH_ORDER');
                }
            }["CartPage.useEffect"]).catch({
                "CartPage.useEffect": ()=>setDeliverySettlements([])
            }["CartPage.useEffect"]);
        }
    }["CartPage.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            const loadCart = {
                "CartPage.useEffect.loadCart": async ()=>{
                    try {
                        setLoading(true);
                        setError(null);
                        await refreshCart();
                    } catch (err) {
                        if (err instanceof Error) {
                            if (err.message === 'Необходима авторизация') {
                                setError('Войдите в систему, чтобы просмотреть корзину');
                            } else {
                                setError(err.message);
                            }
                        } else {
                            setError('Произошла ошибка при загрузке корзины');
                        }
                    } finally{
                        setLoading(false);
                    }
                }
            }["CartPage.useEffect.loadCart"];
            loadCart();
        }
    }["CartPage.useEffect"], [
        refreshCart
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            if (cart.length === 0) return;
            const loadOrders = {
                "CartPage.useEffect.loadOrders": async ()=>{
                    try {
                        const orders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserOrders"])();
                        setUserOrders(orders);
                    } catch  {
                        setUserOrders([]);
                    }
                }
            }["CartPage.useEffect.loadOrders"];
            loadOrders();
        }
    }["CartPage.useEffect"], [
        cart.length
    ]);
    // Восстанавливаем услуги в корзину после отмены заказа админом/менеджером.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            if (!userOrders?.length) return;
            const cancelledOrders = userOrders.filter({
                "CartPage.useEffect.cancelledOrders": (order)=>order.status === 'CANCELLED' && (order.orderServiceItems?.length ?? 0) > 0
            }["CartPage.useEffect.cancelledOrders"]);
            if (cancelledOrders.length === 0) return;
            const restoredIds = getRestoredServiceOrderIds();
            const restoreOrderServices = {
                "CartPage.useEffect.restoreOrderServices": async (order)=>{
                    if (restoredIds.has(order.id) || restoringServiceOrdersRef.current.has(order.id)) return;
                    restoringServiceOrdersRef.current.add(order.id);
                    try {
                        const byCategory = new Map();
                        for (const item of order.orderServiceItems ?? []){
                            const slug = item.serviceCatalogItem?.category?.slug;
                            if (!slug) continue;
                            const categoryName = item.categoryName || 'Услуги';
                            const roomName = item.roomName || 'Помещение';
                            const category = byCategory.get(slug) ?? {
                                categoryName,
                                rooms: new Map()
                            };
                            const room = category.rooms.get(roomName) ?? new Map();
                            const currentQty = room.get(item.serviceCatalogItemId) ?? 0;
                            room.set(item.serviceCatalogItemId, currentQty + item.quantity);
                            category.rooms.set(roomName, room);
                            byCategory.set(slug, category);
                        }
                        if (byCategory.size === 0) return;
                        for (const [slug, category] of byCategory.entries()){
                            const alreadyInCart = cartServiceItems.some({
                                "CartPage.useEffect.restoreOrderServices.alreadyInCart": (cartItem)=>cartItem.category?.slug === slug || cartItem.category?.name === category.categoryName
                            }["CartPage.useEffect.restoreOrderServices.alreadyInCart"]);
                            if (alreadyInCart) continue;
                            const res = await fetch(`${API_URL}/service-catalog/categories/${encodeURIComponent(slug)}`);
                            if (!res.ok) continue;
                            const data = await res.json();
                            const rooms = Array.from(category.rooms.entries()).map({
                                "CartPage.useEffect.restoreOrderServices.rooms": ([name, itemsMap])=>({
                                        name,
                                        items: Array.from(itemsMap.entries()).map({
                                            "CartPage.useEffect.restoreOrderServices.rooms": ([itemId, quantity])=>({
                                                    itemId,
                                                    quantity
                                                })
                                        }["CartPage.useEffect.restoreOrderServices.rooms"])
                                    })
                            }["CartPage.useEffect.restoreOrderServices.rooms"]);
                            await addServiceToCart(data.id, {
                                rooms
                            });
                        }
                        markServiceOrderRestored(order.id);
                    } finally{
                        restoringServiceOrdersRef.current.delete(order.id);
                    }
                }
            }["CartPage.useEffect.restoreOrderServices"];
            cancelledOrders.forEach({
                "CartPage.useEffect": (order)=>{
                    void restoreOrderServices(order);
                }
            }["CartPage.useEffect"]);
        }
    }["CartPage.useEffect"], [
        userOrders,
        cartServiceItems,
        addServiceToCart
    ]);
    const sortedOrders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CartPage.useMemo[sortedOrders]": ()=>{
            if (!userOrders?.length) return [];
            return [
                ...userOrders
            ].sort({
                "CartPage.useMemo[sortedOrders]": (a, b)=>new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            }["CartPage.useMemo[sortedOrders]"]);
        }
    }["CartPage.useMemo[sortedOrders]"], [
        userOrders
    ]);
    const pendingReviewOrder = sortedOrders.find((o)=>o.status === 'PENDING_REVIEW') ?? null;
    const approvedOrder = sortedOrders.find((o)=>o.status === 'APPROVED') ?? null;
    /** Заказ, отправленный менеджером на доработку — один активный заказ на пользователя. */ const returnedForCorrectionOrder = sortedOrders.find((o)=>o.status === 'RETURNED_FOR_CORRECTION') ?? null;
    const approvalRemainingMs = approvedOrder ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApprovalRemainingMs"])(approvedOrder.approvedAt ?? null, approvedOrder.approvalValidMinutes) : 0;
    const approvalExpired = approvedOrder && approvalRemainingMs <= 0;
    /** Есть ли у заказа на проверке доставка (адрес или тип) — показываем блок доставки заполненным и с бейджем. */ const pendingOrderHasDelivery = !!pendingReviewOrder && (!!pendingReviewOrder.shippingAddress || !!pendingReviewOrder.deliveryType);
    /** Есть ли у проверенного заказа доставка — блок доставки остаётся заполненным и с бейджем «Проверено». */ const approvedOrderHasDelivery = !!approvedOrder && !approvalExpired && (!!approvedOrder.shippingAddress || !!approvedOrder.deliveryType);
    /** Заказ, из которого подставляем доставку (на проверке → проверенный → на доработке). */ const returnedOrderHasDelivery = !!returnedForCorrectionOrder && (!!returnedForCorrectionOrder.shippingAddress || !!returnedForCorrectionOrder.deliveryType);
    const orderWithDelivery = pendingReviewOrder?.id && pendingOrderHasDelivery ? pendingReviewOrder : approvedOrderHasDelivery ? approvedOrder : returnedOrderHasDelivery ? returnedForCorrectionOrder : null;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            if (approvalExpired && userOrders) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserOrders"])().then(setUserOrders);
            }
        }
    }["CartPage.useEffect"], [
        approvalExpired
    ]);
    /** Синхронизация формы доставки из заказа (на проверке или проверенного): не обнулять, показывать заполненным. */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            if (!orderWithDelivery) return;
            setWantDelivery(true);
            const addr = orderWithDelivery.shippingAddress;
            setDeliveryForm({
                "CartPage.useEffect": (f)=>({
                        ...f,
                        street: addr?.street ?? '',
                        city: addr?.city ?? '',
                        deliveryType: orderWithDelivery.deliveryType === 'TO_APARTMENT' ? 'TO_APARTMENT' : 'TO_ENTRANCE',
                        deliveryFloor: orderWithDelivery.deliveryFloor != null ? String(orderWithDelivery.deliveryFloor) : '',
                        deliveryHasElevator: orderWithDelivery.deliveryHasElevator ?? false,
                        preferredDeliveryTime: orderWithDelivery.preferredDeliveryTime ?? ''
                    })
            }["CartPage.useEffect"]);
        // Не подставляем данные заказа в calculatedDelivery — расчёт и блок «Итого» всегда берут актуальную стоимость из API (текущий конфиг доставки).
        }
    }["CartPage.useEffect"], [
        orderWithDelivery?.id,
        !!orderWithDelivery
    ]);
    /** ID позиций корзины, которые в заказе на проверке или на доработке (секция 2).
   * Сопоставляем по order → cart: для каждого order item выбираем один подходящий cart item
   * с минимальным id, чтобы при дубликатах (одинаковый товар добавлен дважды) в секции 2
   * попадали именно первые экземпляры, а дополнительные — в секцию 1. */ const cartItemIdsInReviewOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CartPage.useMemo[cartItemIdsInReviewOrder]": ()=>{
            const order = pendingReviewOrder ?? returnedForCorrectionOrder ?? null;
            if (!order?.items?.length || !cart.length) return new Set();
            const ids = new Set();
            const usedCartIds = new Set();
            for (const o of order.items){
                const oProductId = o.productId;
                const oQty = o.quantity;
                const oSize = o.size ?? null;
                const oOpening = o.openingSide ?? null;
                const matching = cart.filter({
                    "CartPage.useMemo[cartItemIdsInReviewOrder].matching": (c)=>{
                        if (usedCartIds.has(c.id)) return false;
                        const cProductId = c.product?.id ?? c.component?.product?.id;
                        if (!cProductId || cProductId !== oProductId) return false;
                        const cQty = Math.round(Number(c.quantity));
                        const cSize = c.size ?? null;
                        const cOpening = c.openingSide ?? null;
                        return cQty === oQty && cSize === oSize && cOpening === oOpening;
                    }
                }["CartPage.useMemo[cartItemIdsInReviewOrder].matching"]);
                if (matching.length === 0) continue;
                matching.sort({
                    "CartPage.useMemo[cartItemIdsInReviewOrder]": (a, b)=>a.id < b.id ? -1 : 1
                }["CartPage.useMemo[cartItemIdsInReviewOrder]"]);
                const chosen = matching[0];
                usedCartIds.add(chosen.id);
                ids.add(chosen.id);
            }
            return ids;
        }
    }["CartPage.useMemo[cartItemIdsInReviewOrder]"], [
        pendingReviewOrder,
        returnedForCorrectionOrder,
        cart
    ]);
    /** Алиас для совместимости. */ const cartItemIdsInOrder = cartItemIdsInReviewOrder;
    /** ID позиций корзины, которые в заказе со статусом «Проверен» (секция 3).
   * Сопоставление order → cart с выбором cart item с минимальным id при дубликатах. */ const cartItemIdsInApprovedOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CartPage.useMemo[cartItemIdsInApprovedOrder]": ()=>{
            if (!approvedOrder?.items?.length || !cart.length) return new Set();
            const ids = new Set();
            const usedCartIds = new Set();
            for (const o of approvedOrder.items){
                const oProductId = o.productId;
                const oQty = o.quantity;
                const oSize = o.size ?? null;
                const oOpening = o.openingSide ?? null;
                const matching = cart.filter({
                    "CartPage.useMemo[cartItemIdsInApprovedOrder].matching": (c)=>{
                        if (usedCartIds.has(c.id)) return false;
                        const cProductId = c.product?.id ?? c.component?.product?.id;
                        if (!cProductId || cProductId !== oProductId) return false;
                        const cQty = Math.round(Number(c.quantity));
                        const cSize = c.size ?? null;
                        const cOpening = c.openingSide ?? null;
                        return cQty === oQty && cSize === oSize && cOpening === oOpening;
                    }
                }["CartPage.useMemo[cartItemIdsInApprovedOrder].matching"]);
                if (matching.length === 0) continue;
                matching.sort({
                    "CartPage.useMemo[cartItemIdsInApprovedOrder]": (a, b)=>a.id < b.id ? -1 : 1
                }["CartPage.useMemo[cartItemIdsInApprovedOrder]"]);
                const chosen = matching[0];
                usedCartIds.add(chosen.id);
                ids.add(chosen.id);
            }
            return ids;
        }
    }["CartPage.useMemo[cartItemIdsInApprovedOrder]"], [
        approvedOrder,
        cart
    ]);
    /** ID позиций для секции 1: ещё не отправлены на проверку. */ const section1ItemIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CartPage.useMemo[section1ItemIds]": ()=>new Set(cart.filter({
                "CartPage.useMemo[section1ItemIds]": (item)=>!cartItemIdsInReviewOrder.has(item.id) && !cartItemIdsInApprovedOrder.has(item.id)
            }["CartPage.useMemo[section1ItemIds]"]).map({
                "CartPage.useMemo[section1ItemIds]": (item)=>item.id
            }["CartPage.useMemo[section1ItemIds]"]))
    }["CartPage.useMemo[section1ItemIds]"], [
        cart,
        cartItemIdsInReviewOrder,
        cartItemIdsInApprovedOrder
    ]);
    /** ID позиций для секции 2: в заказе на проверке или на доработке. */ const section2ItemIds = cartItemIdsInReviewOrder;
    /** ID позиций для секции 3: в проверенном заказе. */ const section3ItemIds = cartItemIdsInApprovedOrder;
    const getDetachedCategoriesForOrder = (orderId)=>{
        if (!orderId || ("TURBOPACK compile-time value", "object") === 'undefined') return new Set();
        try {
            const raw = window.sessionStorage.getItem('detached_service_categories');
            const entries = raw ? JSON.parse(raw) : [];
            const filtered = entries.filter((e)=>e.orderId === orderId);
            const keys = new Set();
            for (const entry of filtered){
                if (entry.categorySlug) keys.add(entry.categorySlug);
                if (entry.categoryName) keys.add(entry.categoryName);
            }
            return keys;
        } catch  {
            return new Set();
        }
    };
    const groupOrderServiceItems = (items, orderId)=>{
        if (!items?.length) return [];
        const detachedCategories = getDetachedCategoriesForOrder(orderId);
        const byCategory = new Map();
        for (const o of items){
            const cat = o.categoryName || 'Услуги';
            const slug = o.serviceCatalogItem?.category?.slug ?? '';
            if (detachedCategories.has(slug) || detachedCategories.has(cat)) continue;
            const roomName = o.roomName || 'Помещение';
            const amount = typeof o.amount === 'string' ? parseFloat(o.amount) : Number(o.amount);
            const line = {
                itemId: o.serviceCatalogItemId,
                name: o.name,
                quantity: o.quantity,
                unit: o.unit,
                amount
            };
            const entry = byCategory.get(cat);
            if (entry) {
                const room = entry.rooms.get(roomName);
                if (room) {
                    room.push(line);
                } else {
                    entry.rooms.set(roomName, [
                        line
                    ]);
                }
                if (slug && !entry.slug) entry.slug = slug;
            } else {
                const rooms = new Map();
                rooms.set(roomName, [
                    line
                ]);
                byCategory.set(cat, {
                    slug,
                    rooms
                });
            }
        }
        return Array.from(byCategory.entries()).map(([categoryName, { slug, rooms }])=>{
            const roomsList = Array.from(rooms.entries()).map(([roomName, list])=>{
                const total = list.reduce((s, i)=>s + i.amount, 0);
                return {
                    roomName,
                    items: list,
                    total
                };
            });
            const total = roomsList.reduce((s, r)=>s + r.total, 0);
            return {
                categoryName,
                categorySlug: slug,
                rooms: roomsList,
                total
            };
        });
    };
    /** Строка preset для URL: itemId1:qty1,itemId2:qty2 (значение целиком кодируется при подстановке в query) */ const buildPresetQuery = (items)=>items.map((i)=>`${i.itemId}:${i.quantity}`).join(',');
    const encodeBase64 = (value)=>{
        const utf8 = encodeURIComponent(value);
        return btoa(utf8);
    };
    const buildRoomsParam = (rooms)=>encodeBase64(JSON.stringify(rooms));
    /** Секции корзины для отображения (1: не отправлены, 2: на проверке, 3: проверено). */ const cartSections = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CartPage.useMemo[cartSections]": ()=>{
            const sumItems = {
                "CartPage.useMemo[cartSections].sumItems": (products, components)=>{
                    let total = 0;
                    for (const p of products){
                        const q = Math.max(1, Math.round(Number(p.quantity)));
                        total += (p.product?.price ?? 0) * q;
                    }
                    for (const c of components){
                        const q = Math.max(0.5, Number(c.quantity));
                        total += (c.component?.price ?? 0) * q;
                    }
                    return total;
                }
            }["CartPage.useMemo[cartSections].sumItems"];
            const countItems = {
                "CartPage.useMemo[cartSections].countItems": (products, components)=>{
                    let n = 0;
                    for (const p of products)n += Math.max(1, Math.round(Number(p.quantity)));
                    for (const c of components)n += Math.max(0.5, Number(c.quantity));
                    return n;
                }
            }["CartPage.useMemo[cartSections].countItems"];
            const s1Products = [];
            const s1Components = [];
            const s2Products = [];
            const s2Components = [];
            const s3Products = [];
            const s3Components = [];
            for (const item of cart){
                if (item.product != null && item.componentId === null) {
                    const p = item;
                    if (section1ItemIds.has(item.id)) s1Products.push(p);
                    else if (section2ItemIds.has(item.id)) s2Products.push(p);
                    else if (section3ItemIds.has(item.id)) s3Products.push(p);
                } else if (item.component != null && item.productId === null) {
                    const c = item;
                    if (section1ItemIds.has(item.id)) s1Components.push(c);
                    else if (section2ItemIds.has(item.id)) s2Components.push(c);
                    else if (section3ItemIds.has(item.id)) s3Components.push(c);
                }
            }
            const reviewOrder = pendingReviewOrder ?? returnedForCorrectionOrder ?? null;
            const s2ServiceGroups = groupOrderServiceItems(reviewOrder?.orderServiceItems, reviewOrder?.id);
            const s3ServiceGroups = groupOrderServiceItems(approvedOrder?.orderServiceItems, approvedOrder?.id);
            const s1ServiceTotal = cartServiceItems.reduce({
                "CartPage.useMemo[cartSections].s1ServiceTotal": (s, i)=>s + (i.total != null && i.total > 0 ? i.total : 0)
            }["CartPage.useMemo[cartSections].s1ServiceTotal"], 0);
            const s2ServiceTotal = s2ServiceGroups.reduce({
                "CartPage.useMemo[cartSections].s2ServiceTotal": (s, g)=>s + g.total
            }["CartPage.useMemo[cartSections].s2ServiceTotal"], 0);
            const s3ServiceTotal = s3ServiceGroups.reduce({
                "CartPage.useMemo[cartSections].s3ServiceTotal": (s, g)=>s + g.total
            }["CartPage.useMemo[cartSections].s3ServiceTotal"], 0);
            const s1ProductCount = countItems(s1Products, s1Components);
            const s2ProductCount = countItems(s2Products, s2Components);
            const s3ProductCount = countItems(s3Products, s3Components);
            const s1ServiceCategoryCount = cartServiceItems.length;
            const s2ServiceCategoryCount = s2ServiceGroups.length;
            const s3ServiceCategoryCount = s3ServiceGroups.length;
            return [
                {
                    id: 'section1',
                    title: 'Товары для отправки на проверку',
                    products: s1Products,
                    components: s1Components,
                    orderServiceGroups: [],
                    productTotal: sumItems(s1Products, s1Components),
                    serviceTotal: s1ServiceTotal,
                    total: sumItems(s1Products, s1Components) + s1ServiceTotal,
                    itemCount: s1ProductCount + s1ServiceCategoryCount,
                    productCount: s1ProductCount,
                    serviceCategoryCount: s1ServiceCategoryCount
                },
                {
                    id: 'section2',
                    title: 'На проверке у менеджера',
                    products: s2Products,
                    components: s2Components,
                    orderServiceGroups: s2ServiceGroups,
                    productTotal: sumItems(s2Products, s2Components),
                    serviceTotal: s2ServiceTotal,
                    total: sumItems(s2Products, s2Components) + s2ServiceTotal,
                    itemCount: s2ProductCount + s2ServiceCategoryCount,
                    productCount: s2ProductCount,
                    serviceCategoryCount: s2ServiceCategoryCount
                },
                {
                    id: 'section3',
                    title: 'Проверено — готово к оформлению',
                    products: s3Products,
                    components: s3Components,
                    orderServiceGroups: s3ServiceGroups,
                    productTotal: sumItems(s3Products, s3Components),
                    serviceTotal: s3ServiceTotal,
                    total: sumItems(s3Products, s3Components) + s3ServiceTotal,
                    itemCount: s3ProductCount + s3ServiceCategoryCount,
                    productCount: s3ProductCount,
                    serviceCategoryCount: s3ServiceCategoryCount
                }
            ];
        }
    }["CartPage.useMemo[cartSections]"], [
        cart,
        cartServiceItems,
        section1ItemIds,
        section2ItemIds,
        section3ItemIds,
        pendingReviewOrder,
        returnedForCorrectionOrder,
        approvedOrder
    ]);
    /** Комментарий менеджера по позиции заказа — показываем на карточке товара в корзине (по совпадению productId, size, openingSide). Учитываем заказ на проверке, проверенный и на доработке. */ const managerCommentByCartItemId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CartPage.useMemo[managerCommentByCartItemId]": ()=>{
            const map = new Map();
            const order = approvedOrder ?? pendingReviewOrder ?? returnedForCorrectionOrder ?? null;
            if (!order?.items?.length || !cart.length) return map;
            for (const o of order.items){
                const comment = typeof o.managerComment === 'string' && o.managerComment.trim() ? o.managerComment.trim() : null;
                if (!comment) continue;
                const productId = o.productId ?? o.product?.id ?? null;
                const size = o.size ?? null;
                const openingSide = o.openingSide ?? null;
                for (const c of cart){
                    const cProductId = c.product?.id ?? null;
                    if (cProductId !== productId) continue;
                    if ((c.size ?? null) !== size) continue;
                    if ((c.openingSide ?? null) !== openingSide) continue;
                    map.set(c.id, comment);
                }
            }
            return map;
        }
    }["CartPage.useMemo[managerCommentByCartItemId]"], [
        approvedOrder,
        pendingReviewOrder,
        returnedForCorrectionOrder,
        cart
    ]);
    const handleAddToOrder = async (cartItemId)=>{
        if (!pendingReviewOrder) return;
        setAddToOrderInProgress((prev)=>new Set(prev).add(cartItemId));
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addCartItemToOrder"])(pendingReviewOrder.id, cartItemId);
            await refreshCart();
            const orders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserOrders"])();
            setUserOrders(orders);
        } catch (err) {
            alert(err instanceof Error ? err.message : 'Не удалось добавить товар в заказ');
        } finally{
            setAddToOrderInProgress((prev)=>{
                const next = new Set(prev);
                next.delete(cartItemId);
                return next;
            });
        }
    };
    const buildDeliveryPayload = ()=>{
        if (!wantDelivery || !deliveryFormValid || !calculatedDelivery) return null;
        const payload = {
            deliveryAddress: {
                street: deliveryForm.street.trim(),
                city: deliveryForm.city.trim()
            },
            deliveryType: deliveryForm.deliveryType
        };
        if (deliveryForm.deliveryType === 'TO_APARTMENT') {
            const floor = parseInt(deliveryForm.deliveryFloor, 10);
            if (!isNaN(floor) && floor >= 1) {
                payload.deliveryFloor = floor;
                payload.deliveryHasElevator = deliveryForm.deliveryHasElevator;
            }
        }
        if (deliveryForm.preferredDeliveryTime.trim()) {
            payload.preferredDeliveryTime = deliveryForm.preferredDeliveryTime.trim();
        }
        const dist = parseFloat(deliveryForm.distanceKm);
        if (deliveryForm.distanceKm.trim() !== '' && !isNaN(dist) && dist >= 0) {
            payload.distanceKm = dist;
        }
        return payload;
    };
    const hasServiceItems = cartServiceItems.length > 0;
    const canSubmitForReview = returnedForCorrectionOrder ? section2ItemIds.size > 0 || hasServiceItems : section1ItemIds.size > 0 || hasServiceItems;
    const hasNewServiceItems = cartServiceItems.length > 0;
    const hasNewItemsForReview = section1ItemIds.size > 0 || hasNewServiceItems;
    const needsAddToApprovedConfirm = !!approvedOrder && approvalRemainingMs > 0 && hasNewItemsForReview && !returnedForCorrectionOrder;
    const needsAddToPendingReviewConfirm = !!pendingReviewOrder && hasNewItemsForReview && !returnedForCorrectionOrder && !needsAddToApprovedConfirm;
    const doSubmitForReview = async (options)=>{
        setSubmitInProgress(true);
        try {
            const payload = buildDeliveryPayload();
            const cartItemIdsToSubmit = returnedForCorrectionOrder != null ? [
                ...Array.from(section1ItemIds),
                ...Array.from(section2ItemIds)
            ] : Array.from(section1ItemIds);
            const basePayload = payload != null ? {
                ...payload,
                cartItemIds: cartItemIdsToSubmit
            } : {
                cartItemIds: cartItemIdsToSubmit
            };
            let fullPayload = basePayload;
            if (options?.addToApproved === true) fullPayload = {
                ...fullPayload,
                addToApproved: true
            };
            if (options?.addToPendingReview === true) fullPayload = {
                ...fullPayload,
                addToPendingReview: true
            };
            const returnedOrder = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["submitOrderFromCart"])(fullPayload);
            setShowAddToApprovedModal(false);
            setShowAddToPendingReviewModal(false);
            await refreshCart();
            setUserOrders((prev)=>{
                const list = prev ?? [];
                const idx = list.findIndex((o)=>o.id === returnedOrder.id);
                if (idx >= 0) {
                    const next = [
                        ...list
                    ];
                    next[idx] = {
                        ...next[idx],
                        ...returnedOrder
                    };
                    return next;
                }
                return [
                    returnedOrder,
                    ...list
                ];
            });
            const orders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserOrders"])();
            setUserOrders(orders);
        } catch (err) {
            alert(err instanceof Error ? err.message : 'Не удалось отправить заказ на проверку');
        } finally{
            setSubmitInProgress(false);
        }
    };
    const handleSubmitForReview = ()=>{
        if (needsAddToApprovedConfirm) {
            setShowAddToApprovedModal(true);
            return;
        }
        if (needsAddToPendingReviewConfirm) {
            setShowAddToPendingReviewModal(true);
            return;
        }
        doSubmitForReview();
    };
    const handleDeliveryCheckboxChange = (e)=>{
        const checked = e.target.checked;
        if (!checked) {
            setWantDelivery(false);
            return;
        }
        setWantDelivery(true);
    };
    const orderToCancel = pendingReviewOrder ?? returnedForCorrectionOrder;
    const handleCancelReview = async ()=>{
        if (!orderToCancel) return;
        setCancelInProgress(true);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cancelOrderByCustomer"])(orderToCancel.id);
            const orders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserOrders"])();
            setUserOrders(orders);
        } catch (err) {
            alert(err instanceof Error ? err.message : 'Не удалось отменить заказ');
        } finally{
            setCancelInProgress(false);
        }
    };
    const handleQuantityChange = async (itemId, newQuantity)=>{
        // Если количество становится 0 или меньше, удаляем товар из корзины
        if (newQuantity < 1) {
            await handleRemoveItem(itemId);
            return;
        }
        const itemKey = `item-${itemId}`;
        setUpdatingItems((prev)=>new Set(prev).add(itemKey));
        try {
            await updateCartItemQuantityById(itemId, newQuantity);
        } catch (err) {
            if (err instanceof Error) {
                alert(err.message);
            } else {
                alert('Произошла ошибка при обновлении количества');
            }
        } finally{
            setUpdatingItems((prev)=>{
                const next = new Set(prev);
                next.delete(itemKey);
                return next;
            });
        }
    };
    const handleComponentQuantityChange = async (componentId, newQuantity)=>{
        // Если количество становится 0 или меньше, удаляем комплектующее из корзины
        if (newQuantity <= 0) {
            await handleRemoveComponent(componentId);
            return;
        }
        const itemKey = `component-${componentId}`;
        setUpdatingItems((prev)=>new Set(prev).add(itemKey));
        try {
            await updateComponentQuantity(componentId, newQuantity);
        } catch (err) {
            if (err instanceof Error) {
                alert(err.message);
            } else {
                alert('Произошла ошибка при обновлении количества');
            }
        } finally{
            setUpdatingItems((prev)=>{
                const next = new Set(prev);
                next.delete(itemKey);
                return next;
            });
        }
    };
    const handleRemoveItem = async (itemId)=>{
        const item = cart.find((c)=>c.id === itemId);
        const needConfirm = item ? guard.hasApprovedOrder && guard.isCartItemInApprovedOrder(item) : false;
        const ok = await guard.confirmBeforeCartChange(async ()=>{
            const itemKey = `item-${itemId}`;
            setUpdatingItems((prev)=>new Set(prev).add(itemKey));
            try {
                await removeCartItemById(itemId);
            } catch (err) {
                if (err instanceof Error) alert(err.message);
                else alert('Произошла ошибка при удалении товара');
            } finally{
                setUpdatingItems((prev)=>{
                    const next = new Set(prev);
                    next.delete(itemKey);
                    return next;
                });
            }
        }, needConfirm);
        if (!ok && needConfirm) return;
    };
    const handleRemoveComponent = async (componentId)=>{
        const item = cart.find((c)=>c.componentId === componentId);
        const needConfirm = item ? guard.hasApprovedOrder && guard.isCartItemInApprovedOrder(item) : false;
        const ok = await guard.confirmBeforeCartChange(async ()=>{
            const itemKey = `component-${componentId}`;
            setUpdatingItems((prev)=>new Set(prev).add(itemKey));
            try {
                await removeComponentFromCart(componentId);
            } catch (err) {
                if (err instanceof Error) alert(err.message);
                else alert('Произошла ошибка при удалении комплектующего');
            } finally{
                setUpdatingItems((prev)=>{
                    const next = new Set(prev);
                    next.delete(itemKey);
                    return next;
                });
            }
        }, needConfirm);
        if (!ok && needConfirm) return;
    };
    const totalPrice = getTotalPrice();
    /** Суммарные данные по всем секциям (включая заказы) — для заголовка при наличии заказов. */ const allSectionsTotal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CartPage.useMemo[allSectionsTotal]": ()=>{
            const total = cartSections.reduce({
                "CartPage.useMemo[allSectionsTotal].total": (s, sec)=>s + sec.total
            }["CartPage.useMemo[allSectionsTotal].total"], 0);
            const items = cartSections.reduce({
                "CartPage.useMemo[allSectionsTotal].items": (s, sec)=>s + sec.itemCount
            }["CartPage.useMemo[allSectionsTotal].items"], 0);
            return {
                total,
                items
            };
        }
    }["CartPage.useMemo[allSectionsTotal]"], [
        cartSections
    ]);
    const hasAnyContent = cart.length > 0 || cartServiceItems.length > 0 || allSectionsTotal.items > 0;
    /** Достаточно для расчёта стоимости — город и улица. Этаж не обязателен. */ const deliveryFormValidForCalculation = wantDelivery && deliveryForm.street.trim() !== '' && deliveryForm.city.trim() !== '' && deliveryForm.city !== '__OTHER__';
    /** Достаточно для отправки заказа — для TO_APARTMENT нужен этаж. */ const deliveryFormValid = deliveryFormValidForCalculation && (deliveryForm.deliveryType === 'TO_ENTRANCE' || deliveryForm.deliveryType === 'TO_APARTMENT' && deliveryForm.deliveryFloor.trim() !== '' && parseInt(deliveryForm.deliveryFloor, 10) >= 1);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartPage.useEffect": ()=>{
            if (!wantDelivery || !deliveryFormValidForCalculation) {
                setCalculatedDelivery(null);
                setDeliveryCalculationError(null);
                return;
            }
            const floorNum = deliveryForm.deliveryType === 'TO_APARTMENT' && deliveryForm.deliveryFloor.trim() !== '' ? parseInt(deliveryForm.deliveryFloor, 10) : undefined;
            const distanceKmNum = deliveryForm.distanceKm.trim() !== '' ? parseFloat(deliveryForm.distanceKm) : undefined;
            let cancelled = false;
            setDeliveryCalculationLoading(true);
            setDeliveryCalculationError(null);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateDelivery"])({
                subtotal: totalPrice,
                city: deliveryForm.city.trim(),
                distanceKm: distanceKmNum != null && !isNaN(distanceKmNum) ? distanceKmNum : undefined,
                deliveryType: deliveryForm.deliveryType,
                deliveryFloor: floorNum,
                deliveryHasElevator: deliveryForm.deliveryType === 'TO_APARTMENT' ? deliveryForm.deliveryHasElevator : undefined
            }).then({
                "CartPage.useEffect": (res)=>{
                    if (!cancelled) {
                        setCalculatedDelivery(res);
                        setDeliveryCalculationError(null);
                    }
                }
            }["CartPage.useEffect"]).catch({
                "CartPage.useEffect": (err)=>{
                    if (!cancelled) {
                        setCalculatedDelivery(null);
                        setDeliveryCalculationError(err instanceof Error ? err.message : 'Не удалось рассчитать доставку');
                    }
                }
            }["CartPage.useEffect"]).finally({
                "CartPage.useEffect": ()=>{
                    if (!cancelled) setDeliveryCalculationLoading(false);
                }
            }["CartPage.useEffect"]);
            return ({
                "CartPage.useEffect": ()=>{
                    cancelled = true;
                }
            })["CartPage.useEffect"];
        }
    }["CartPage.useEffect"], [
        wantDelivery,
        deliveryFormValidForCalculation,
        totalPrice,
        deliveryForm.city,
        deliveryForm.distanceKm,
        deliveryForm.deliveryType,
        deliveryForm.deliveryFloor,
        deliveryForm.deliveryHasElevator
    ]);
    const pluralizeRu = (count, one, few, many)=>{
        const mod10 = count % 10;
        const mod100 = count % 100;
        if (mod10 === 1 && mod100 !== 11) return one;
        if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
        return many;
    };
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading,
                children: "Загрузка корзины..."
            }, void 0, false, {
                fileName: "[project]/src/app/(site)/cart/page.tsx",
                lineNumber: 1038,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/(site)/cart/page.tsx",
            lineNumber: 1037,
            columnNumber: 7
        }, this);
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        children: "Ошибка"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                        lineNumber: 1047,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                        lineNumber: 1048,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link,
                        children: "Вернуться на главную"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                        lineNumber: 1049,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(site)/cart/page.tsx",
                lineNumber: 1046,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/(site)/cart/page.tsx",
            lineNumber: 1045,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: "Корзина"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                        lineNumber: 1060,
                        columnNumber: 9
                    }, this),
                    hasAnyContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                        children: [
                            allSectionsTotal.items,
                            ' ',
                            pluralizeRu(allSectionsTotal.items, 'позиция', 'позиции', 'позиций'),
                            " на сумму",
                            ' ',
                            allSectionsTotal.total.toLocaleString('ru-RU'),
                            " ₽"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                        lineNumber: 1062,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(site)/cart/page.tsx",
                lineNumber: 1059,
                columnNumber: 7
            }, this),
            !hasAnyContent ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: "Ваша корзина пуста"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                        lineNumber: 1072,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Добавьте товары или услуги в корзину, чтобы оформить заказ"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                        lineNumber: 1073,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/catalog/products",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link,
                        children: "Перейти в каталог"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                        lineNumber: 1074,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(site)/cart/page.tsx",
                lineNumber: 1071,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartItems,
                    children: [
                        cartSections.map((section)=>(section.products.length > 0 || section.components.length > 0 || section.orderServiceGroups.length > 0 || section.id === 'section1' && cartServiceItems.length > 0 || section.id === 'section1' && returnedForCorrectionOrder && canSubmitForReview) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSection,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionTitle,
                                        children: section.title
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                        lineNumber: 1091,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionItems,
                                        children: [
                                            section.products.map((item)=>{
                                                const itemKey = `item-${item.id}`;
                                                const isUpdating = updatingItems.has(itemKey);
                                                // Убеждаемся, что quantity - это число, и оно больше 0
                                                let quantity;
                                                if (typeof item.quantity === 'number') {
                                                    quantity = item.quantity;
                                                } else if (typeof item.quantity === 'string') {
                                                    quantity = parseInt(item.quantity, 10);
                                                } else {
                                                    quantity = 1;
                                                }
                                                // Гарантируем, что quantity >= 1
                                                if (isNaN(quantity) || quantity < 1) {
                                                    quantity = 1;
                                                }
                                                const itemTotal = item.product.price * quantity;
                                                const managerComment = managerCommentByCartItemId.get(item.id);
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartItem,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            href: `/product/${item.product.slug}`,
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemImage,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                src: item.product.images?.[0] || '/images/products/door-placeholder.jpg',
                                                                alt: item.product.name,
                                                                width: 88,
                                                                height: 88,
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].image
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1118,
                                                                columnNumber: 31
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1114,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInfo,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    href: `/product/${item.product.slug}`,
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemName,
                                                                    children: item.product.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1131,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemCategory,
                                                                    children: item.product.category.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1137,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemPrice,
                                                                    children: [
                                                                        item.product.price.toLocaleString(),
                                                                        " ₽ за шт."
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1138,
                                                                    columnNumber: 31
                                                                }, this),
                                                                (item.size || item.openingSide || item.product.stock !== undefined && item.product.stock === 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemOptionsRow,
                                                                    children: [
                                                                        (item.size || item.openingSide) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemOptions,
                                                                            children: [
                                                                                item.size && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemOption,
                                                                                    children: [
                                                                                        "Размер: ",
                                                                                        item.size
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1148,
                                                                                    columnNumber: 41
                                                                                }, this),
                                                                                item.openingSide && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemOption,
                                                                                    children: [
                                                                                        "Сторона открывания: ",
                                                                                        item.openingSide
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1153,
                                                                                    columnNumber: 41
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1146,
                                                                            columnNumber: 37
                                                                        }, this),
                                                                        item.product.stock !== undefined && item.product.stock === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].outOfStockBadge,
                                                                            children: "Под заказ"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1160,
                                                                            columnNumber: 37
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1144,
                                                                    columnNumber: 33
                                                                }, this),
                                                                managerComment && !dismissedManagerCommentIds.has(item.id) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemManagerComment,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            type: "button",
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemManagerCommentClose,
                                                                            onClick: ()=>setDismissedManagerCommentIds((prev)=>new Set(prev).add(item.id)),
                                                                            "aria-label": "Закрыть рекомендации менеджера",
                                                                            title: "Закрыть",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
                                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemManagerCommentCloseIcon
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1177,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1166,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemManagerCommentLabel,
                                                                            children: "Рекомендации менеджера:"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1179,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemManagerCommentText,
                                                                            children: managerComment
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1182,
                                                                            columnNumber: 35
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1165,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1130,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemQuantityAndTotal,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemQuantity,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            type: "button",
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityButton,
                                                                            onClick: ()=>handleQuantityChange(item.id, quantity - 1),
                                                                            disabled: isUpdating,
                                                                            "aria-label": "Уменьшить количество",
                                                                            children: "−"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1191,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityValue,
                                                                            children: quantity
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1200,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            type: "button",
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityButton,
                                                                            onClick: ()=>handleQuantityChange(item.id, quantity + 1),
                                                                            disabled: isUpdating,
                                                                            "aria-label": "Увеличить количество",
                                                                            children: "+"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1201,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1190,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].totalPrice,
                                                                    children: [
                                                                        itemTotal.toLocaleString(),
                                                                        " ₽"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1211,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1189,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemActionsColumn,
                                                            children: [
                                                                cartItemIdsInApprovedOrder.has(item.id) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInOrderBadge,
                                                                    title: "Проверено",
                                                                    "aria-hidden": true,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].doubleCheckIcon,
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        fill: "none",
                                                                        viewBox: "0 0 24 24",
                                                                        strokeWidth: 2.5,
                                                                        stroke: "currentColor",
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M5 12l3 3 7-7"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1233,
                                                                                columnNumber: 37
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M9 15l2 2 5-5"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1234,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 1223,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1218,
                                                                    columnNumber: 33
                                                                }, this) : cartItemIdsInOrder.has(item.id) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInOrderBadge,
                                                                    title: "В заказе на проверке",
                                                                    "aria-hidden": true,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressIconSmall,
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        fill: "none",
                                                                        viewBox: "0 0 24 24",
                                                                        strokeWidth: 2,
                                                                        stroke: "currentColor",
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressSpinnerArc,
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                    strokeDasharray: "28 56",
                                                                                    d: "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18z"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1254,
                                                                                    columnNumber: 39
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1253,
                                                                                columnNumber: 37
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressCheck,
                                                                                d: "M7 12l3.5 3.5L17 9"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1259,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 1243,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1238,
                                                                    columnNumber: 33
                                                                }, this) : pendingReviewOrder && section.id !== 'section1' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    type: "button",
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].addToOrderButton,
                                                                    onClick: ()=>handleAddToOrder(item.id),
                                                                    disabled: addToOrderInProgress.has(item.id),
                                                                    "aria-label": "Проверить",
                                                                    children: addToOrderInProgress.has(item.id) ? '…' : 'Проверить'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1266,
                                                                    columnNumber: 33
                                                                }, this) : null,
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    type: "button",
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].removeButton,
                                                                    onClick: ()=>handleRemoveItem(item.id),
                                                                    disabled: isUpdating || cartItemIdsInOrder.has(item.id),
                                                                    title: cartItemIdsInApprovedOrder.has(item.id) ? 'Удалить (заказ будет переоформлен)' : cartItemIdsInOrder.has(item.id) ? 'Нельзя удалить: товар в заказе на проверке' : 'Удалить товар',
                                                                    "aria-label": "Удалить товар",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].removeButtonIcon
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 1290,
                                                                        columnNumber: 33
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1276,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1216,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, item.id, true, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 1113,
                                                    columnNumber: 27
                                                }, this);
                                            }),
                                            section.components.map((item)=>{
                                                const itemKey = `component-${item.componentId}`;
                                                const isUpdating = updatingItems.has(itemKey);
                                                // quantity может быть дробным (например, 2,5 для «Стойка коробки»)
                                                let quantity;
                                                if (typeof item.quantity === 'number') {
                                                    quantity = item.quantity;
                                                } else if (typeof item.quantity === 'string') {
                                                    quantity = parseFloat(item.quantity);
                                                } else {
                                                    quantity = 1;
                                                }
                                                if (isNaN(quantity) || quantity <= 0) {
                                                    quantity = 1;
                                                }
                                                // «Стойка коробки» — шаг 0,5, минимум 0,5; остальные — шаг 1, минимум 1
                                                const isStoikaKorobka = /стойка\s+коробки/i.test(item.component.name) || /стойка\s+коробки/i.test(item.component.type) || item.component.name === 'Коробка' && !/стойки/i.test(item.component.type ?? '');
                                                const step = isStoikaKorobka ? 0.5 : 1;
                                                const minQty = isStoikaKorobka ? 0.5 : 1;
                                                const displayQty = step === 0.5 && quantity % 1 !== 0 ? quantity.toFixed(1) : String(quantity);
                                                const newQtyDown = Math.round((quantity - step) * 2) / 2;
                                                const newQtyUp = Math.round((quantity + step) * 2) / 2;
                                                const itemTotal = item.component.price * quantity;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartItem,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            href: `/product/${item.component.product.slug}`,
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemImage,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                src: item.component.image || '/images/products/door-placeholder.jpg',
                                                                alt: item.component.name,
                                                                width: 88,
                                                                height: 88,
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].image
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1334,
                                                                columnNumber: 31
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1330,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInfo,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    href: `/product/${item.component.product.slug}`,
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemName,
                                                                    children: item.component.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1346,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemCategory,
                                                                    children: [
                                                                        item.component.type,
                                                                        " • ",
                                                                        item.component.product.name
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1352,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemPrice,
                                                                    children: [
                                                                        item.component.price.toLocaleString(),
                                                                        " ₽ за шт."
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1355,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1345,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemQuantityAndTotal,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemQuantity,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            type: "button",
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityButton,
                                                                            onClick: async ()=>{
                                                                                if (newQtyDown < minQty) {
                                                                                    await handleRemoveComponent(item.componentId);
                                                                                } else {
                                                                                    await handleComponentQuantityChange(item.componentId, newQtyDown);
                                                                                }
                                                                            },
                                                                            disabled: isUpdating,
                                                                            "aria-label": "Уменьшить количество",
                                                                            children: "−"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1362,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityValue,
                                                                            children: displayQty
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1380,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            type: "button",
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].quantityButton,
                                                                            onClick: ()=>handleComponentQuantityChange(item.componentId, newQtyUp),
                                                                            disabled: isUpdating,
                                                                            "aria-label": "Увеличить количество",
                                                                            children: "+"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1381,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1361,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].totalPrice,
                                                                    children: [
                                                                        itemTotal.toLocaleString(),
                                                                        " ₽"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1393,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1360,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemActionsColumn,
                                                            children: [
                                                                cartItemIdsInApprovedOrder.has(item.id) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInOrderBadge,
                                                                    title: "Проверено",
                                                                    "aria-hidden": true,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].doubleCheckIcon,
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        fill: "none",
                                                                        viewBox: "0 0 24 24",
                                                                        strokeWidth: 2.5,
                                                                        stroke: "currentColor",
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M5 12l3 3 7-7"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1415,
                                                                                columnNumber: 37
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M9 15l2 2 5-5"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1416,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 1405,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1400,
                                                                    columnNumber: 33
                                                                }, this) : cartItemIdsInOrder.has(item.id) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInOrderBadge,
                                                                    title: "В заказе на проверке",
                                                                    "aria-hidden": true,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressIconSmall,
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        fill: "none",
                                                                        viewBox: "0 0 24 24",
                                                                        strokeWidth: 2,
                                                                        stroke: "currentColor",
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressSpinnerArc,
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                    strokeDasharray: "28 56",
                                                                                    d: "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18z"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1436,
                                                                                    columnNumber: 39
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1435,
                                                                                columnNumber: 37
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressCheck,
                                                                                d: "M7 12l3.5 3.5L17 9"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1441,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 1425,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1420,
                                                                    columnNumber: 33
                                                                }, this) : pendingReviewOrder && section.id !== 'section1' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    type: "button",
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].addToOrderButton,
                                                                    onClick: ()=>handleAddToOrder(item.id),
                                                                    disabled: addToOrderInProgress.has(item.id),
                                                                    "aria-label": "Проверить",
                                                                    children: addToOrderInProgress.has(item.id) ? '…' : 'Проверить'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1448,
                                                                    columnNumber: 33
                                                                }, this) : null,
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    type: "button",
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].removeButton,
                                                                    onClick: ()=>handleRemoveComponent(item.componentId),
                                                                    disabled: isUpdating || cartItemIdsInOrder.has(item.id),
                                                                    title: cartItemIdsInApprovedOrder.has(item.id) ? 'Удалить (заказ будет переоформлен)' : cartItemIdsInOrder.has(item.id) ? 'Нельзя удалить: товар в заказе на проверке' : 'Удалить комплектующее',
                                                                    "aria-label": "Удалить комплектующее",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].removeButtonIcon
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 1472,
                                                                        columnNumber: 33
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1458,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1398,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, item.id, true, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 1329,
                                                    columnNumber: 27
                                                }, this);
                                            }),
                                            section.id === 'section1' && cartServiceItems.map((item)=>{
                                                const legacyItems = Array.isArray(item.items) ? item.items : [];
                                                const roomsForPreset = item.rooms && item.rooms.length > 0 ? item.rooms : [
                                                    {
                                                        name: 'Помещение',
                                                        items: (item.itemsWithDetails ?? legacyItems).map((i)=>({
                                                                itemId: i.itemId,
                                                                quantity: i.quantity
                                                            }))
                                                    }
                                                ];
                                                const displayRooms = item.roomsWithDetails && item.roomsWithDetails.length > 0 ? item.roomsWithDetails : [
                                                    {
                                                        name: 'Помещение',
                                                        items: item.itemsWithDetails && item.itemsWithDetails.length > 0 ? item.itemsWithDetails : legacyItems.map((i)=>({
                                                                itemId: i.itemId,
                                                                quantity: i.quantity,
                                                                name: '—',
                                                                unit: '—',
                                                                price: 0,
                                                                amount: 0
                                                            })),
                                                        total: item.total ?? 0
                                                    }
                                                ];
                                                const totalPositions = displayRooms.reduce((sum, room)=>sum + room.items.length, 0);
                                                const roomsParam = roomsForPreset.length > 0 ? buildRoomsParam(roomsForPreset) : '';
                                                const serviceHref = item.category?.slug ? `/catalog/services/${item.category.slug}${roomsParam ? `?rooms=${encodeURIComponent(roomsParam)}` : ''}` : '/catalog/services';
                                                const serviceTotal = item.total != null && item.total > 0 ? item.total : 0;
                                                const serviceContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceItemIcon,
                                                            "aria-hidden": true,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                strokeWidth: 1.5,
                                                                stroke: "currentColor",
                                                                width: 40,
                                                                height: 40,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    d: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1538,
                                                                    columnNumber: 35
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1529,
                                                                columnNumber: 33
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1528,
                                                            columnNumber: 31
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInfo,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemName,
                                                                    children: [
                                                                        item.category.name,
                                                                        " (",
                                                                        totalPositions,
                                                                        ")"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1546,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceItemLines,
                                                                    children: displayRooms.map((room, roomIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceRoomTitle,
                                                                                    children: [
                                                                                        room.name,
                                                                                        " (",
                                                                                        room.items.length,
                                                                                        ")"
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1552,
                                                                                    columnNumber: 39
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceRoomList,
                                                                                    children: room.items.map((line)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceItemLine,
                                                                                            children: [
                                                                                                line.name,
                                                                                                " — ",
                                                                                                line.quantity,
                                                                                                " ",
                                                                                                line.unit
                                                                                            ]
                                                                                        }, line.itemId, true, {
                                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                            lineNumber: 1557,
                                                                                            columnNumber: 43
                                                                                        }, this))
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1555,
                                                                                    columnNumber: 39
                                                                                }, this)
                                                                            ]
                                                                        }, `${item.id}-room-${roomIndex}`, true, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1551,
                                                                            columnNumber: 37
                                                                        }, this))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1549,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1545,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, void 0, true);
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartItem,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            href: serviceHref,
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceItemLink,
                                                            children: serviceContent
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1570,
                                                            columnNumber: 31
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemQuantityAndTotal,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].totalPrice,
                                                                children: [
                                                                    serviceTotal.toLocaleString('ru-RU'),
                                                                    " ₽"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1574,
                                                                columnNumber: 33
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1573,
                                                            columnNumber: 31
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemActionsColumn,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].removeButton,
                                                                onClick: ()=>removeCartServiceItemById(item.id),
                                                                title: "Удалить услуги из корзины",
                                                                "aria-label": "Удалить услуги",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].removeButtonIcon
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1586,
                                                                    columnNumber: 35
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1579,
                                                                columnNumber: 33
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1578,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, `svc-${item.id}`, true, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 1569,
                                                    columnNumber: 29
                                                }, this);
                                            }),
                                            (section.id === 'section2' || section.id === 'section3') && section.orderServiceGroups.map((group, idx)=>{
                                                const orderIdForServices = section.id === 'section2' ? (pendingReviewOrder ?? returnedForCorrectionOrder)?.id : approvedOrder?.id;
                                                const roomsForPreset = group.rooms.map((room)=>({
                                                        name: room.roomName,
                                                        items: room.items.map((i)=>({
                                                                itemId: i.itemId,
                                                                quantity: i.quantity
                                                            }))
                                                    }));
                                                const queryParams = new URLSearchParams();
                                                if (roomsForPreset.length > 0) {
                                                    queryParams.set('rooms', buildRoomsParam(roomsForPreset));
                                                }
                                                if (orderIdForServices) {
                                                    queryParams.set('orderId', orderIdForServices);
                                                }
                                                const query = queryParams.toString();
                                                const orderServiceHref = group.categorySlug ? `/catalog/services/${group.categorySlug}${query ? `?${query}` : ''}` : '/catalog/services';
                                                const orderServiceContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceItemIcon,
                                                            "aria-hidden": true,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                strokeWidth: 1.5,
                                                                stroke: "currentColor",
                                                                width: 40,
                                                                height: 40,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    d: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1628,
                                                                    columnNumber: 35
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1619,
                                                                columnNumber: 33
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1618,
                                                            columnNumber: 31
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInfo,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemName,
                                                                    children: [
                                                                        group.categoryName,
                                                                        " (",
                                                                        group.rooms.reduce((sum, room)=>sum + room.items.length, 0),
                                                                        ")"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1636,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceItemLines,
                                                                    children: group.rooms.map((room, roomIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceRoomTitle,
                                                                                    children: [
                                                                                        room.roomName,
                                                                                        " (",
                                                                                        room.items.length,
                                                                                        ")"
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1643,
                                                                                    columnNumber: 39
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceRoomList,
                                                                                    children: room.items.map((line)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceItemLine,
                                                                                            children: [
                                                                                                line.name,
                                                                                                " — ",
                                                                                                line.quantity,
                                                                                                " ",
                                                                                                line.unit
                                                                                            ]
                                                                                        }, line.itemId, true, {
                                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                            lineNumber: 1648,
                                                                                            columnNumber: 43
                                                                                        }, this))
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1646,
                                                                                    columnNumber: 39
                                                                                }, this)
                                                                            ]
                                                                        }, `${group.categoryName}-${roomIndex}`, true, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 1642,
                                                                            columnNumber: 37
                                                                        }, this))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1640,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1635,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, void 0, true);
                                                const orderServiceStatusIcon = section.id === 'section3' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInOrderBadge,
                                                    title: "Проверено",
                                                    "aria-hidden": true,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].doubleCheckIcon,
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        fill: "none",
                                                        viewBox: "0 0 24 24",
                                                        strokeWidth: 2.5,
                                                        stroke: "currentColor",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M5 12l3 3 7-7"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1676,
                                                                columnNumber: 35
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M9 15l2 2 5-5"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1677,
                                                                columnNumber: 35
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1666,
                                                        columnNumber: 33
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 1661,
                                                    columnNumber: 31
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInOrderBadge,
                                                    title: "В заказе на проверке",
                                                    "aria-hidden": true,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressIconSmall,
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        fill: "none",
                                                        viewBox: "0 0 24 24",
                                                        strokeWidth: 2,
                                                        stroke: "currentColor",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressSpinnerArc,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeDasharray: "28 56",
                                                                    d: "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 1697,
                                                                    columnNumber: 37
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1696,
                                                                columnNumber: 35
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressCheck,
                                                                d: "M7 12l3.5 3.5L17 9"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1702,
                                                                columnNumber: 35
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1686,
                                                        columnNumber: 33
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 1681,
                                                    columnNumber: 31
                                                }, this);
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartItem,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            href: orderServiceHref,
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].serviceItemLink,
                                                            children: orderServiceContent
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1711,
                                                            columnNumber: 31
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemQuantityAndTotal,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].totalPrice,
                                                                children: [
                                                                    group.total.toLocaleString('ru-RU'),
                                                                    " ₽"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1715,
                                                                columnNumber: 33
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1714,
                                                            columnNumber: 31
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemActionsColumn,
                                                            children: orderServiceStatusIcon
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1719,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, `order-svc-${section.id}-${idx}`, true, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 1710,
                                                    columnNumber: 29
                                                }, this);
                                            })
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                        lineNumber: 1092,
                                        columnNumber: 21
                                    }, this),
                                    section.id === 'section1' && !orderWithDelivery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCheckboxWrap,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCheckboxLabel,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "checkbox",
                                                        checked: wantDelivery,
                                                        onChange: handleDeliveryCheckboxChange,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCheckbox
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1730,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Оформить доставку"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1736,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 1729,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCheckboxHint,
                                                children: "Заполните адрес и условия доставки — они отправятся на проверку вместе с заказом по кнопке «Отправить на проверку»."
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 1738,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                        lineNumber: 1728,
                                        columnNumber: 23
                                    }, this),
                                    section.id === 'section1' && wantDelivery && !orderWithDelivery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormBlock,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormTitleRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormTitle,
                                                        children: "Адрес и условия доставки"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1748,
                                                        columnNumber: 27
                                                    }, this),
                                                    deliveryPaymentMode === 'ON_SITE' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormPaymentNote,
                                                        children: "Оплата доставки не включается в стоимость заказа, а производится водителю после доставки товара."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1750,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 1747,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormGrid,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormField,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                htmlFor: `delivery-street-${section.id}`,
                                                                children: "Улица, дом, квартира *"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1758,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                id: `delivery-street-${section.id}`,
                                                                type: "text",
                                                                value: deliveryForm.street,
                                                                onChange: (e)=>setDeliveryForm((f)=>({
                                                                            ...f,
                                                                            street: e.target.value
                                                                        })),
                                                                placeholder: "ул. Примерная, д. 1, кв. 1"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1761,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1757,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormField,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                htmlFor: `delivery-city-${section.id}`,
                                                                children: "Город *"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1772,
                                                                columnNumber: 29
                                                            }, this),
                                                            deliverySettlements.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                        id: `delivery-city-${section.id}`,
                                                                        value: deliveryForm.city === '__OTHER__' || deliveryForm.city.trim() !== '' && !deliverySettlements.some((s)=>s.name.trim().toLowerCase() === deliveryForm.city.trim().toLowerCase()) ? '__OTHER__' : deliverySettlements.some((s)=>s.name.trim().toLowerCase() === deliveryForm.city.trim().toLowerCase()) ? deliveryForm.city.trim() : '__SELECT__',
                                                                        onChange: (e)=>{
                                                                            const v = e.target.value;
                                                                            if (v === '__SELECT__') {
                                                                                setDeliveryForm((f)=>({
                                                                                        ...f,
                                                                                        city: '',
                                                                                        distanceKm: ''
                                                                                    }));
                                                                            } else if (v === '__OTHER__') {
                                                                                setDeliveryForm((f)=>({
                                                                                        ...f,
                                                                                        city: '__OTHER__',
                                                                                        distanceKm: f.distanceKm
                                                                                    }));
                                                                            } else {
                                                                                setDeliveryForm((f)=>({
                                                                                        ...f,
                                                                                        city: v,
                                                                                        distanceKm: ''
                                                                                    }));
                                                                            }
                                                                        },
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                value: "__SELECT__",
                                                                                children: "Выберите город"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1809,
                                                                                columnNumber: 35
                                                                            }, this),
                                                                            deliverySettlements.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                    value: s.name,
                                                                                    children: [
                                                                                        s.name,
                                                                                        " — ",
                                                                                        s.price.toLocaleString(),
                                                                                        " ₽"
                                                                                    ]
                                                                                }, s.name, true, {
                                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                    lineNumber: 1811,
                                                                                    columnNumber: 37
                                                                                }, this)),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                value: "__OTHER__",
                                                                                children: "Другой населённый пункт"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 1815,
                                                                                columnNumber: 35
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 1775,
                                                                        columnNumber: 33
                                                                    }, this),
                                                                    (deliveryForm.city === '__OTHER__' || deliveryForm.city.trim() !== '' && !deliverySettlements.some((s)=>s.name.trim().toLowerCase() === deliveryForm.city.trim().toLowerCase())) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "text",
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormOtherCity,
                                                                        value: deliveryForm.city === '__OTHER__' ? '' : deliveryForm.city,
                                                                        onChange: (e)=>setDeliveryForm((f)=>({
                                                                                    ...f,
                                                                                    city: e.target.value
                                                                                })),
                                                                        placeholder: "Укажите населённый пункт"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 1824,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                ]
                                                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                id: `delivery-city-${section.id}`,
                                                                type: "text",
                                                                value: deliveryForm.city,
                                                                onChange: (e)=>setDeliveryForm((f)=>({
                                                                            ...f,
                                                                            city: e.target.value
                                                                        })),
                                                                placeholder: "Мурманск"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1838,
                                                                columnNumber: 31
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1771,
                                                        columnNumber: 27
                                                    }, this),
                                                    (deliverySettlements.length > 0 ? (deliveryForm.city === '__OTHER__' || deliveryForm.city.trim() !== '' && !deliverySettlements.some((s)=>s.name.trim().toLowerCase() === deliveryForm.city.trim().toLowerCase())) && deliveryForm.city !== '__OTHER__' : deliveryForm.city.trim() && !deliveryForm.city.trim().toLowerCase().includes('мурманск')) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormField,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                htmlFor: `delivery-distance-${section.id}`,
                                                                children: "Расстояние от Мурманска, км"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1861,
                                                                columnNumber: 31
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                id: `delivery-distance-${section.id}`,
                                                                type: "number",
                                                                min: 0,
                                                                step: 1,
                                                                value: deliveryForm.distanceKm,
                                                                onChange: (e)=>setDeliveryForm((f)=>({
                                                                            ...f,
                                                                            distanceKm: e.target.value
                                                                        })),
                                                                placeholder: "0"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1864,
                                                                columnNumber: 31
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1860,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 1756,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormRadios,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryRadioLabel,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                type: "radio",
                                                                name: "deliveryType",
                                                                checked: deliveryForm.deliveryType === 'TO_ENTRANCE',
                                                                onChange: ()=>setDeliveryForm((f)=>({
                                                                            ...f,
                                                                            deliveryType: 'TO_ENTRANCE'
                                                                        }))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1880,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "Доставка до подъезда"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1888,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1879,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryRadioLabel,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                type: "radio",
                                                                name: "deliveryType",
                                                                checked: deliveryForm.deliveryType === 'TO_APARTMENT',
                                                                onChange: ()=>setDeliveryForm((f)=>({
                                                                            ...f,
                                                                            deliveryType: 'TO_APARTMENT'
                                                                        }))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1891,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "Доставка до квартиры"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1899,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1890,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 1878,
                                                columnNumber: 25
                                            }, this),
                                            deliveryForm.deliveryType === 'TO_APARTMENT' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormLift,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormField,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                htmlFor: `delivery-floor-${section.id}`,
                                                                children: "Этаж *"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1905,
                                                                columnNumber: 31
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                id: `delivery-floor-${section.id}`,
                                                                type: "number",
                                                                min: 1,
                                                                value: deliveryForm.deliveryFloor,
                                                                onChange: (e)=>setDeliveryForm((f)=>({
                                                                            ...f,
                                                                            deliveryFloor: e.target.value
                                                                        })),
                                                                placeholder: "1"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1906,
                                                                columnNumber: 31
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1904,
                                                        columnNumber: 29
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormCheckbox,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                type: "checkbox",
                                                                checked: deliveryForm.deliveryHasElevator,
                                                                onChange: (e)=>setDeliveryForm((f)=>({
                                                                            ...f,
                                                                            deliveryHasElevator: e.target.checked
                                                                        }))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1918,
                                                                columnNumber: 31
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "Есть лифт"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1928,
                                                                columnNumber: 31
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1917,
                                                        columnNumber: 29
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormMoversNote,
                                                        children: "Стоимость работы одного грузчика производится из расчёта = 1000 руб/час."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1930,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 1903,
                                                columnNumber: 27
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormField} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormDateField}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: `delivery-preferred-date-${section.id}`,
                                                        children: "Выберите удобный для вас день для осуществления доставки (мы постараемся организовать доставку в выбранный вами день)"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1939,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: `delivery-preferred-date-${section.id}`,
                                                        type: "date",
                                                        value: /^\d{4}-\d{2}-\d{2}$/.test(deliveryForm.preferredDeliveryTime) ? deliveryForm.preferredDeliveryTime : '',
                                                        min: new Date().toISOString().slice(0, 10),
                                                        onChange: (e)=>setDeliveryForm((f)=>({
                                                                    ...f,
                                                                    preferredDeliveryTime: e.target.value
                                                                }))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1943,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 1936,
                                                columnNumber: 25
                                            }, this),
                                            deliveryFormValid && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryFormTotal,
                                                children: [
                                                    deliveryCalculationLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCostLine,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCostLabel,
                                                                children: "Стоимость доставки:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1964,
                                                                columnNumber: 33
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCostLoading,
                                                                children: "Рассчитываем…"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1967,
                                                                columnNumber: 33
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1963,
                                                        columnNumber: 31
                                                    }, this),
                                                    !deliveryCalculationLoading && deliveryCalculationError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCostLine,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCostError,
                                                            children: deliveryCalculationError
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 1972,
                                                            columnNumber: 33
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1971,
                                                        columnNumber: 31
                                                    }, this),
                                                    !deliveryCalculationLoading && calculatedDelivery && !deliveryCalculationError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCostLine,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCostLabel,
                                                                children: "Предварительный расчёт доставки:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1981,
                                                                columnNumber: 35
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCostValue,
                                                                children: [
                                                                    calculatedDelivery.totalShippingCost.toLocaleString(),
                                                                    " ₽"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 1984,
                                                                columnNumber: 35
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 1980,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 1961,
                                                columnNumber: 27
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                        lineNumber: 1746,
                                        columnNumber: 23
                                    }, this),
                                    section.id === 'section2' && (pendingOrderHasDelivery || returnedOrderHasDelivery) && orderWithDelivery || section.id === 'section3' && approvedOrderHasDelivery && orderWithDelivery ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactWrap,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactRow,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactIcon,
                                                    "aria-hidden": true,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TruckIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TruckIcon$3e$__["TruckIcon"], {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactIconSvg
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2001,
                                                        columnNumber: 29
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2000,
                                                    columnNumber: 27
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactInfo,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactTitle,
                                                            children: [
                                                                "Доставка",
                                                                deliveryPaymentMode === 'ON_SITE' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryPayOnSiteBadge,
                                                                    role: "status",
                                                                    children: "Оплатить водителю!"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 2007,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 2004,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactDetails,
                                                            children: [
                                                                [
                                                                    orderWithDelivery.shippingAddress?.street,
                                                                    orderWithDelivery.shippingAddress?.city
                                                                ].filter(Boolean).join(', ') || 'Адрес указан',
                                                                ' · ',
                                                                orderWithDelivery.deliveryType === 'TO_APARTMENT' ? 'до квартиры' : 'до подъезда',
                                                                orderWithDelivery.deliveryType === 'TO_APARTMENT' && orderWithDelivery.deliveryFloor != null && `, ${orderWithDelivery.deliveryFloor} этаж`
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 2012,
                                                            columnNumber: 29
                                                        }, this),
                                                        (Number(orderWithDelivery.shippingCost ?? 0) > 0 || Number(orderWithDelivery.carryCost ?? 0) > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactCostBreakdown,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactCostLine,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: [
                                                                                "Доставка:",
                                                                                ' ',
                                                                                (Number(orderWithDelivery.shippingCost) || 0).toLocaleString('ru-RU'),
                                                                                ' ',
                                                                                "₽"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 2031,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        orderWithDelivery.carryCost != null && Number(orderWithDelivery.carryCost) > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: [
                                                                                orderWithDelivery.moversCount != null && orderWithDelivery.moversCount > 0 ? `${orderWithDelivery.moversCount} грузчик${orderWithDelivery.moversCount === 1 ? '' : orderWithDelivery.moversCount < 5 ? 'а' : 'ов'}: ` : 'Грузчики: ',
                                                                                Number(orderWithDelivery.carryCost).toLocaleString('ru-RU'),
                                                                                ' ',
                                                                                "₽"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 2040,
                                                                            columnNumber: 39
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 2030,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactCostTotal,
                                                                    children: [
                                                                        "Итого стоимость доставки:",
                                                                        ' ',
                                                                        (Number(orderWithDelivery.shippingCost ?? 0) + Number(orderWithDelivery.carryCost ?? 0)).toLocaleString('ru-RU'),
                                                                        ' ',
                                                                        "₽"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 2052,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 2029,
                                                            columnNumber: 31
                                                        }, this),
                                                        orderWithDelivery.plannedDeliveryDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryCompactDate,
                                                            children: [
                                                                "Дата доставки:",
                                                                ' ',
                                                                new Date(orderWithDelivery.plannedDeliveryDate).toLocaleDateString('ru-RU')
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 2063,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2003,
                                                    columnNumber: 27
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemActionsColumn,
                                                    children: [
                                                        orderWithDelivery.adminEditedAt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryEditedBadge,
                                                            role: "status",
                                                            children: "Изменено!"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 2073,
                                                            columnNumber: 31
                                                        }, this),
                                                        pendingOrderHasDelivery ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInOrderBadge,
                                                            title: "В заказе на проверке",
                                                            "aria-hidden": true,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressIconSmall,
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                strokeWidth: 2,
                                                                stroke: "currentColor",
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressSpinnerArc,
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                            strokeDasharray: "28 56",
                                                                            d: "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18z"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 2094,
                                                                            columnNumber: 37
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 2093,
                                                                        columnNumber: 35
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewProgressCheck,
                                                                        d: "M7 12l3.5 3.5L17 9"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 2099,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 2083,
                                                                columnNumber: 33
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 2078,
                                                            columnNumber: 31
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].itemInOrderBadge,
                                                                    title: "Проверено",
                                                                    "aria-hidden": true,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].doubleCheckIcon,
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        fill: "none",
                                                                        viewBox: "0 0 24 24",
                                                                        strokeWidth: 2.5,
                                                                        stroke: "currentColor",
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M5 12l3 3 7-7"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 2122,
                                                                                columnNumber: 37
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M9 15l2 2 5-5"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                                lineNumber: 2123,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 2112,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 2107,
                                                                    columnNumber: 33
                                                                }, this),
                                                                approvedOrder && approvalRemainingMs > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    href: `/checkout?orderId=${approvedOrder.id}`,
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryBasketButton,
                                                                    title: "Корзинка — перейти к оформлению",
                                                                    "aria-label": "Корзинка — перейти к оформлению",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deliveryBasketButtonIcon
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 2133,
                                                                        columnNumber: 37
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 2127,
                                                                    columnNumber: 35
                                                                }, this)
                                                            ]
                                                        }, void 0, true)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2071,
                                                    columnNumber: 27
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                            lineNumber: 1999,
                                            columnNumber: 25
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                        lineNumber: 1998,
                                        columnNumber: 23
                                    }, this) : null,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummary,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryRows,
                                                children: [
                                                    (()=>{
                                                        const fallbackToReview = section.id === 'section1' && returnedForCorrectionOrder && section.products.length === 0 && section.components.length === 0 && cartServiceItems.length === 0;
                                                        const displaySection = fallbackToReview ? cartSections[1] : section;
                                                        const productLabel = pluralizeRu(displaySection.productCount, 'товар', 'товара', 'товаров');
                                                        const serviceLabel = pluralizeRu(displaySection.serviceCategoryCount, 'услуга', 'услуги', 'услуг');
                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryRow,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryLabel,
                                                                            children: "Товары:"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 2168,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: [
                                                                                displaySection.productCount,
                                                                                " ",
                                                                                productLabel,
                                                                                " ·",
                                                                                ' ',
                                                                                displaySection.productTotal.toLocaleString('ru-RU'),
                                                                                " ₽"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 2169,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 2167,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryRow,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryLabel,
                                                                            children: "Услуги:"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 2175,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: [
                                                                                displaySection.serviceCategoryCount,
                                                                                " ",
                                                                                serviceLabel,
                                                                                " ·",
                                                                                ' ',
                                                                                displaySection.serviceTotal.toLocaleString('ru-RU'),
                                                                                " ₽"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                            lineNumber: 2176,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                    lineNumber: 2174,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true);
                                                    })(),
                                                    section.id === 'section1' && wantDelivery && !orderWithDelivery && calculatedDelivery || section.id === 'section2' && (pendingOrderHasDelivery || returnedOrderHasDelivery) && orderWithDelivery || section.id === 'section3' && approvedOrderHasDelivery && orderWithDelivery ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryRow,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryLabel,
                                                                        children: "Доставка:"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 2196,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: [
                                                                            section.id === 'section1' && calculatedDelivery ? calculatedDelivery.totalShippingCost.toLocaleString() : orderWithDelivery ? (Number(orderWithDelivery.shippingCost ?? 0) + Number(orderWithDelivery.carryCost ?? 0)).toLocaleString() : '0',
                                                                            ' ',
                                                                            "₽"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                        lineNumber: 2197,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 2195,
                                                                columnNumber: 29
                                                            }, this),
                                                            deliveryPaymentMode === 'ON_SITE' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionDeliveryNote,
                                                                children: "Стоимость доставки не включена в заказ"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 2210,
                                                                columnNumber: 31
                                                            }, this)
                                                        ]
                                                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryRow,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryLabel,
                                                                children: "Доставка:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 2217,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "—"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 2218,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2216,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryRow} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionSummaryRowTotal}`,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionTotalLabel,
                                                                children: "Итого:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 2224,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionTotal,
                                                                children: (()=>{
                                                                    const fallbackToReview = section.id === 'section1' && returnedForCorrectionOrder && section.products.length === 0 && section.components.length === 0 && cartServiceItems.length === 0;
                                                                    const baseTotal = fallbackToReview ? cartSections[1]?.total ?? 0 : section.total;
                                                                    const hasDelivery = section.id === 'section1' && wantDelivery && !orderWithDelivery && calculatedDelivery || section.id === 'section2' && (pendingOrderHasDelivery || returnedOrderHasDelivery) && orderWithDelivery || section.id === 'section3' && approvedOrderHasDelivery && orderWithDelivery;
                                                                    const deliveryAmount = hasDelivery ? section.id === 'section1' && calculatedDelivery ? calculatedDelivery.totalShippingCost : orderWithDelivery ? Number(orderWithDelivery.shippingCost ?? 0) + Number(orderWithDelivery.carryCost ?? 0) : 0 : 0;
                                                                    const total = deliveryPaymentMode === 'WITH_ORDER' && hasDelivery ? baseTotal + deliveryAmount : baseTotal;
                                                                    return `${total.toLocaleString()} ₽`;
                                                                })()
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 2225,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2221,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 2144,
                                                columnNumber: 23
                                            }, this),
                                            section.id === 'section1' && returnedForCorrectionOrder && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].returnedForCorrectionBanner,
                                                role: "alert",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].returnedForCorrectionTitle,
                                                        children: [
                                                            "Заказ ",
                                                            returnedForCorrectionOrder.orderNumber,
                                                            " отправлен на доработку"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2266,
                                                        columnNumber: 27
                                                    }, this),
                                                    returnedForCorrectionOrder.returnedForCorrectionComment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].returnedForCorrectionHint,
                                                        children: returnedForCorrectionOrder.returnedForCorrectionComment
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2270,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 2265,
                                                columnNumber: 25
                                            }, this),
                                            section.id === 'section1' && canSubmitForReview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionActions,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].checkoutButton,
                                                        onClick: handleSubmitForReview,
                                                        disabled: submitInProgress || !canSubmitForReview,
                                                        children: submitInProgress ? 'Отправка...' : returnedForCorrectionOrder ? 'Отправить на проверку повторно' : 'Отправить на проверку'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2278,
                                                        columnNumber: 27
                                                    }, this),
                                                    !returnedForCorrectionOrder && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].checkoutHint,
                                                        children: "Обычно проверка длится около 15 минут"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2291,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 2277,
                                                columnNumber: 25
                                            }, this),
                                            section.id === 'section2' && (pendingReviewOrder || returnedForCorrectionOrder) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionActions,
                                                children: [
                                                    returnedForCorrectionOrder && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionHint,
                                                        children: "Менеджер оставил комментарии. Внесите изменения и нажмите кнопку «Отправить на проверку» в блоке выше."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2301,
                                                        columnNumber: 31
                                                    }, this),
                                                    pendingReviewOrder && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].checkoutHint} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].checkoutHintPink}`,
                                                        children: "Обычно проверка длится около 15 минут"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2307,
                                                        columnNumber: 31
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cancelReviewLink,
                                                        onClick: handleCancelReview,
                                                        disabled: cancelInProgress,
                                                        children: cancelInProgress ? 'Отмена…' : 'Отменить проверку'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2311,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 2299,
                                                columnNumber: 27
                                            }, this),
                                            section.id === 'section3' && approvedOrder && approvalRemainingMs > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cartSectionActions,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].approvalCountdown,
                                                        children: [
                                                            "Оформить в течение:",
                                                            ' ',
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].approvalCountdownTime,
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$api$2f$user$2d$orders$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatApprovalCountdown"])(approvalRemainingMs)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                                lineNumber: 2325,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2323,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/checkout?orderId=${approvedOrder.id}`,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].checkoutButton,
                                                        children: "Оформить заказ"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2329,
                                                        columnNumber: 27
                                                    }, this),
                                                    canSendToEmail && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailLink,
                                                        onClick: openSendToEmailModal,
                                                        children: "Отправить заказ на email клиенту"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                        lineNumber: 2336,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 2322,
                                                columnNumber: 25
                                            }, this),
                                            section.id === 'section3' && approvedOrder && approvalRemainingMs <= 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].checkoutHint,
                                                children: "Время действия заказа истекло. Обновляю…"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                lineNumber: 2347,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(site)/cart/page.tsx",
                                        lineNumber: 2143,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, section.id, true, {
                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                lineNumber: 1090,
                                columnNumber: 19
                            }, this)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].continueShoppingWrap,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/catalog/products",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].continueShopping,
                                children: "Продолжить покупки"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(site)/cart/page.tsx",
                                lineNumber: 2357,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2356,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                    lineNumber: 1080,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(site)/cart/page.tsx",
                lineNumber: 1079,
                columnNumber: 9
            }, this),
            showAddToApprovedModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalOverlay,
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": "add-to-approved-modal-title",
                onClick: (e)=>{
                    if (e.target === e.currentTarget) setShowAddToApprovedModal(false);
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalContent,
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            id: "add-to-approved-modal-title",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalTitle,
                            children: "Добавить товары к проверенному заказу?"
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2376,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalText,
                            children: "У вас уже есть проверенный заказ. При отправке новых товаров и услуг на проверку они будут добавлены к вашему проверенному заказу, и заказ снова отправится на проверку менеджеру."
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2379,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalHint,
                            children: "После проверки вы сможете оформить и оплатить весь заказ целиком."
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2384,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalActions,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalButtonSecondary,
                                    onClick: ()=>setShowAddToApprovedModal(false),
                                    disabled: submitInProgress,
                                    children: "Отмена"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2388,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalButtonPrimary,
                                    onClick: ()=>doSubmitForReview({
                                            addToApproved: true
                                        }),
                                    disabled: submitInProgress,
                                    children: submitInProgress ? 'Отправка…' : 'Да, добавить к заказу'
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2396,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2387,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                    lineNumber: 2375,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(site)/cart/page.tsx",
                lineNumber: 2366,
                columnNumber: 9
            }, this),
            showSendToEmailModal && approvedOrder && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalOverlay,
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": "send-to-email-modal-title",
                onClick: (e)=>{
                    if (e.target === e.currentTarget && !sendToEmailInProgress) setShowSendToEmailModal(false);
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalContent,
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            id: "send-to-email-modal-title",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalTitle,
                            children: "Отправить заказ на email клиенту"
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2421,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalText,
                            children: "Заполните данные покупателя. На указанный email будет отправлена ссылка на просмотр и оформление заказа."
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2424,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailForm,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailRow,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailField,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailLabel,
                                                    htmlFor: "send-email",
                                                    children: [
                                                        "Email ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].required,
                                                            children: "*"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                            lineNumber: 2432,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2431,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    id: "send-email",
                                                    type: "email",
                                                    value: sendToEmailCustomer.customerEmail,
                                                    onChange: (e)=>setSendToEmailCustomer((s)=>({
                                                                ...s,
                                                                customerEmail: e.target.value
                                                            })),
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailInput,
                                                    placeholder: "customer@example.com"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2434,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                            lineNumber: 2430,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailField,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailLabel,
                                                    htmlFor: "send-phone",
                                                    children: "Телефон"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2446,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    id: "send-phone",
                                                    type: "tel",
                                                    value: sendToEmailCustomer.customerPhone,
                                                    onChange: (e)=>setSendToEmailCustomer((s)=>({
                                                                ...s,
                                                                customerPhone: e.target.value
                                                            })),
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailInput,
                                                    placeholder: "+7 (___) ___-__-__"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2449,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                            lineNumber: 2445,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2429,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailRow,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailField,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailLabel,
                                                    htmlFor: "send-lastName",
                                                    children: "Фамилия"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2463,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    id: "send-lastName",
                                                    type: "text",
                                                    value: sendToEmailCustomer.customerLastName,
                                                    onChange: (e)=>setSendToEmailCustomer((s)=>({
                                                                ...s,
                                                                customerLastName: e.target.value
                                                            })),
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailInput
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2466,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                            lineNumber: 2462,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailField,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailLabel,
                                                    htmlFor: "send-firstName",
                                                    children: "Имя"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2477,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    id: "send-firstName",
                                                    type: "text",
                                                    value: sendToEmailCustomer.customerFirstName,
                                                    onChange: (e)=>setSendToEmailCustomer((s)=>({
                                                                ...s,
                                                                customerFirstName: e.target.value
                                                            })),
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailInput
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2480,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                            lineNumber: 2476,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailField,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailLabel,
                                                    htmlFor: "send-middleName",
                                                    children: "Отчество"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2491,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    id: "send-middleName",
                                                    type: "text",
                                                    value: sendToEmailCustomer.customerMiddleName,
                                                    onChange: (e)=>setSendToEmailCustomer((s)=>({
                                                                ...s,
                                                                customerMiddleName: e.target.value
                                                            })),
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailInput
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                                    lineNumber: 2494,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                                            lineNumber: 2490,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2461,
                                    columnNumber: 15
                                }, this),
                                sendToEmailMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendToEmailError,
                                    role: "alert",
                                    children: sendToEmailMessage
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2506,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2428,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalActions,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalButtonSecondary,
                                    onClick: ()=>!sendToEmailInProgress && setShowSendToEmailModal(false),
                                    disabled: sendToEmailInProgress,
                                    children: "Отмена"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2512,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalButtonPrimary,
                                    onClick: handleSendToEmailSubmit,
                                    disabled: sendToEmailInProgress,
                                    children: sendToEmailInProgress ? 'Отправка…' : 'Отправить на email'
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2520,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2511,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                    lineNumber: 2420,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(site)/cart/page.tsx",
                lineNumber: 2410,
                columnNumber: 9
            }, this),
            showAddToPendingReviewModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalOverlay,
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": "add-to-pending-review-modal-title",
                onClick: (e)=>{
                    if (e.target === e.currentTarget) setShowAddToPendingReviewModal(false);
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalContent,
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            id: "add-to-pending-review-modal-title",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalTitle,
                            children: "Обновить заказ на проверке?"
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2544,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalText,
                            children: "У вас уже есть заказ на проверке. При отправке новых товаров и услуг они добавятся к этому заказу, и проверка запустится заново с обновлённым списком товаров и услуг."
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2547,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalHint,
                            children: "Менеджер увидит объединённый заказ и проверит его заново."
                        }, void 0, false, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2551,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalActions,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalButtonSecondary,
                                    onClick: ()=>setShowAddToPendingReviewModal(false),
                                    disabled: submitInProgress,
                                    children: "Отмена"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2555,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$site$292f$cart$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].confirmModalButtonPrimary,
                                    onClick: ()=>doSubmitForReview({
                                            addToPendingReview: true
                                        }),
                                    disabled: submitInProgress,
                                    children: submitInProgress ? 'Отправка…' : 'Да, обновить заказ'
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                                    lineNumber: 2563,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/(site)/cart/page.tsx",
                            lineNumber: 2554,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(site)/cart/page.tsx",
                    lineNumber: 2543,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(site)/cart/page.tsx",
                lineNumber: 2534,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(site)/cart/page.tsx",
        lineNumber: 1058,
        columnNumber: 5
    }, this);
}
_s(CartPage, "izx5KHtatJf9BRTYJYiBcYpJM9k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$contexts$2f$ApprovedOrderGuardContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApprovedOrderGuard"]
    ];
});
_c = CartPage;
var _c;
__turbopack_context__.k.register(_c, "CartPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_24b8cce2._.js.map