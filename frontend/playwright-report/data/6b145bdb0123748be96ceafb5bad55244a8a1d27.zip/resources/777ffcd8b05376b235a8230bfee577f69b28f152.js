(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_2bab8063._.js",
  "static/chunks/src_views_services_ui_ServiceCatalogPage_ServiceCatalogPage_module_db4f6e04.css"
],
    source: "dynamic"
});
